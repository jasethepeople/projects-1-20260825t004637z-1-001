;;;; -*- Mode: Lisp; Syntax: ANSI-Common-Lisp; Base: 10 -*-
;;;;
;;;; LISPMIND.ASD -- ASDF System Definition
;;;;
;;;; This file defines the LISPMIND system for ASDF (Another System Definition
;;;; Facility). LISPMIND is a self-healing agentic AI orchestrator built on
;;;; CLOS MOP, the condition/restart system, and advanced concurrency primitives.
;;;;
;;;; Load with: (ql:quickload :lispmind)

(defsystem :lispmind
  :description "LISPMIND -- Self-Healing Agentic AI Orchestrator"
  :author "Lisp Machine Wizard"
  :license "MIT"
  :version "2.3.0"

  ;; -------------------------------------------------------------------------
  ;; Serial compilation ensures files are compiled in declaration order.
  ;; Each file builds on symbols defined in the previous ones.
  ;; -------------------------------------------------------------------------
  :serial t

  ;; -------------------------------------------------------------------------
  ;; Component Graph -- each arrow is a compile-time dependency
  ;;
  ;;   packages --> conditions --> agent-class --> macros --> orchestrator
  ;;        |                                                    |
  ;;        |   hotpatch <-- checkpoint <-- gossip <-- evolution  |
  ;;        |                       |              |              |
  ;;        |                       v              v              v
  ;;        |               image-persist    profiler       dashboard --> demo
  ;;        |                                                     ^
  ;;        |   telemetry --> websocket --> kali-interface          |
  ;;        |                                    |                  |
  ;;        |                       policy-gatekeeper               |
  ;;        |                                    |                  |
  ;;        |                               mcp-bridge              |
  ;;        |                                    |                  |
  ;;        |          inference --> osint-engine                   |
  ;;
  ;; packages        -- Central package definition.  All files live here.
  ;; conditions      -- Custom condition hierarchy + restart API.
  ;; agent-class     -- CLOS agent class with MOP hooks for monitoring.
  ;; macros          -- DSL macro (define-agent-type) expands into class + method.
  ;; orchestrator    -- Registry, monitor loop, healing, inter-agent messaging.
  ;; hotpatch        -- Safe function replacement and versioning primitives.
  ;; checkpoint      -- State serialization / deserialization via cl-store.
  ;; gossip          -- ZeroMQ-based distributed agent communication (stub mode
  ;;                    graceful degradation when :cl-zeromq unavailable).
  ;; evolution       -- Genetic programming: agents evolve their own strategies.
  ;; image-persist   -- Image-based persistence via SBCL save-lisp-and-die.
  ;; profiler        -- Statistical profiling, flamegraphs, auto-tuning.
  ;; telemetry       -- Real-time metrics calculation + JSON encoding pipeline.
  ;; websocket       -- WebSocket/TCP server for dashboard data streaming.
  ;; kali-interface  -- Kali Linux tool wrappers (12 tools), shadow agents.
  ;; policy-gatekeeper -- Tool policy enforcement, janitor cleanup, network recovery.
  ;; mcp-bridge      -- Model Context Protocol server (JSON-RPC 2.0, stdio + SSE).
  ;; dashboard       -- ASCII REPL dashboard and interactive commands.
  ;; demo            -- Self-contained demonstration narrative.
  ;; -------------------------------------------------------------------------
  :components ((:file "packages")
               (:file "conditions")
               (:file "agent-class")
               (:file "macros")
               (:file "orchestrator")
               (:file "hotpatch")
               (:file "checkpoint")
               (:file "gossip")
               (:file "evolution")
               (:file "image-persist")
               (:file "profiler")
               (:file "telemetry")
               (:file "websocket")
               (:file "kali-interface")
               (:file "policy-gatekeeper")
               (:file "mcp-bridge")
               (:file "inference")
               (:file "osint-engine")
               (:file "dashboard")
               (:file "demo"))

  ;; -------------------------------------------------------------------------
  ;; Dependency Justification
  ;; -------------------------------------------------------------------------
  ;; Each dependency was chosen deliberately to solve a specific engineering
  ;; problem.  No bloat -- every library earns its place.
  ;;
  ;; :bordeaux-threads  -- Portable threading API across Lisp implementations.
  ;;                       We use it for agent monitor threads, heartbeat
  ;;                       timers, and lock-protected slot access.  Essential
  ;;                       for any concurrent orchestrator.
  ;;
  ;; :closer-mop        -- CLOS Meta-Object Protocol portability layer.
  ;;                       Enables :around methods on slot accessors for
  ;;                       health/status change notifications, class
  ;;                       introspection, and metaclass manipulation.
  ;;
  ;; :alexandria        -- The de-facto standard utility library.  Provides
  ;;                       `once-only', `with-gensyms', `define-constant',
  ;;                       and other macros that keep our code clean and
  ;;                       battle-tested.
  ;;
  ;; :cl-ppcre          -- Perl-compatible regular expressions.  Used in
  ;;                       agent log parsing, strategy validation, and
  ;;                       dashboard filtering.
  ;;
  ;; :local-time        -- High-precision timestamp handling.  Powers agent
  ;;                       heartbeats, checkpoint timestamps, and elapsed-time
  ;;                       calculations for strategy-stall detection.
  ;;
  ;; :cl-store          -- Fast binary serialization of Lisp objects.  The
  ;;                       backbone of the checkpoint/restore system that
  ;;                       enables zero-downtime agent persistence.
  ;;
  ;; :lparallel         -- Parallel programming toolkit (thread pools,
  ;;                       channels, promises).  Used to parallelize
  ;;                       multi-agent strategy execution and checkpoint
  ;;                       I/O operations.
  ;;
  ;; :cl-zeromq         -- [OPTIONAL] ZeroMQ bindings for distributed gossip.
  ;;                       Install libzmq3-dev + (ql:quickload :cl-zeromq).
  ;;                       If absent, gossip runs in stub mode with warnings.
  ;;                       Commented out by default for air-gapped installs.
  ;; -------------------------------------------------------------------------
  :depends-on (:bordeaux-threads
               :closer-mop
               :alexandria
               :cl-ppcre
               :local-time
               :cl-store
               :lparallel
               ;; :cl-zeromq   ; uncomment after `apt install libzmq3-dev'
               ))
