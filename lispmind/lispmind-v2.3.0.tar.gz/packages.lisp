;;;; -*- Mode: Lisp; Syntax: ANSI-Common-Lisp; Base: 10 -*-
;;;;
;;;; PACKAGES.LISP -- Central Package Definition for LISPMIND
;;;;
;;;; This is the first file loaded by ASDF (see lispmind.asd).  It defines the
;;;; LISPMIND package (nickname MIND) and exports every public symbol that the
;;;; implementation files create or reference.  Keep this file in strict sync
;;;; with the rest of the codebase -- every exported generic function, class,
;;;; condition, and accessor must have a corresponding definition.

(in-package :cl-user)

;; ---------------------------------------------------------------------------
;; Package LISPMIND  (Nickname: MIND)
;; ---------------------------------------------------------------------------
;; The canonical namespace for the entire orchestrator.  All implementation
;; files begin with (in-package :lispmind).  External users should use the
;; MIND nickname for brevity: (mind:run-demo).
;;
;; Shadowing imports prevent name collisions between our exported symbols and
;; identically-named symbols from the used packages.  In particular:
;;   - `agent-health' shadows any potential generic from Alexandria
;;   - `agent-state' avoids ambiguity with closer-mop:class-state
;; ---------------------------------------------------------------------------
(defpackage :lispmind
  (:nicknames :mind)
  (:use
   ;; The Common Lisp standard -- our foundation.
   :cl

   ;; Portable threading: locks, condition variables, threads.  Used heavily
   ;; in orchestrator.lisp and agent-class.lisp for concurrent agent access.
   :bordeaux-threads

   ;; CLOS MOP portability layer.  Enables :around methods on slot accessors
   ;; so that health/status changes automatically trigger notifications.
   :closer-mop

   ;; Alexandria utilities: with-gensyms, once-only, define-constant, etc.
   :alexandria)

  (:shadowing-import-from :closer-mop
                          #:standard-class)

  ;; =======================================================================
  ;; CONDITION EXPORTS -- The Custom Condition Hierarchy
  ;; =======================================================================
  ;; These are the four condition classes that the orchestrator recognizes
  ;; and handles.  Each carries rich diagnostic data so the healing subsystem
  ;; can make informed restart decisions.
  ;;
  ;; Inheritance: all conditions ultimately inherit from ERROR.
  ;;
  ;; Usage in orchestrator.lisp: handler-bind binds these to restart
  ;; functions selected by default-restart-policy.
  ;; =======================================================================

  ;; Base condition for any agent-level failure.
  (:export #:agent-failure)

  ;; Raised when an agent's strategy function runs longer than its threshold
  ;; without producing progress.
  (:export #:strategy-stalled)

  ;; Raised when an agent exceeds its resource quota (memory, CPU, handles).
  (:export #:resource-exhausted)

  ;; Raised when an external system (network, database, API) fails to respond
  ;; within the allotted time.
  (:export #:external-timeout)

  ;; ---- Condition Readers --------------------------------------------------
  ;; Each slot below has an auto-generated reader (and writer when mutable).
  ;; These readers are exported so external debugging tools and the dashboard
  ;; can inspect condition details without breaking encapsulation.

  ;; AGENT-FAILURE readers
  (:export #:agent-failure-agent-id      ; symbol -- which agent failed
           #:agent-failure-reason)        ; string -- human-readable cause

  ;; STRATEGY-STALLED readers
  (:export #:strategy-stalled-agent-id       ; symbol -- stalled agent
           #:strategy-stalled-elapsed-time   ; float -- seconds since start
           #:strategy-stalled-threshold)     ; float -- configured limit

  ;; RESOURCE-EXHAUSTED readers
  (:export #:resource-exhausted-agent-id       ; symbol -- over-limit agent
           #:resource-exhausted-resource-type  ; keyword -- :memory | :cpu | :handles
           #:resource-exhausted-current-usage  ; number -- actual consumption
           #:resource-exhausted-limit)         ; number -- configured ceiling

  ;; EXTERNAL-TIMEOUT readers
  (:export #:external-timeout-agent-id          ; symbol -- waiting agent
           #:external-timeout-operation         ; string -- what was attempted
           #:external-timeout-timeout-seconds)  ; float -- how long it waited

  ;; =======================================================================
  ;; CLASS EXPORTS -- CLOS Class Names
  ;; =======================================================================
  ;; These are the two primary classes.  AGENT is the base unit of
  ;; computation; ORCHESTRATOR is a meta-agent that supervises a colony
  ;; of agents.
  ;; =======================================================================

  (:export #:agent)          ; Base agent class with MOP hooks
  (:export #:orchestrator)   ; Meta-agent: registry, monitor, messenger

  ;; =======================================================================
  ;; GENERIC FUNCTION EXPORTS -- Polymorphic Operations
  ;; =======================================================================
  ;; These generic functions form the core protocol.  Each has methods
  ;; specialized on AGENT, ORCHESTRATOR, or subclasses created by
  ;; DEFINE-AGENT-TYPE.  New agent types automatically participate in
  ;; the protocol by inheriting from AGENT.
  ;; =======================================================================

  ;; Execute the agent's current strategy function.  Primary method on
  ;; base AGENT is a no-op; DEFINE-AGENT-TYPE generates a real method.
  (:export #:run-agent)

  ;; Dispatch a condition to the agent's restart policy.  Returns a restart
  ;; keyword (e.g. :retry, :use-fallback, :escalate).
  (:export #:handle-condition)

  ;; Predicate: is the agent still alive?  Checks health > 0 and heartbeat
  ;; freshness (within 30 seconds).
  (:export #:agent-alive-p)

  ;; Callback invoked by MOP :around methods when agent-health changes.
  ;; Implemented in orchestrator.lisp to trigger healing when health drops
  ;; below critical thresholds.
  (:export #:notify-health-change)

  ;; Callback invoked by MOP :around methods when agent-status changes.
  ;; Used by the dashboard to refresh its display without polling.
  (:export #:notify-status-change)

  ;; =======================================================================
  ;; FUNCTION EXPORTS -- API Entry Points
  ;; =======================================================================
  ;; These are the functions that users (and demo.lisp) call directly.
  ;; Every function has a docstring in its defining file.
  ;; =======================================================================

  ;; ---- Agent Lifecycle ----------------------------------------------------
  (:export #:make-agent)           ; Create a generic agent instance.
  (:export #:define-agent-type)    ; Macro: DSL for declaring agent subclasses.
  (:export #:register-agent)       ; Add an agent to an orchestrator's registry.
  (:export #:deregister-agent)     ; Remove an agent by id from the registry.

  ;; ---- Orchestrator Control -----------------------------------------------
  (:export #:start-orchestrator)   ; Launch monitor + dashboard threads.
  (:export #:stop-orchestrator)    ; Graceful shutdown of all threads.

  ;; ---- Introspection ------------------------------------------------------
  (:export #:list-agents)          ; Return all registered agents.
  (:export #:inspect-agent)        ; Detailed human-readable agent report.

  ;; ---- Healing & Patching -------------------------------------------------
  (:export #:heal-agent)           ; Apply a named restart to an agent.
  (:export #:hotpatch-agent)       ; Replace strategy at runtime, zero-downtime.
  (:export #:rollback-strategy)    ; Revert to a previous strategy version.

  ;; ---- Persistence --------------------------------------------------------
  (:export #:checkpoint-system)           ; Serialize entire orchestrator state.
  (:export #:restore-system)             ; Restore from checkpoint directory.
  (:export #:checkpoint-agent)           ; Serialize single agent state.
  (:export #:restore-agent-from-checkpoint)  ; Recreate agent from disk.

  ;; ---- Image-Based Persistence (Resurrection Engine) --------------------
  (:export #:save-golden-image)           ; Save entire SBCL image as executable.
  (:export #:resurrect-toplevel)         ; Entry point for golden image restart.
  (:export #:enable-immortality)         ; Enable full image-based persistence.
  (:export #:disable-immortality)        ; Stop watchdog, disable auto-save.
  (:export #:record-resurrection-data)   ; Store orchestrator state for image save.
  (:export #:compute-heuristics-score)   ; Calculate swarm health score (0-100).
  (:export #:should-save-golden-image-p) ; Check if heuristics justify saving.
  (:export #:start-watchdog)             ; Launch the immortality watchdog thread.
  (:export #:stop-watchdog)              ; Stop the watchdog gracefully.
  (:export #:list-golden-images)         ; List all golden images with metadata.
  (:export #:find-latest-golden-image)   ; Find the most recent golden image.
  (:export #:load-golden-image)          ; Launch a golden image in new process.
  (:export #:prune-golden-images)        ; Delete old images, keep N most recent.
  (:export #:check-unclean-shutdown)    ; Detect crash/power-loss from heartbeat.
  (:export #:image-persistence-available-p)  ; T if SBCL save-lisp-and-die available.
  (:export #:golden-image-metadata)      ; Metadata struct for golden images.

  ;; ---- Dashboard & Demo ---------------------------------------------------
  (:export #:start-dashboard)      ; Launch ASCII dashboard in its own thread.
  (:export #:stop-dashboard)       ; Terminate dashboard thread.
  (:export #:run-demo)             ; Self-contained demonstration narrative.
  (:export #:simulate-failure)    ; Inject a synthetic condition for testing.

  ;; ---- Messaging ----------------------------------------------------------
  (:export #:send-message)         ; Inter-agent asynchronous message passing.

  ;; =======================================================================
  ;; GOSSIP EXPORTS -- Distributed Agent Communication (ZeroMQ)
  ;; =======================================================================
  ;; The gossip module extends LISPMIND from a single-process orchestrator
  ;; to a distributed swarm. Agents publish health, evolution events, and
  ;; threat intelligence across machine boundaries via ZeroMQ PUB/SUB.
  ;;
  ;; When :cl-zeromq is unavailable, all functions degrade to stub mode:
  ;; they print a warning and return nil, allowing the system to compile
  ;; and run without the native libzmq dependency.
  ;; =======================================================================

  ;; ---- Gossip State & Configuration ---------------------------------------
  (:export #:*gossip-context*)            ; ZeroMQ context handle (nil in stub mode)
  (:export #:*gossip-publisher*)          ; PUB socket for outbound messages
  (:export #:*gossip-subscriber*)         ; SUB socket for inbound messages
  (:export #:*gossip-endpoint-inproc*)   ; In-process transport endpoint string
  (:export #:*gossip-endpoint-tcp*)      ; TCP bind address for cross-machine gossip
  (:export #:*gossip-peers*)             ; List of remote peer TCP endpoints
  (:export #:*gossip-topics*)            ; Hash-table: topic -> callback list
  (:export #:*gossip-lock*)              ; Mutex protecting gossip state mutations
  (:export #:*gossip-receive-thread*)    ; Background message receive thread
  (:export #:*gossip-running-p*)         ; Predicate: is the gossip node active?

  ;; ---- Gossip Message Protocol --------------------------------------------
  (:export #:gossip-message)              ; Struct: serialized wire format
  (:export #:make-gossip-message)         ; Constructor
  (:export #:gossip-message-topic)        ; Reader: topic string
  (:export #:gossip-message-payload)      ; Reader: arbitrary Lisp payload
  (:export #:gossip-message-timestamp)    ; Reader: local-time timestamp
  (:export #:gossip-message-sender-id)    ; Reader: symbol identifying sender
  (:export #:serialize-message)           ; gossip-message -> JSON string
  (:export #:deserialize-message)         ; JSON string -> gossip-message

  ;; ---- Gossip Node Lifecycle ----------------------------------------------
  (:export #:start-gossip-node)           ; Create context, bind sockets, start receiver
  (:export #:stop-gossip-node)            ; Tear down context, join receiver thread
  (:export #:add-peer)                    ; Register a remote peer endpoint
  (:export #:remove-peer)                 ; Unregister a remote peer endpoint
  (:export #:list-peers)                  ; Return all registered peer endpoints

  ;; ---- Publish/Subscribe API ----------------------------------------------
  (:export #:publish-message)             ; Send a message on a topic
  (:export #:gossip-broadcast)            ; Publish to all known topics
  (:export #:subscribe-topic)             ; Register a callback for a topic
  (:export #:register-topic)              ; Alias for subscribe-topic
  (:export #:unregister-topic)            ; Remove a callback for a topic
  (:export #:topic-callbacks)             ; Return callbacks registered for a topic

  ;; ---- Orchestrator Integration -------------------------------------------
  (:export #:publish-agent-health)        ; Publish orchestrator health to swarm
  (:export #:publish-evolution-event)     ; Broadcast an agent evolution event
  (:export #:handle-remote-health)        ; Callback: process health from peer
  (:export #:handle-remote-threat)        ; Callback: process threat alert from peer
  (:export #:start-orchestrator-with-gossip) ; Launch orchestrator + gossip node

  ;; ---- Peer Discovery -----------------------------------------------------
  (:export #:discover-peers)              ; Scan IP range for gossip nodes
  (:export #:announce-presence)           ; Broadcast presence on local network
  (:export #:handle-presence-announcement) ; Callback: process peer announcement
  (:export #:gossip-status)               ; Return gossip node state plist
  (:export #:gossip-topic-list)           ; Return list of active topics

  ;; =======================================================================
  ;; EVOLUTION EXPORTS -- Genetic Programming Engine
  ;; =======================================================================
  ;; The evolution module gives agents the ability to evolve their own
  ;; strategies through genetic programming. Each strategy is represented
  ;; as an S-expression tree (chromosome) that undergoes mutation and
  ;; crossover to improve fitness over successive generations.
  ;;
  ;; Key entry point: DEFINE-EVOLVING-AGENT macro creates agents that
  ;; automatically trigger GP when their error count exceeds a threshold.
  ;; =======================================================================

  ;; ---- Chromosome Data Type -----------------------------------------------
  (:export #:strategy-chromosome)              ; The genome struct for GP trees
  (:export #:make-strategy-chromosome)          ; Constructor for chromosomes
  (:export #:chromosome-p)                      ; Predicate: is object a chromosome?
  (:export #:chromosome<)                       ; Comparator: sort by fitness descending
  (:export #:strategy-chromosome-id)            ; Chromosome unique ID
  (:export #:strategy-chromosome-expression)    ; The S-expression tree
  (:export #:strategy-chromosome-fitness)       ; Fitness score (higher=better)
  (:export #:strategy-chromosome-generation)    ; Which GP generation
  (:export #:strategy-chromosome-parent-ids)    ; Lineage tracking

  ;; ---- GP Configuration Parameters ----------------------------------------
  (:export #:*default-gp-functions*)       ; Default function set for GP trees
  (:export #:*default-gp-terminals*)       ; Default terminal set for GP trees
  (:export #:*max-gp-tree-depth*)          ; Maximum depth of generated trees
  (:export #:*bloat-penalty-factor*)       ; Parsimony pressure coefficient
  (:export #:*mutation-rate*)              ; Probability of subtree mutation
  (:export #:*crossover-rate*)             ; Probability of subtree crossover
  (:export #:*tournament-size*)            ; Selection tournament pool size

  ;; ---- Tree Utilities -----------------------------------------------------
  (:export #:tree-size)                    ; Count nodes in S-expression
  (:export #:tree-depth)                   ; Compute max depth of S-expression
  (:export #:random-subtree)               ; Pick a random subtree address
  (:export #:replace-subtree)              ; Substitute subtree at address
  (:export #:count-nodes)                  ; Alias for tree-size
  (:export #:random-terminal)              ; Pick random terminal from set
  (:export #:random-function)              ; Pick random function from set
  (:export #:function-arity)               ; Return arity of a function symbol
  (:export #:random-expression)            ; Generate random tree (grow/full/mixed)
  (:export #:extract-terminals)            ; Extract all terminals from an expression
  (:export #:expression-to-string)         ; Pretty-print S-expression as string
  (:export #:validate-expression)          ; Sanity-check strategy S-expression

  ;; ---- Genetic Operators --------------------------------------------------
  (:export #:mutate-subtree)               ; GP mutation: replace random subtree
  (:export #:crossover-subtrees)           ; GP crossover: swap subtrees between parents
  (:export #:compile-chromosome)           ; S-expression -> executable function
  (:export #:decompile-strategy)           ; Function -> S-expression (best-effort)

  ;; ---- Fitness & Selection ------------------------------------------------
  (:export #:strategy-fitness)             ; Evaluate fitness of a chromosome
  (:export #:score-result)                 ; Score a single actual-vs-expected result
  (:export #:tournament-select)            ; Select one individual via tournament
  (:export #:select-parents)               ; Select pair of parents for breeding

  ;; ---- Population Management ----------------------------------------------
  (:export #:initialize-population)        ; Create initial population from seed
  (:export #:evaluate-population)          ; Compute fitness for entire population
  (:export #:fittest-chromosome)           ; Return best individual in population
  (:export #:average-fitness)              ; Mean fitness across population
  (:export #:next-generation)             ; Produce next generation (elitism + crossover + mutation)

  ;; ---- Evolution Lifecycle ------------------------------------------------
  (:export #:generate-initial-strategy)    ; Create seed chromosome from capabilities
  (:export #:evolve-strategy)             ; Core GP engine entry point
  (:export #:run-evolutionary-cycle)      ; Main evolution entry point
  (:export #:should-evolve-p)             ; Predicate: should agent trigger GP?
  (:export #:define-evolving-agent)       ; Macro: auto-evolving agent declaration
  (:export #:generate-default-fitness-data) ; Create fitness dataset from agent state

  ;; ---- Evolution Logging & Introspection ----------------------------------
  (:export #:*evolution-log*)              ; Global evolution history hash-table
  (:export #:*evolution-log-lock*)         ; Mutex protecting evolution-log
  (:export #:log-evolution)               ; Record an evolution event
  (:export #:evolution-history)           ; Retrieve history for an agent
  (:export #:print-evolution-report)      ; Formatted evolution report

  ;; ---- Healing Integration ------------------------------------------------
  (:export #:healing-via-evolution)       ; Orchestrator integration: heal via GP
  (:export #:list-strategy-functions)     ; List all available GP function symbols
  (:export #:list-strategy-terminals)     ; List terminals for given capabilities

  ;; =======================================================================
  ;; IMAGE-PERSIST EXPORTS -- SBCL Image-Based Persistence (Resurrection)
  ;; =======================================================================
  ;; The image-persist module provides process-level persistence via
  ;; SBCL's save-lisp-and-die. The entire orchestrator state is captured
  ;; in a "golden image" that can be restarted after crash or power loss.
  ;;
  ;; When SBCL save-lisp-and-die is unavailable, the module gracefully
  ;; falls back to cl-store checkpointing via checkpoint.lisp.
  ;; =======================================================================

  ;; ---- Configuration Parameters -------------------------------------------
  (:export #:*golden-image-directory*)       ; Directory path for golden images
  (:export #:*golden-image-prefix*)           ; Filename prefix for image files
  (:export #:*golden-image-count*)            ; Number of images to retain
  (:export #:*current-golden-image-version*)  ; Monotonic version counter
  (:export #:*watchdog-thread*)               ; Background watchdog thread handle
  (:export #:*watchdog-running-p*)            ; Is the watchdog active?
  (:export #:*last-heuristics-score*)         ; Most recent swarm health score
  (:export #:*heartbeat-file-path*)           ; Path for crash-detection heartbeat
  (:export #:*resurrection-data*)             ; Hash-table: state to survive image save

  ;; ---- Golden Image Metadata Struct ---------------------------------------
  (:export #:golden-image-metadata)                ; Struct: image metadata
  (:export #:make-golden-image-metadata)            ; Constructor
  (:export #:golden-image-metadata-version)         ; Reader: save version number
  (:export #:golden-image-metadata-timestamp)       ; Reader: save timestamp
  (:export #:golden-image-metadata-agent-count)     ; Reader: number of agents
  (:export #:golden-image-metadata-orchestrator-health) ; Reader: health at save time
  (:export #:golden-image-metadata-heuristics-score)    ; Reader: heuristics score
  (:export #:golden-image-metadata-checkpoint-file)     ; Reader: companion checkpoint path

  ;; ---- Image Lifecycle API ------------------------------------------------
  (:export #:image-persistence-available-p)    ; T if SBCL save-lisp-and-die available
  (:export #:compute-heuristics-score)         ; Calculate swarm health score (0-100)
  (:export #:should-save-golden-image-p)       ; Check if heuristics justify saving
  (:export #:save-golden-image)                ; Save SBCL image + metadata
  (:export #:resurrect-toplevel)               ; Entry point for golden image restart
  (:export #:enter-resurrected-main-loop)      ; Main loop after resurrection

  ;; ---- Watchdog & Auto-Save -----------------------------------------------
  (:export #:start-watchdog)                   ; Launch immortality watchdog thread
  (:export #:stop-watchdog)                    ; Stop watchdog gracefully
  (:export #:watchdog-loop)                    ; Core watchdog loop function
  (:export #:write-watchdog-heartbeat)         ; Write crash-detection heartbeat
  (:export #:check-unclean-shutdown)           ; Detect crash from heartbeat

  ;; ---- Image Inventory Management -----------------------------------------
  (:export #:list-golden-images)               ; List all images with metadata
  (:export #:find-latest-golden-image)         ; Return most recent image filename
  (:export #:load-golden-image)                ; Launch image in subprocess
  (:export #:prune-golden-images)              ; Delete old images, keep N recent
  (:export #:read-golden-metadata)             ; Parse metadata from filename
  (:export #:write-golden-metadata)            ; Write metadata to file

  ;; ---- Immortality Control ------------------------------------------------
  (:export #:enable-immortality)               ; Enable full auto-save pipeline
  (:export #:disable-immortality)              ; Stop watchdog, disable auto-save
  (:export #:record-resurrection-data)         ; Store state for image save
  (:export #:trigger-fallback-checkpoint)      ; Fallback to cl-store checkpointing

  ;; =======================================================================
  ;; PROFILER EXPORTS -- Statistical Profiling & Auto-Tuning
  ;; =======================================================================
  ;; The profiler module provides statistical sampling of agent thread
  ;; call stacks via SB-SPROF. It generates ASCII flamegraphs, detects
  ;; CPU hotspots, and can automatically apply SBCL optimizations (inline
  ;; declarations, type specializations) to hot functions.
  ;;
  ;; Key entry point: START-PROFILER-DASHBOARD launches a combined view
  ;; of agent health and CPU profiling data.
  ;; =======================================================================

  ;; ---- Profiler State & Configuration -------------------------------------
  (:export #:*profiler-running-p*)           ; Is the profiler actively sampling?
  (:export #:*profiler-thread*)               ; Background sampling thread handle
  (:export #:*profiler-data*)                 ; Hash-table: aggregated profile stats
  (:export #:*profiler-raw-samples*)          ; Circular buffer of raw samples
  (:export #:*profiler-sample-interval*)      ; Seconds between samples (default 0.01)
  (:export #:*profiler-hotspot-threshold*)    ; CPU fraction to flag as hotspot
  (:export #:*profiler-warm-threshold*)       ; CPU fraction to flag as warm
  (:export #:*auto-tune-enabled-p*)           ; Should monitor auto-optimize hotspots?
  (:export #:*auto-tuned-functions*)          ; Hash-table: functions already optimized
  (:export #:*profiler-lock*)                 ; Mutex protecting profiler data
  (:export #:*profiler-max-samples*)          ; Ring buffer capacity

  ;; ---- Data Structures ----------------------------------------------------
  (:export #:profile-sample)                 ; Struct: single stack sample
  (:export #:make-profile-sample)             ; Constructor
  (:export #:sample-thread)                   ; Reader: sampled thread
  (:export #:sample-timestamp)                ; Reader: sample timestamp
  (:export #:sample-stack)                    ; Reader: call stack as list
  (:export #:optimization-record)             ; Struct: auto-tuning audit entry
  (:export #:make-optimization-record)        ; Constructor
  (:export #:opt-function-name)               ; Reader: function that was optimized
  (:export #:opt-original-form)               ; Reader: form before optimization
  (:export #:opt-optimized-form)              ; Reader: form after optimization
  (:export #:opt-timestamp)                   ; Reader: when optimization occurred

  ;; ---- Profiling Control --------------------------------------------------
  (:export #:start-swarm-profile)             ; Begin statistical profiling
  (:export #:stop-swarm-profile)              ; Stop profiling, aggregate data
  (:export #:profiler-sample-loop)            ; Core sampling loop function
  (:export #:sample-worthy-thread-p)          ; Should a thread be sampled?
  (:export #:sample-call-stack)               ; Capture call stack of a thread
  (:export #:aggregate-profile-data)          ; Collate raw samples into stats

  ;; ---- Data Analysis ------------------------------------------------------
  (:export #:sync-sb-sprof-data)              ; Import data from SB-SPROF
  (:export #:total-samples)                   ; Total number of captured samples
  (:export #:incf-profile-stat)               ; Increment a profile counter
  (:export #:get-profile-stat)                ; Retrieve a profile counter
  (:export #:sorted-profile-functions)        ; Functions sorted by CPU usage

  ;; ---- Flamegraph & Visualization -----------------------------------------
  (:export #:generate-flamegraph)             ; Create ASCII flamegraph
  (:export #:generate-call-graph)             ; Create parent-child call graph
  (:export #:flamegraph-color)                ; ANSI color for a percentage
  (:export #:center-string)                    ; Utility: center text in field
  (:export #:profiler-dashboard-data)         ; Profile data formatted for dashboard

  ;; ---- Hotspot Detection --------------------------------------------------
  (:export #:detect-hotspots)                 ; Find functions exceeding threshold
  (:export #:profiler-sample-loop)            ; Core sampling loop

  ;; ---- Auto-Tuning --------------------------------------------------------
  (:export #:auto-tune-hotspot)               ; Optimize a single hotspot function
  (:export #:auto-tune-all-hotspots)          ; Optimize all detected hotspots
  (:export #:apply-inline-optimization)       ; Apply inline declaration
  (:export #:apply-type-declarations)         ; Add type specializations
  (:export #:attempt-recompile-optimization)  ; Recompile with higher optimize
  (:export #:optimization-report)             ; Display auto-tuning audit trail
  (:export #:reset-auto-tuning)               ; Revert all auto-tuned optimizations
  (:export #:enable-auto-tuning)              ; Enable automatic hotspot optimization
  (:export #:disable-auto-tuning)             ; Disable automatic hotspot optimization

  ;; ---- Dashboard Integration ----------------------------------------------
  (:export #:print-profiler-dashboard)        ; Combined agent table + flamegraph
  (:export #:start-profiler-dashboard)        ; Launch dashboard with profiling
  (:export #:profiler-check-in-monitor)       ; Orchestrator monitor hook

  ;; ---- Status & Introspection ---------------------------------------------
  (:export #:profiler-status)                 ; Return profiler state plist
  (:export #:print-profiler-status)           ; Print compact profiler status line
  (:export #:export-profile-data)             ; Save profile data to file

  ;; =======================================================================
  ;; ACCESSOR EXPORTS -- Slot Readers/Writers
  ;; =======================================================================
  ;; These are generated automatically by CLOS defclass :accessor specs.
  ;; They are exported so the dashboard, checkpoint system, and external
  ;; tooling can read (and sometimes write) agent state.
  ;;
  ;; NOTE: Writers are intentionally NOT exported for most slots to preserve
  ;; encapsulation.  Use the provided generic functions (heal-agent,
  ;; hotpatch-agent) for mutations.  The orchestrator's monitor loop
  ;; accesses slots directly -- it is the only privileged mutator.
  ;; =======================================================================

  ;; ---- Agent slots --------------------------------------------------------
  (:export #:agent-id)             ; symbol   -- unique identifier (read-only after creation)
  (:export #:agent-health)         ; integer  -- 0..100 health score
  (:export #:agent-strategy)       ; function -- current behavior function
  (:export #:agent-capabilities)   ; list     -- keyword capability tags
  (:export #:agent-restart-policy) ; function -- restart selection logic
  (:export #:agent-state)          ; hash-table -- agent-local key/value store
  (:export #:agent-heartbeat)      ; timestamp -- last alive signal
  (:export #:agent-error-count)    ; integer  -- cumulative errors since birth
  (:export #:agent-status)         ; keyword  -- :running :paused :failed :healing
  (:export #:agent-version)        ; integer  -- strategy version counter
  (:export #:agent-lock)           ; bt:lock  -- thread-safe mutation gate

  ;; ---- Orchestrator slots -------------------------------------------------
  (:export #:orchestrator-agents)           ; hash-table  -- id -> agent mapping
  (:export #:orchestrator-mailboxes)        ; hash-table  -- id -> message queue
  (:export #:orchestrator-running-p)        ; boolean     -- is the loop active?
  (:export #:orchestrator-monitor-thread)   ; bt:thread or nil -- health monitor
  (:export #:orchestrator-dashboard-thread) ; bt:thread or nil -- REPL display

  ;; =====================================================================
  ;; INFERENCE EXPORTS — Model Router + Strategy-Mutation Pipeline
  ;; =====================================================================
  (:export #:*inference-server-endpoint*)      ; llama.cpp/vLLM endpoint URL
  (:export #:*model-registry*)                 ; model-id → model-config hash
  (:export #:*default-model*)                  ; Symbol: default model-id
  (:export #:*inference-history*)              ; model-id → latency records
  (:export #:*inference-timeout-seconds*)      ; HTTP timeout
  (:export #:*http-client-preference*)         ; :dexador :drakma :curl
  (:export #:*swarm-mind-system-prompt*)       ; Default Swarm-Mind persona

  (:export #:model-config)                     ; Struct: model configuration
  (:export #:make-model-config)                ; Constructor
  (:export #:model-config-id)                  ; Reader: model symbol
  (:export #:model-config-name)                ; Reader: human name
  (:export #:model-config-endpoint)            ; Reader: URL override
  (:export #:model-config-max-tokens)          ; Reader: generation limit
  (:export #:model-config-temperature)         ; Reader: sampling temp
  (:export #:model-config-top-p)               ; Reader: nucleus sampling
  (:export #:model-config-system-prompt)       ; Reader: default prompt
  (:export #:model-config-specialty)           ; Reader: :analysis :coding etc
  (:export #:model-config-priority)            ; Reader: load-balance priority
  (:export #:model-config-enabled-p)           ; Reader: availability flag

  (:export #:register-model)                   ; Add model to registry
  (:export #:unregister-model)                 ; Remove model from registry
  (:export #:get-model)                        ; Lookup model-config by id
  (:export #:list-registered-models)           ; All model-id symbols
  (:export #:list-available-models)            ; Enabled (id . specialty) pairs
  (:export #:model-exists-p)                   ; Is model registered+enabled?
  (:export #:register-default-models)          ; Register the 4 built-in models
  (:export #:set-model-enabled)                ; Toggle model availability

  (:export #:ask-model)                        ; Core: POST to model, get text
  (:export #:ask-default)                      ; Convenience: ask default model
  (:export #:ask-with-role)                    ; Route by :analysis/:coding etc
  (:export #:quick-inference)                  ; One-shot, string-only return
  (:export #:batch-inference)                  ; Multiple messages
  (:export #:encode-request-payload)           ; Build JSON for API
  (:export #:parse-model-response)             ; Extract text from JSON

  (:export #:build-swarm-prompt)               ; Assemble Swarm-Mind prompt

  (:export #:record-inference)                 ; Log latency + tokens
  (:export #:get-model-latency)                ; Average latency (windowed)
  (:export #:get-model-throughput)             ; Tokens per second
  (:export #:get-model-call-count)             ; Total inferences for model
  (:export #:select-best-model-for-task)       ; Load balancer
  (:export #:get-inference-stats)              ; Comprehensive stats plist
  (:export #:reset-inference-history)          ; Clear all history

  (:export #:generate-strategy-mutation)       ; AI-guided GP mutation
  (:export #:analyze-tool-findings)            ; AI analysis of tool output
  (:export #:generate-exploit-assessment)      ; Full exploitability report
  (:export #:should-mutate-p)                  ; Evolution trigger decision

  (:export #:evolve-strategy-via-ai)           ; Hook for evolution system
  (:export #:ai-guided-crossover)              ; AI-combined parent strategies
  (:export #:ai-fitness-evaluation)            ; AI-evaluated fitness score

  (:export #:build-inference-telemetry)        ; Metrics for telemetry
  (:export #:stream-inference-metrics)          ; Periodic telemetry event

  (:export #:init-inference-subsystem)         ; Startup
  (:export #:inference-status)                 ; Status plist
  (:export #:print-inference-status)           ; Formatted status display

  ;; Package documentation string (visible via (documentation 'lispmind 'package))
  (:documentation
   "LISPMIND -- Self-Healing Agentic AI Orchestrator.

The LISPMIND package (nickname MIND) exports the complete public API for
building, monitoring, and healing autonomous agent colonies in Common Lisp.

Key entry points:
  (mind:run-demo)               -- Watch the system heal itself
  (mind:start-orchestrator)     -- Launch a live orchestrator
  (mind:define-agent-type ...)  -- Create a new agent species
  (mind:list-agents)            -- See what's running

Module groups (v2.0):
  GOSSIP      -- Distributed swarm communication via ZeroMQ
  EVOLUTION   -- Genetic programming for self-improving strategies
  IMAGE-PERSIST -- SBCL image-based process resurrection
  PROFILER    -- Statistical profiling with auto-optimization

All symbols are documented.  Use (describe 'symbol) or (documentation 'symbol 'function)
for details."))
