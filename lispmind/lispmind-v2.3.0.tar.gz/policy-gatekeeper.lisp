;;;; -*- Mode: Lisp; Syntax: ANSI-Common-Lisp; Base: 10 -*-
;;;
;;; POLICY-GATEKEEPER.LISP -- Policy Enforcement + Cleanup + Network Recovery
;;;
;;; ═══════════════════════════════════════════════════════════════════════════
;;;          THE SENTINEL: TACTICAL POLICY ENFORCEMENT FOR KALI TOOLS
;;; ═══════════════════════════════════════════════════════════════════════════
;;;
;;; This module is the security kernel of LISPMIND's offensive operations
;;; surface. When an agent wants to launch a Kali tool -- nmap, metasploit,
;;; hydra, aircrack, sqlmap, john, hashcat -- it does not execute directly.
;;; It must pass through the POLICY GATEKEEPER: a multi-layer validation
;;; system that checks arguments, targets, risk levels, and concurrency
;;; limits against the TACTICAL REPOSITORY of registered policies.
;;;
;;; The module provides:
;;;   1. POLICY DEFINITION SYSTEM -- The Tactical Repository
;;;   2. POLICY VALIDATION -- The Gatekeeper (safe-strategy-p)
;;;   3. THE JANITOR -- Automated cleanup via CLOS :AFTER + sweep thread
;;;   4. NETWORK STATE CHECKPOINT -- Save/restore/monitor interfaces
;;;   5. EMERGENCY INTEGRATION -- Kill-switch + audit logging
;;;   6. KALI TOOL LAUNCHER -- Safe subprocess spawning
;;;   7. SYSTEM STATUS -- Comprehensive diagnostics
;;;   8. INITIALIZATION/SHUTDOWN -- Full lifecycle management
;;;   9. GRAY STREAMS -- Filtered output for sensitive data
;;;   10. ORCHESTRATOR INTEGRATION -- Emergency halt handler
;;;   11. CONVENIENCE API -- Shortcuts for common operations
;;;
;;; DESIGN PHILOSOPHY
;;; --
;;; "Safety is not a feature you bolt on. It is the foundation everything
;;;  else stands on. The Gatekeeper exists because one malformed nmap
;;;  command launched against the wrong subnet at 3 AM can end a career.
;;;  The Janitor exists because every leaked process is a debt that comes
;;;  due eventually. The network monitor exists because an air-gapped
;;;  Kali box that loses its bridge interface is a brick."
;;;
;;; THREAD SAFETY
;;; --
;;; All policy mutations hold *POLICY-LOCK*. The Janitor thread and
;;; network monitor thread are independently managed. The audit log
;;; is a circular buffer protected by *AUDIT-LOG-LOCK*.
;;;
;;; DEPENDENCIES
;;; --
;;;   - UIOP (portable process control)
;;;   - Bordeaux-Threads (background threads)
;;;   - CLOS MOP (:AFTER methods on finalize-agent)
;;;   - trivial-gray-streams (output filtering)
;;;
;;; "The Gatekeeper does not ask permission. It grants it."

(in-package :lispmind)


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 0: Kali-Agent Class -- Agent with Subprocess Management
;; ═══════════════════════════════════════════════════════════════════════════

(defclass kali-agent (agent)
  ((subprocess
    :initform nil
    :accessor kali-agent-subprocess
    :documentation
    "The UIOP process-info object for the running Kali tool, or NIL.
Set by the tool launcher. Cleared by the Janitor on agent death.")

   (tool-name
    :initarg :tool-name
    :initform nil
    :accessor kali-agent-tool-name
    :documentation
    "Symbol naming the tool: 'nmap, 'metasploit, 'hydra, 'aircrack,
'sqlmap, 'john, 'hashcat, etc. Used for policy lookup.")

   (tool-args
    :initarg :tool-args
    :initform nil
    :accessor kali-agent-tool-args
    :documentation
    "Validated argument list passed to the tool.
Only safe, approved args reach this slot.")

   (requested-args
    :initarg :requested-args
    :initform nil
    :accessor kali-agent-requested-args
    :documentation
    "Original argument list as requested BEFORE policy validation.
Kept for forensic analysis and audit logging.")

   (target
    :initarg :target
    :initform nil
    :accessor kali-agent-target
    :documentation
    "Target host, IP, or subnet string. Validated against FORBIDDEN-TARGETS.")

   (launch-time
    :initform nil
    :accessor kali-agent-launch-time
    :documentation
    "LOCAL-TIME timestamp when the tool was launched. NIL if not launched.")

   (policy-approved-p
    :initform nil
    :accessor kali-agent-policy-approved-p
    :documentation
    "T if the Gatekeeper approved this agent's tool invocation.")

   (output-buffer
    :initform (make-array 0 :element-type 'character :fill-pointer 0 :adjustable t)
    :accessor kali-agent-output-buffer
    :documentation
    "Adjustable string array capturing tool stdout/stderr output.")

   (risk-level
    :initarg :risk-level
    :initform :medium
    :accessor kali-agent-risk-level
    :documentation
    "Risk classification: :low, :medium, :high, or :critical.
Critical requires explicit operator confirmation.")

   (confirmation-received-p
    :initform nil
    :accessor kali-agent-confirmation-received-p
    :documentation
    "T if operator confirmation received for a high-risk operation.")

   (binary-path
    :initarg :binary-path
    :initform nil
    :accessor kali-agent-binary-path
    :documentation
    "Full filesystem path to the tool binary executable."))

  (:documentation
   "A Kali-Agent manages an external offensive security tool as a subprocess.
Lifecycle: CREATION -> VALIDATION -> LAUNCH -> MONITORING -> FINALIZATION.
The finalize-agent :AFTER method on this class kills the subprocess on death."))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 1: Policy Definition System -- The Tactical Repository
;; ═══════════════════════════════════════════════════════════════════════════

(defstruct (tool-policy
            (:constructor %make-tool-policy-internal))
  "Policy rules for a specific Kali tool.
Fields:
  - tool-name         -- Symbol: 'nmap, 'metasploit, etc.
  - forbidden-args    -- List of argument strings never allowed (e.g., \"-T5\")
  - forbidden-targets -- IP ranges/subnets off-limits (e.g., \"10.0.0.0/8\")
  - max-parallel      -- Maximum concurrent instances (default: 1)
  - timeout-seconds   -- Default timeout (default: 300)
  - output-filters    -- Regex patterns to filter from output
  - required-args     -- Args that must always be present
  - risk-level        -- :low :medium :high :critical (default: :medium)

Fail-closed: no policy means ALL invocations are blocked."
  (tool-name nil :type symbol)
  (forbidden-args nil :type list)
  (forbidden-targets nil :type list)
  (max-parallel 1 :type integer)
  (timeout-seconds 300 :type integer)
  (output-filters nil :type list)
  (required-args nil :type list)
  (risk-level :medium :type keyword))

(defun make-tool-policy (tool-name &key forbidden-args forbidden-targets
                                        max-parallel timeout-seconds
                                        output-filters required-args risk-level)
  "Constructor for TOOL-POLICY with sensible defaults.
MAX-PARALLEL defaults to 1, TIMEOUT-SECONDS to 300, RISK-LEVEL to :medium.
All list fields default to NIL."
  (%make-tool-policy-internal
   :tool-name tool-name
   :forbidden-args (or forbidden-args nil)
   :forbidden-targets (or forbidden-targets nil)
   :max-parallel (or max-parallel 1)
   :timeout-seconds (or timeout-seconds 300)
   :output-filters (or output-filters nil)
   :required-args (or required-args nil)
   :risk-level (or risk-level :medium)))

(defvar *tactical-repository* (make-hash-table :test 'eq)
  "Maps tool-name symbol to TOOL-POLICY. The Tactical Repository.
Fail-closed: tools without registered policies are BLOCKED.
All accesses protected by *POLICY-LOCK*.")

(defvar *policy-lock* (bt:make-lock "policy-lock")
  "Recursive lock protecting *TACTICAL-REPOSITORY*.")

(defvar *active-kali-agents* (make-hash-table :test 'eq)
  "Registry of active KALI-AGENT instances. Maps agent-id -> agent.
Used by Janitor, CHECK-MAX-PARALLEL, and EMERGENCY-KILL-ALL-TOOLS.
Protected by *KALI-AGENTS-LOCK*.")

(defvar *kali-agents-lock* (bt:make-lock "kali-agents-lock")
  "Lock protecting *ACTIVE-KALI-AGENTS* and *PARALLEL-INSTANCE-COUNTS*.")

(defun register-policy (tool-name policy)
  "Register a POLICY for TOOL-NAME in the Tactical Repository.
TOOL-NAME is a symbol (e.g., 'nmap). POLICY is a TOOL-POLICY.
Replaces any existing policy. Returns POLICY.
Thread-safe: acquires *POLICY-LOCK*."
  (bt:with-lock-held (*policy-lock*)
    (setf (gethash tool-name *tactical-repository*) policy))
  (policy-audit-log :register-policy t
                    (format nil "Registered policy for ~A (risk: ~A)"
                            tool-name (tool-policy-risk-level policy)))
  policy)

(defun get-policy (tool-name)
  "Get the TOOL-POLICY for TOOL-NAME, or NIL if none exists.
Thread-safe: acquires *POLICY-LOCK*."
  (bt:with-lock-held (*policy-lock*)
    (gethash tool-name *tactical-repository*)))

(defun policy-exists-p (tool-name)
  "Return T if a policy exists for TOOL-NAME. Used by Gatekeeper fail-closed check."
  (bt:with-lock-held (*policy-lock*)
    (not (null (gethash tool-name *tactical-repository*)))))

(defun unregister-policy (tool-name)
  "Remove the policy for TOOL-NAME. Returns T if a policy was removed.
After unregistering, all invocations of that tool are BLOCKED."
  (bt:with-lock-held (*policy-lock*)
    (let ((had-policy (gethash tool-name *tactical-repository*)))
      (remhash tool-name *tactical-repository*)
      (policy-audit-log :unregister-policy had-policy
                        (format nil "Unregistered policy for ~A" tool-name))
      (not (null had-policy)))))

(defun list-registered-policies ()
  "Return a list of all registered tool-name symbols. Fresh list."
  (bt:with-lock-held (*policy-lock*)
    (loop for tool-name being the hash-keys of *tactical-repository*
          collect tool-name)))

(defun describe-policy (tool-name)
  "Return a human-readable string describing the policy for TOOL-NAME.
If no policy exists, reports that all invocations are BLOCKED."
  (let ((policy (get-policy tool-name)))
    (if policy
        (format nil "Policy for ~A:~%  Risk Level: ~A~%  Max Parallel: ~D~%  Timeout: ~Ds~%  Forbidden Args: ~S~%  Forbidden Targets: ~S~%  Required Args: ~S~%  Output Filters: ~S"
                (tool-policy-tool-name policy)
                (tool-policy-risk-level policy)
                (tool-policy-max-parallel policy)
                (tool-policy-timeout-seconds policy)
                (tool-policy-forbidden-args policy)
                (tool-policy-forbidden-targets policy)
                (tool-policy-required-args policy)
                (tool-policy-output-filters policy))
        (format nil "No policy registered for ~A (all invocations BLOCKED)." tool-name))))

(defun load-default-policies ()
  "Load the default policy set into the Tactical Repository.
Registers conservative, production-safe policies for 7 common Kali tools:
  - NMAP      -- No -T5 (insane timing), no scans of 10.0.0.0/8
  - METASPLOIT -- No exploits above :medium risk without confirmation
  - HYDRA     -- No brute-force against non-test targets
  - AIRCRACK  -- Only on test interfaces (wlan1, not wlan0)
  - SQLMAP    -- No --dump-all, --os-shell, --os-pwn
  - JOHN      -- No cracking of production hash files
  - HASHCAT   -- No cracking of production hash files
Returns list of registered tool-name symbols. Idempotent."
  (let ((registered '()))
    ;; NMAP: Network discovery
    (push (tool-policy-tool-name
           (register-policy
            'nmap
            (make-tool-policy
             'nmap
             :forbidden-args '("-T5" "--script=unsafe" "--script=malware")
             :forbidden-targets '("10.0.0.0/8" "127.0.0.0/8")
             :max-parallel 4
             :timeout-seconds 600
             :required-args '("-sT")
             :risk-level :medium)))
          registered)
    ;; METASPLOIT: Exploitation framework
    (push (tool-policy-tool-name
           (register-policy
            'metasploit
            (make-tool-policy
             'metasploit
             :forbidden-args '("-j" "--exit-on-session")
             :forbidden-targets '("10.0.0.0/8")
             :max-parallel 2
             :timeout-seconds 900
             :risk-level :high)))
          registered)
    ;; HYDRA: Login cracker
    (push (tool-policy-tool-name
           (register-policy
            'hydra
            (make-tool-policy
             'hydra
             :forbidden-args '("-t64" "-w32")
             :forbidden-targets '("*.prod.*" "*.production.*")
             :max-parallel 2
             :timeout-seconds 1800
             :required-args '("-l" "testuser")
             :risk-level :high)))
          registered)
    ;; AIRCRACK: WiFi auditing
    (push (tool-policy-tool-name
           (register-policy
            'aircrack
            (make-tool-policy
             'aircrack
             :forbidden-args '("wlan0" "mon0" "--bssid")
             :forbidden-targets nil
             :max-parallel 1
             :timeout-seconds 3600
             :required-args '("-i" "wlan1")
             :risk-level :critical)))
          registered)
    ;; SQLMAP: SQL injection
    (push (tool-policy-tool-name
           (register-policy
            'sqlmap
            (make-tool-policy
             'sqlmap
             :forbidden-args '("--dump-all" "--os-shell" "--os-pwn")
             :forbidden-targets '("*.prod.*" "*.production.*")
             :max-parallel 2
             :timeout-seconds 1800
             :required-args '("--batch")
             :risk-level :high)))
          registered)
    ;; JOHN: Password cracker
    (push (tool-policy-tool-name
           (register-policy
            'john
            (make-tool-policy
             'john
             :forbidden-args '("--format=descrypt")
             :forbidden-targets '("/etc/shadow" "/etc/passwd")
             :max-parallel 2
             :timeout-seconds 3600
             :risk-level :medium)))
          registered)
    ;; HASHCAT: GPU password recovery
    (push (tool-policy-tool-name
           (register-policy
            'hashcat
            (make-tool-policy
             'hashcat
             :forbidden-args '("--force" "-O" "--backend-devices-virtual")
             :forbidden-targets '("*.prod.*" "/etc/shadow")
             :max-parallel 1
             :timeout-seconds 7200
             :risk-level :medium)))
          registered)
    (policy-audit-log :load-defaults t
                      (format nil "Loaded ~D default policies: ~S"
                              (length registered) registered))
    registered))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 2: Policy Validation -- The Gatekeeper
;; ═══════════════════════════════════════════════════════════════════════════

(defvar *max-risk-without-confirmation* :medium
  "Maximum risk level launchable WITHOUT explicit confirmation.
Default :medium means :high and :critical require confirmation.
Set to :low for maximum paranoia (everything needs confirmation).")

(defvar *parallel-instance-counts* (make-hash-table :test 'eq)
  "Tracks instance counts per tool. Maps tool-name -> integer.
Incremented on launch, decremented on finalization.
Protected by *KALI-AGENTS-LOCK*.")

(defun safe-strategy-p (agent binary args)
  "The Gatekeeper: validate a tool launch against its policy.
Single point of enforcement. Every Kali tool launch must pass through here.

Arguments:
  AGENT  -- KALI-AGENT instance
  BINARY -- Tool binary name string (e.g., \"nmap\")
  ARGS   -- List of string arguments

Validation steps (ALL must pass):
  1. Policy exists for this tool? (fail-closed)
  2. ARGS contain no forbidden arguments?
  3. All required arguments present in ARGS?
  4. Target not in forbidden-targets list?
  5. Tool's risk level acceptable?
  6. Parallel instance limits respected?

Returns (values T nil) if approved, (values nil reason) if blocked.
The REASON string is logged to the policy audit log."
  (let* ((tool-name (intern (string-upcase binary) :keyword))
         (policy (get-policy tool-name)))
    (cond
      ;; Step 1: Fail-closed -- no policy means BLOCKED
      ((null policy)
       (let ((reason (format nil "BLOCKED: No policy for tool ~A (~A). All unregistered tools blocked."
                             tool-name binary)))
         (policy-audit-log :gatekeeper-deny nil reason)
         (return-from safe-strategy-p (values nil reason))))

      ;; Step 2: Validate forbidden args
      ((not (validate-args-against-policy args policy))
       (let ((reason (format nil "BLOCKED: Forbidden arg for ~A. Args: ~S" tool-name args)))
         (policy-audit-log :gatekeeper-deny nil reason)
         (return-from safe-strategy-p (values nil reason))))

      ;; Step 3: Validate required args
      ((not (validate-required-args-present args policy))
       (let ((reason (format nil "BLOCKED: Missing required arg for ~A. Need: ~S Got: ~S"
                             tool-name (tool-policy-required-args policy) args)))
         (policy-audit-log :gatekeeper-deny nil reason)
         (return-from safe-strategy-p (values nil reason))))

      ;; Step 4: Validate target
      ((and (kali-agent-target agent)
            (not (validate-target-against-policy (kali-agent-target agent) policy)))
       (let ((reason (format nil "BLOCKED: Target '~A' forbidden for ~A."
                             (kali-agent-target agent) tool-name)))
         (policy-audit-log :gatekeeper-deny nil reason)
         (return-from safe-strategy-p (values nil reason))))

      ;; Step 5: Validate risk level
      ((not (validate-risk-level tool-name))
       (let ((reason (format nil "BLOCKED: Risk ~A for ~A exceeds max ~A."
                             (tool-policy-risk-level policy) tool-name
                             *max-risk-without-confirmation*)))
         (policy-audit-log :gatekeeper-deny nil reason)
         (return-from safe-strategy-p (values nil reason))))

      ;; Step 6: Check parallel limits
      ((not (check-max-parallel tool-name))
       (let ((reason (format nil "BLOCKED: Max parallel (~D) exceeded for ~A."
                             (tool-policy-max-parallel policy) tool-name)))
         (policy-audit-log :gatekeeper-deny nil reason)
         (return-from safe-strategy-p (values nil reason))))

      ;; All checks passed -- APPROVED
      (t
       (policy-audit-log :gatekeeper-approve t
                         (format nil "APPROVED: ~A ~{~A~^ ~}" binary args))
       (values t nil)))))

(defun validate-args-against-policy (args policy)
  "Return T if no ARGS match any forbidden pattern in POLICY.
Uses exact string match (string=), not substring search."
  (let ((forbidden (tool-policy-forbidden-args policy)))
    (not (some (lambda (arg)
                 (some (lambda (fb) (string= arg fb)) forbidden))
               args))))

(defun validate-required-args-present (args policy)
  "Return T if all REQUIRED-ARGS from POLICY are present in ARGS.
Uses prefix matching to handle attached values (e.g., \"-l testuser\")."
  (let ((required (tool-policy-required-args policy)))
    (every (lambda (req)
             (some (lambda (arg)
                     (or (string= arg req)
                         (uiop:string-prefix-p req arg)))
                   args))
           required)))

(defun validate-target-against-policy (target policy)
  "Return T if TARGET is not in any forbidden range of POLICY.
Supports CIDR notation, wildcard patterns, and exact matches."
  (let ((forbidden-targets (tool-policy-forbidden-targets policy)))
    (not (some (lambda (fb) (target-matches-p target fb)) forbidden-targets))))

(defun target-matches-p (target forbidden)
  "Check if TARGET matches FORBIDDEN pattern.
Supports CIDR (10.0.0.0/8), wildcard (*.prod.*), and exact matches."
  (cond
    ;; CIDR /8 /16 /24
    ((or (uiop:string-suffix-p forbidden "/8")
         (uiop:string-suffix-p forbidden "/16")
         (uiop:string-suffix-p forbidden "/24"))
     (let ((prefix (subseq forbidden 0 (position #\\/ forbidden))))
       (uiop:string-prefix-p prefix target)))
    ;; Wildcard patterns
    ((or (uiop:string-prefix-p forbidden "*.")
         (uiop:string-suffix-p forbidden ".*"))
     (wildcard-match-p target forbidden))
    ;; Exact match
    (t (string= target forbidden))))

(defun wildcard-match-p (string pattern)
  "Simple wildcard matching: * matches any sequence.
Examples: (wildcard-match-p \"web.prod.com\" \"*.prod.*\") => T"
  (cond
    ((string= pattern "*") t)
    ((uiop:string-prefix-p pattern "*.")
     (search (subseq pattern 2) string))
    ((uiop:string-suffix-p pattern ".*")
     (uiop:string-prefix-p string (subseq pattern 0 (- (length pattern) 2))))
    (t (string= string pattern))))

(defun validate-risk-level (tool-name)
  "Return T if the tool's risk level is acceptable for launch.
Compares against *MAX-RISK-WITHOUT-CONFIRMATION*.
Ordering: :low < :medium < :high < :critical."
  (let ((policy (get-policy tool-name)))
    (if (null policy)
        nil
        (risk-level-<= (tool-policy-risk-level policy)
                       *max-risk-without-confirmation*))))

(defun risk-level-<= (a b)
  "Compare two risk levels. Return T if A <= B."
  (let ((ordering '(:low 0 :medium 1 :high 2 :critical 3)))
    (<= (getf ordering a 999) (getf ordering b 999))))

(defun check-max-parallel (tool-name)
  "Return T if parallel instance limit not exceeded for TOOL-NAME.
Compares current count against policy MAX-PARALLEL."
  (let ((policy (get-policy tool-name)))
    (if (null policy)
        nil
        (bt:with-lock-held (*kali-agents-lock*)
          (< (gethash tool-name *parallel-instance-counts* 0)
             (tool-policy-max-parallel policy))))))

(defun confirm-high-risk-operation (agent)
  "Prompt operator for confirmation of a high-risk tool launch.
Returns T if confirmed, NIL if denied. Sets confirmation-received-p on approval."
  (format *query-io* "~&~%*** HIGH-RISK OPERATION CONFIRMATION REQUIRED ***~%")
  (format *query-io* "  Tool:   ~A~%" (kali-agent-tool-name agent))
  (format *query-io* "  Target: ~A~%" (kali-agent-target agent))
  (format *query-io* "  Risk:   ~A~%" (kali-agent-risk-level agent))
  (format *query-io* "  Args:   ~S~%" (kali-agent-requested-args agent))
  (format *query-io* "~&Confirm launch? (yes/no): ")
  (force-output *query-io*)
  (let ((response (read-line *query-io*)))
    (when (member (string-downcase (string-trim " " response))
                  '("yes" "y" "confirm")
                  :test #'string=)
      (setf (kali-agent-confirmation-received-p agent) t)
      (policy-audit-log :high-risk-confirmed t
                        (format nil "Confirmed high-risk: ~A on ~A"
                                (kali-agent-tool-name agent)
                                (kali-agent-target agent)))
      t)))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 3: The Janitor -- Automated Cleanup Finalization
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; "A process left running after its agent dies is a ghost -- invisible,
;;  unaccounted for, and dangerous. The Janitor exorcises ghosts."

(defvar *janitor-thread* nil
  "Background Janitor sweep thread, or NIL if not running.")

(defvar *janitor-running-p* nil
  "Flag controlling the Janitor sweep loop.")

(defvar *janitor-lock* (bt:make-lock "janitor-lock")
  "Lock protecting Janitor state.")

(defvar *janitor-cvar* (bt:make-condition-variable :name "janitor-cvar")
  "Condition variable for Janitor shutdown signaling.")

(defun finalize-agent (agent)
  "Generic finalization hook for agent cleanup.
Primary method is a no-op. The :AFTER method on KALI-AGENT kills subprocesses.
Also supports SB-EXT:FINALIZE for GC-triggered cleanup."
  (declare (ignore agent))
  nil)

(defmethod finalize-agent :after ((agent kali-agent))
  "Kill the subprocess when a KALI-AGENT is finalized.
Sequence:
  1. Drain remaining output
  2. SIGTERM (graceful, wait 5s)
  3. SIGKILL if still alive (forceful)
  4. Decrement parallel instance count
  5. Remove from *ACTIVE-KALI-AGENTS*
Called by Janitor sweep, explicit shutdown, and emergency kill."
  (bt:with-lock-held ((agent-lock agent))
    (let ((subprocess (kali-agent-subprocess agent)))
      (when (and subprocess (uiop:process-alive-p subprocess))
        ;; Step 1: Drain output
        (ignore-errors (drain-subprocess-output agent))
        ;; Step 2: SIGTERM graceful
        (ignore-errors (uiop:terminate-process subprocess))
        ;; Step 3: Wait up to 5 seconds
        (dotimes (i 50)
          (unless (uiop:process-alive-p subprocess)
            (return))
          (sleep 0.1))
        ;; Step 4: SIGKILL if needed
        (when (uiop:process-alive-p subprocess)
          (ignore-errors (uiop:terminate-process subprocess :urgent t)))
        ;; Log cleanup
        (policy-audit-log :janitor-cleanup t
                          (format nil "Finalized ~A (tool: ~A, target: ~A)"
                                  (agent-id agent)
                                  (kali-agent-tool-name agent)
                                  (kali-agent-target agent))))
      ;; Decrement count and remove from registry
      (when (kali-agent-tool-name agent)
        (bt:with-lock-held (*kali-agents-lock*)
          (let ((current (gethash (kali-agent-tool-name agent)
                                  *parallel-instance-counts* 0)))
            (when (> current 0)
              (decf (gethash (kali-agent-tool-name agent)
                             *parallel-instance-counts*))))))
      (bt:with-lock-held (*kali-agents-lock*)
        (remhash (agent-id agent) *active-kali-agents*))
      (setf (kali-agent-subprocess agent) nil))))

(defun drain-subprocess-output (agent)
  "Drain stdout/stderr from the agent's subprocess into output-buffer.
Non-blocking: returns immediately if no output available."
  (let ((subprocess (kali-agent-subprocess agent)))
    (when subprocess
      (ignore-errors
        (let ((stream (uiop:process-info-output subprocess)))
          (when (and stream (open-stream-p stream))
            (loop while (listen stream)
                  do (vector-push-extend (read-char stream)
                                         (kali-agent-output-buffer agent))))))
      (ignore-errors
        (let ((stream (uiop:process-info-error-output subprocess)))
          (when (and stream (open-stream-p stream))
            (loop while (listen stream)
                  do (vector-push-extend (read-char stream)
                                         (kali-agent-output-buffer agent)))))))))

(defun janitor-sweep ()
  "Sweep all Kali agents. Kill subprocesses of dead agents (ghosts),
mark agents with dead subprocesses as :FAILED (zombies), and kill
runaway processes exceeding timeout.

Returns a plist:
  :agents-checked   -- total agents examined
  :ghosts-killed    -- subprocesses killed for dead agents
  :zombies-detected -- agents whose subprocess exited unexpectedly
  :runaways-stopped -- processes killed for exceeding timeout"
  (let ((stats (list :agents-checked 0 :ghosts-killed 0
                     :zombies-detected 0 :runaways-stopped 0)))
    (bt:with-lock-held (*kali-agents-lock*)
      (maphash
       (lambda (agent-id agent)
         (declare (ignore agent-id))
         (incf (getf stats :agents-checked))
         (let ((alive (agent-alive-p agent))
               (subprocess (kali-agent-subprocess agent))
               (subprocess-alive (and (kali-agent-subprocess agent)
                                      (uiop:process-alive-p
                                       (kali-agent-subprocess agent))))
               (timed-out
                 (and (kali-agent-launch-time agent)
                      (kali-agent-policy-approved-p agent)
                      (> (local-time:timestamp-difference
                          (local-time:now)
                          (kali-agent-launch-time agent))
                         (let ((policy (get-policy (kali-agent-tool-name agent))))
                           (if policy (tool-policy-timeout-seconds policy) 300))))))
           (cond
             ;; Dead agent + living subprocess = GHOST
             ((and (not alive) subprocess-alive)
              (finalize-agent agent)
              (incf (getf stats :ghosts-killed)))
             ;; Alive agent + dead subprocess = ZOMBIE
             ((and alive subprocess (not subprocess-alive))
              (setf (agent-status agent) :failed)
              (incf (getf stats :zombies-detected)))
             ;; Runaway process (exceeded timeout)
             ((and alive subprocess-alive timed-out)
              (finalize-agent agent)
              (setf (agent-status agent) :failed)
              (incf (getf stats :runaways-stopped))
              (policy-audit-log :runaway-killed t
                                (format nil "Killed runaway ~A after timeout"
                                        (agent-id agent)))))))
       *active-kali-agents*))
    stats))

(defun start-janitor-thread (&optional (interval 5))
  "Start a background thread that sweeps every INTERVAL seconds.
INTERVAL default is 5 seconds. Returns the Janitor thread.
If already running, returns existing thread. Thread-safe."
  (bt:with-lock-held (*janitor-lock*)
    (if (and *janitor-thread* (bt:thread-alive-p *janitor-thread*))
        *janitor-thread*
        (progn
          (setf *janitor-running-p* t)
          (setf *janitor-thread*
                (bt:make-thread
                 (lambda () (janitor-loop interval))
                 :name "lispmind-janitor"
                 :initial-bindings `((*standard-output* . ,*standard-output*)
                                     (*error-output*    . ,*error-output*))))
          (policy-audit-log :janitor-started t
                            (format nil "Janitor started (interval: ~Ds)" interval))
          *janitor-thread*))))

(defun stop-janitor-thread ()
  "Stop the Janitor thread gracefully. Signals via *JANITOR-CVAR*,
waits up to 10s, force-destroys if needed. Returns T if stopped."
  (bt:with-lock-held (*janitor-lock*)
    (when *janitor-running-p*
      (setf *janitor-running-p* nil)
      (bt:condition-notify *janitor-cvar*)
      (when (and *janitor-thread* (bt:thread-alive-p *janitor-thread*))
        (dotimes (i 100)
          (unless (bt:thread-alive-p *janitor-thread*)
            (return))
          (sleep 0.1))
        (when (bt:thread-alive-p *janitor-thread*)
          (ignore-errors (bt:destroy-thread *janitor-thread*))))
      (setf *janitor-thread* nil)
      (policy-audit-log :janitor-stopped t "Janitor stopped")
      t)))

(defun janitor-loop (interval)
  "The Janitor sweep loop. Runs until *JANITOR-RUNNING-P* becomes NIL.
Error handling: catches ALL conditions and continues. A dead Janitor
is worse than a noisy log."
  (loop while *janitor-running-p* do
    (handler-case
        (progn
          (bt:with-lock-held (*janitor-lock*)
            (unless *janitor-running-p* (return))
            (bt:condition-wait *janitor-cvar* *janitor-lock*
                               :timeout interval))
          (when *janitor-running-p*
            (let ((stats (janitor-sweep)))
              (when (or (> (getf stats :ghosts-killed) 0)
                        (> (getf stats :runaways-stopped) 0))
                (policy-audit-log :janitor-sweep t
                                  (format nil "Sweep: ~D checked, ~D ghosts, ~D zombies, ~D runaways"
                                          (getf stats :agents-checked)
                                          (getf stats :ghosts-killed)
                                          (getf stats :zombies-detected)
                                          (getf stats :runaways-stopped)))))))
      (error (e)
        (format *error-output* "~&[JANITOR ERROR] ~A~%" e)
        (policy-audit-log :janitor-error nil (format nil "Janitor error: ~A" e)))
      (condition (c)
        (format *error-output* "~&[JANITOR CONDITION] ~A~%" c)
        (policy-audit-log :janitor-condition nil (format nil "Janitor condition: ~A" c))))))

(defun janitor-status ()
  "Return Janitor subsystem status as a plist:
  :running-p, :thread-alive-p, :active-agents, :parallel-counts"
  (let ((agent-count 0)
        (counts-copy (make-hash-table :test 'eq)))
    (bt:with-lock-held (*kali-agents-lock*)
      (setf agent-count (hash-table-count *active-kali-agents*))
      (maphash (lambda (k v) (setf (gethash k counts-copy) v))
               *parallel-instance-counts*))
    (list :running-p *janitor-running-p*
          :thread-alive-p (and *janitor-thread*
                               (bt:thread-alive-p *janitor-thread*))
          :active-agents agent-count
          :parallel-counts counts-copy)))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 4: Network State Checkpoint -- Save/Restore/Monitor
;; ═══════════════════════════════════════════════════════════════════════════

(defvar *network-state-checkpoint* nil
  "Saved network interface state as a plist:
  :timestamp    -- local-time timestamp
  :interfaces   -- list of (:name :state :ip-address :mac-address)
  :routes       -- list of route strings
  :primary-link -- name of primary interface")

(defvar *network-monitor-thread* nil)
(defvar *network-monitor-running-p* nil)
(defvar *network-monitor-lock* (bt:make-lock "network-monitor-lock"))
(defvar *network-monitor-cvar* (bt:make-condition-variable :name "network-monitor-cvar"))

(defun save-network-state ()
  "Save current network interface configuration.
Captures interface names, states, IPs, MACs, routes, and primary link
from /sys/class/net/ and iproute2. Returns checkpoint plist.
Non-Linux systems get empty checkpoint (no error)."
  (let ((interfaces '()) (routes '()) (primary-link nil))
    (ignore-errors
      (dolist (iface-dir (uiop:subdirectories #P"/sys/class/net/"))
        (let* ((iface-name (car (last (pathname-directory iface-dir))))
               (state-file (merge-pathnames "operstate" iface-dir))
               (address-file (merge-pathnames "address" iface-dir))
               (state "unknown") (mac "unknown") (ip nil))
          (when (probe-file state-file)
            (with-open-file (s state-file :direction :input)
              (setf state (string-trim '(#\\newline #\\space #\\tab)
                                       (read-line s nil "unknown")))))
          (when (probe-file address-file)
            (with-open-file (s address-file :direction :input)
              (setf mac (string-trim '(#\\newline #\\space #\\tab)
                                     (read-line s nil "unknown")))))
          (ignore-errors
            (let ((ip-output (uiop:run-program
                              (format nil "ip -4 addr show ~A 2>/dev/null" iface-name)
                              :output '(:string :stripped t)
                              :ignore-error-status t)))
              (when (and ip-output (> (length ip-output) 0))
                (let ((start (search "inet " ip-output)))
                  (when start
                    (let ((addr-start (+ start 5)))
                      (let ((addr-end (position #\\/ ip-output :start addr-start)))
                        (when addr-end
                          (setf ip (subseq ip-output addr-start addr-end))))))))))
          (when (and (string= state "up") (not (string= iface-name "lo"))
                     (null primary-link))
            (setf primary-link iface-name))
          (push (list :name iface-name :state state :ip-address ip
                      :mac-address mac)
                interfaces))))
    (ignore-errors
      (let ((route-output (uiop:run-program "ip route show 2>/dev/null"
                                            :output '(:string :stripped t)
                                            :ignore-error-status t)))
        (when (and route-output (> (length route-output) 0))
          (setf routes (uiop:split-string route-output :separator '(#\\newline))))))
    (setf *network-state-checkpoint*
          (list :timestamp (local-time:now)
                :interfaces interfaces
                :routes routes
                :primary-link primary-link))
    (policy-audit-log :network-checkpoint t
                      (format nil "Saved network state: ~D interfaces, primary: ~A"
                              (length interfaces) primary-link))
    *network-state-checkpoint*))

(defun restore-network-state ()
  "Restore network interfaces from *NETWORK-STATE-CHECKPOINT*.
Attempts to restore each interface to its saved state and IP.
Returns T if attempted, NIL if no checkpoint exists.
Note: requires root privileges for iproute2 commands."
  (if (null *network-state-checkpoint*)
      (progn (warn "No network checkpoint. Call SAVE-NETWORK-STATE first.") nil)
      (let ((interfaces (getf *network-state-checkpoint* :interfaces))
            (restored 0) (failed 0))
        (dolist (iface interfaces)
          (let ((name (getf iface :name))
                (state (getf iface :state))
                (ip (getf iface :ip-address)))
            (handler-case
                (progn
                  (uiop:run-program
                   (format nil "ip link set ~A ~A 2>/dev/null"
                           name (if (string= state "up") "up" "down"))
                   :ignore-error-status t)
                  (when ip
                    (uiop:run-program
                     (format nil "ip addr add ~A dev ~A 2>/dev/null" ip name)
                     :ignore-error-status t))
                  (incf restored))
              (error (e)
                (incf failed)
                (format *error-output* "~&[NETWORK-RESTORE] Failed ~A: ~A~%" name e)))))
        (policy-audit-log :network-restore t
                          (format nil "Restored ~D interfaces (~D failed)" restored failed))
        t)))

(defun check-network-link ()
  "Check if primary network link is up. Returns plist:
  :link-up, :interface, :ip-address, :carrier
Uses /sys/class/net/ on Linux."
  (let ((primary (or (getf *network-state-checkpoint* :primary-link) "eth0"))
        (link-up nil) (ip-address nil) (carrier nil))
    (ignore-errors
      (let ((state-file (format nil "/sys/class/net/~A/operstate" primary)))
        (when (probe-file state-file)
          (with-open-file (s state-file :direction :input)
            (let ((state (string-trim '(#\\newline #\\space #\\tab)
                                      (read-line s nil "down"))))
              (setf link-up (string= state "up"))))))
      (let ((carrier-file (format nil "/sys/class/net/~A/carrier" primary)))
        (when (probe-file carrier-file)
          (with-open-file (s carrier-file :direction :input)
            (let ((val (read-line s nil "0")))
              (setf carrier (string= (string-trim '(#\\newline) val) "1"))))))
      (let ((ip-output (uiop:run-program
                        (format nil "ip -4 addr show ~A 2>/dev/null" primary)
                        :output '(:string :stripped t)
                        :ignore-error-status t)))
        (when (and ip-output (> (length ip-output) 0))
          (let ((start (search "inet " ip-output)))
            (when start
              (let* ((addr-start (+ start 5))
                     (addr-end (or (position #\\/ ip-output :start addr-start)
                                   (position #\\space ip-output :start addr-start))))
                (when addr-end
                  (setf ip-address (subseq ip-output addr-start addr-end))))))))
    (list :link-up (and link-up carrier)
          :interface primary
          :ip-address ip-address
          :carrier carrier))))

(defun handle-unexpected-link-loss ()
  "Recovery action for network link loss. Restores network state from checkpoint.
Returns plist: :link-lost-detected, :restoration-attempted,
:restoration-successful, :action-taken"
  (let ((status (check-network-link)) (restored nil) (success nil))
    (if (getf status :link-up)
        (list :link-lost-detected nil
              :restoration-attempted nil
              :restoration-successful t
              :action-taken "Link is up -- no action needed")
        (progn
          (policy-audit-log :link-loss-detected t
                            (format nil "Link loss on ~A" (getf status :interface)))
          (setf restored (restore-network-state))
          (sleep 2)
          (let ((new-status (check-network-link)))
            (setf success (getf new-status :link-up))
            (policy-audit-log :link-loss-recovery success
                              (format nil "Link recovery on ~A: ~A"
                                      (getf new-status :interface)
                                      (if success "SUCCESS" "FAILED")))
            (list :link-lost-detected t
                  :restoration-attempted restored
                  :restoration-successful success
                  :action-taken (if success
                                    "Network state restored"
                                    "Restoration attempted but link still down")))))))

(defun start-network-monitor (&optional (interval 10))
  "Start a background thread monitoring network link state.
Checks primary link every INTERVAL seconds (default: 10).
Restores from checkpoint on unexpected link loss.
Returns monitor thread. If running, returns existing thread."
  (bt:with-lock-held (*network-monitor-lock*)
    (if (and *network-monitor-thread*
             (bt:thread-alive-p *network-monitor-thread*))
        *network-monitor-thread*
        (progn
          (unless *network-state-checkpoint* (save-network-state))
          (setf *network-monitor-running-p* t)
          (setf *network-monitor-thread*
                (bt:make-thread
                 (lambda () (network-monitor-loop interval))
                 :name "lispmind-network-monitor"
                 :initial-bindings `((*standard-output* . ,*standard-output*)
                                     (*error-output*    . ,*error-output*))))
          (policy-audit-log :network-monitor-started t
                            (format nil "Network monitor started (interval: ~Ds)" interval))
          *network-monitor-thread*))))

(defun stop-network-monitor ()
  "Stop the network monitor thread gracefully. Returns T if stopped."
  (bt:with-lock-held (*network-monitor-lock*)
    (when *network-monitor-running-p*
      (setf *network-monitor-running-p* nil)
      (bt:condition-notify *network-monitor-cvar*)
      (when (and *network-monitor-thread*
                 (bt:thread-alive-p *network-monitor-thread*))
        (dotimes (i 100)
          (unless (bt:thread-alive-p *network-monitor-thread*)
            (return))
          (sleep 0.1))
        (when (bt:thread-alive-p *network-monitor-thread*)
          (ignore-errors (bt:destroy-thread *network-monitor-thread*))))
      (setf *network-monitor-thread* nil)
      (policy-audit-log :network-monitor-stopped t "Network monitor stopped")
      t)))

(defun network-monitor-loop (interval)
  "Network monitor loop. Checks link state periodically.
Restores from checkpoint on unexpected loss. Catches ALL errors.
A crashed monitor means undetected link loss -- never let it die."
  (loop while *network-monitor-running-p* do
    (handler-case
        (progn
          (bt:with-lock-held (*network-monitor-lock*)
            (unless *network-monitor-running-p* (return))
            (bt:condition-wait *network-monitor-cvar* *network-monitor-lock*
                               :timeout interval))
          (when *network-monitor-running-p*
            (let ((status (check-network-link)))
              (unless (getf status :link-up)
                (handle-unexpected-link-loss)))))
      (error (e)
        (format *error-output* "~&[NETWORK-MONITOR ERROR] ~A~%" e)
        (policy-audit-log :network-monitor-error nil (format nil "~A" e)))
      (condition (c)
        (format *error-output* "~&[NETWORK-MONITOR CONDITION] ~A~%" c)
        (policy-audit-log :network-monitor-condition nil (format nil "~A" c))))))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 5: Emergency Integration -- Kill-Switch and Audit
;; ═══════════════════════════════════════════════════════════════════════════

(defvar *policy-audit-log* (make-array 1000 :fill-pointer 0 :adjustable t
                                       :element-type 'list)
  "Circular buffer of policy decisions. Each entry is a plist:
  :timestamp  -- local-time timestamp
  :action     -- keyword (:gatekeeper-approve, :janitor-sweep, etc.)
  :result     -- T or NIL
  :reason     -- human-readable string
Holds up to 1000 entries (FIFO). Protected by *AUDIT-LOG-LOCK*.")

(defvar *audit-log-lock* (bt:make-lock "audit-log-lock")
  "Lock protecting *POLICY-AUDIT-LOG*.")

(defvar *audit-log-max-entries* 1000
  "Maximum audit log entries before old ones are dropped.")

(defun policy-audit-log (action result &optional reason)
  "Log a policy decision to the audit system.
ACTION: keyword naming the action.
RESULT: T or NIL.
REASON: optional human-readable string.
Thread-safe. Also forwards to telemetry system if active."
  (bt:with-lock-held (*audit-log-lock*)
    (when (>= (fill-pointer *policy-audit-log*) *audit-log-max-entries*)
      (replace *policy-audit-log* *policy-audit-log*
               :start1 0 :start2 1
               :end2 (fill-pointer *policy-audit-log*))
      (decf (fill-pointer *policy-audit-log*)))
    (vector-push (list :timestamp (local-time:now)
                       :action action
                       :result result
                       :reason (or reason ""))
                 *policy-audit-log*))
  ;; Forward to telemetry if available
  (ignore-errors
    (when (and (boundp '*telemetry-enabled-p*) *telemetry-enabled-p*)
      nil)))

(defun get-policy-audit (&optional (max-entries 100))
  "Return the most recent MAX-ENTRIES audit log entries.
Returns fresh list of plists, newest first. Each plist has
:timestamp, :action, :result, :reason."
  (bt:with-lock-held (*audit-log-lock*)
    (let ((start (max 0 (- (fill-pointer *policy-audit-log*) max-entries)))
          (result '()))
      (loop for i from (1- (fill-pointer *policy-audit-log*)) downto start
            do (push (aref *policy-audit-log* i) result))
      (nreverse result))))

(defun get-policy-audit-by-action (action &optional (max-entries 50))
  "Return audit entries filtered by ACTION keyword.
Useful for finding all denials, all cleanups, etc."
  (bt:with-lock-held (*audit-log-lock*)
    (let ((result '()) (count 0))
      (loop for i from (1- (fill-pointer *policy-audit-log*)) downto 0
            while (< count max-entries)
            do (let ((entry (aref *policy-audit-log* i)))
                 (when (eq (getf entry :action) action)
                   (push entry result)
                   (incf count))))
      (nreverse result))))

(defun clear-policy-audit ()
  "Clear all audit log entries. Returns number cleared.
Use with caution -- destroys forensic trail."
  (bt:with-lock-held (*audit-log-lock*)
    (let ((count (fill-pointer *policy-audit-log*)))
      (setf (fill-pointer *policy-audit-log*) 0)
      (policy-audit-log :audit-cleared t (format nil "Cleared ~D entries" count))
      count)))

(defun emergency-kill-all-tools (orchestrator)
  "Kill all Kali tool subprocesses during emergency halt (NUCLEAR OPTION).
Steps:
  1. Stop Janitor thread
  2. Stop network monitor
  3. For each KALI-AGENT with running subprocess: SIGKILL
  4. Clear *ACTIVE-KALI-AGENTS* and *PARALLEL-INSTANCE-COUNTS*
  5. Log to audit

Returns plist: :killed-count, :agents-affected, :errors.
Every error is caught and logged -- never propagated."
  (let ((killed-count 0) (agents-affected '()) (errors '()))
    (ignore-errors (stop-janitor-thread))
    (ignore-errors (stop-network-monitor))
    (bt:with-lock-held (*kali-agents-lock*)
      (maphash
       (lambda (agent-id agent)
         (handler-case
             (progn
               (bt:with-lock-held ((agent-lock agent))
                 (let ((subprocess (kali-agent-subprocess agent)))
                   (when (and subprocess (uiop:process-alive-p subprocess))
                     (uiop:terminate-process subprocess :urgent t)
                     (incf killed-count)
                     (push agent-id agents-affected)
                     (setf (agent-status agent) :failed)
                     (setf (kali-agent-subprocess agent) nil)))))
           (error (e)
             (push (cons agent-id (format nil "~A" e)) errors)
             (format *error-output* "~&[EMERGENCY-KILL] Failed ~A: ~A~%" agent-id e))
           (condition (c)
             (push (cons agent-id (format nil "~A" c)) errors)
             (format *error-output* "~&[EMERGENCY-KILL] Condition ~A: ~A~%" agent-id c)))
         (remhash agent-id *active-kali-agents*))
       *active-kali-agents*)
      (clrhash *parallel-instance-counts*))
    (policy-audit-log :emergency-kill t
                      (format nil "EMERGENCY HALT: Killed ~D subprocesses (~D errors)"
                              killed-count (length errors)))
    (list :killed-count killed-count
          :agents-affected (nreverse agents-affected)
          :errors errors)))

(defun register-kali-agent (orchestrator agent)
  "Register a KALI-AGENT with orchestrator and active Kali registry.
Increments parallel instance count for the tool.
Returns agent-id."
  (let ((agent-id (agent-id agent)))
    (register-agent orchestrator agent)
    (bt:with-lock-held (*kali-agents-lock*)
      (setf (gethash agent-id *active-kali-agents*) agent)
      (when (kali-agent-tool-name agent)
        (incf (gethash (kali-agent-tool-name agent)
                       *parallel-instance-counts* 0))))
    (policy-audit-log :kali-agent-registered t
                      (format nil "Registered Kali agent ~A (tool: ~A)"
                              agent-id (kali-agent-tool-name agent)))
    agent-id))

(defun deregister-kali-agent (orchestrator agent-id)
  "Deregister a KALI-AGENT. Kills subprocess, removes from registries,
decrements instance count. Returns T if found, NIL otherwise."
  (let ((agent (gethash agent-id (orchestrator-agents orchestrator))))
    (when agent
      (finalize-agent agent)
      (deregister-agent orchestrator agent-id)
      (bt:with-lock-held (*kali-agents-lock*)
        (remhash agent-id *active-kali-agents*)
        (when (and (typep agent 'kali-agent) (kali-agent-tool-name agent))
          (let ((current (gethash (kali-agent-tool-name agent)
                                  *parallel-instance-counts* 0)))
            (when (> current 0)
              (decf (gethash (kali-agent-tool-name agent)
                             *parallel-instance-counts*))))))
      (policy-audit-log :kali-agent-deregistered t
                        (format nil "Deregistered Kali agent ~A" agent-id))
      t)))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 6: Kali Tool Launcher -- Safe Subprocess Spawning
;; ═══════════════════════════════════════════════════════════════════════════

(defun launch-kali-tool (orchestrator tool-name binary args
                          &key target (risk-level nil))
  "Safely launch a Kali tool with full policy enforcement. MAIN ENTRY POINT.
Complete launch sequence:
  1. Create KALI-AGENT instance
  2. Validate via SAFE-STRATEGY-P (the Gatekeeper)
  3. If blocked, return rejection reason
  4. If high-risk, prompt for operator confirmation
  5. Spawn subprocess via UIOP:LAUNCH-PROGRAM
  6. Register agent with orchestrator
  7. Return agent on success

Returns (values agent nil) on success, (values nil reason) on failure."
  (let* ((agent (make-instance 'kali-agent
                               :tool-name tool-name
                               :tool-args args
                               :requested-args (copy-list args)
                               :target target
                               :binary-path binary
                               :risk-level (or risk-level
                                               (let ((p (get-policy tool-name)))
                                                 (if p (tool-policy-risk-level p) :medium)))
                               :capabilities (list :kali-tool tool-name)))
         (approved (safe-strategy-p agent binary args)))
    ;; Handle rejection
    (unless approved
      (setf (agent-status agent) :rejected)
      (return-from launch-kali-tool
        (values nil (format nil "Gatekeeper rejected: ~S" args))))
    ;; High-risk confirmation
    (when (and (not (validate-risk-level tool-name))
               (not (kali-agent-confirmation-received-p agent)))
      (unless (confirm-high-risk-operation agent)
        (setf (agent-status agent) :rejected)
        (policy-audit-log :high-risk-denied nil
                          (format nil "High-risk ~A on ~A denied" tool-name target))
        (return-from launch-kali-tool
          (values nil "High-risk operation denied by operator"))))
    ;; Spawn subprocess
    (handler-case
        (let ((subprocess (uiop:launch-program
                           (cons binary args)
                           :output :stream
                           :error-output :stream
                           :wait nil)))
          (setf (kali-agent-subprocess agent) subprocess)
          (setf (kali-agent-policy-approved-p agent) t)
          (setf (kali-agent-launch-time agent) (local-time:now)))
      (error (e)
        (setf (agent-status agent) :failed)
        (policy-audit-log :launch-failed nil (format nil "Spawn failed: ~A" e))
        (return-from launch-kali-tool
          (values nil (format nil "Subprocess spawn failed: ~A" e)))))
    ;; Register and return
    (register-kali-agent orchestrator agent)
    (policy-audit-log :tool-launched t
                      (format nil "Launched ~A (PID: ~A) target: ~A"
                              tool-name
                              (ignore-errors
                                (uiop:process-info-pid
                                 (kali-agent-subprocess agent)))
                              target))
    (values agent nil)))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 7: System Status -- Comprehensive Diagnostics
;; ═══════════════════════════════════════════════════════════════════════════

(defun gatekeeper-status ()
  "Return comprehensive Gatekeeper subsystem status as a plist:
  :policies-loaded, :policy-names, :max-risk, :janitor-running,
  :network-monitor, :active-agents, :parallel-counts,
  :network-checkpoint, :audit-log-entries, :last-denial"
  (let ((policy-count 0) (policy-names '()))
    (bt:with-lock-held (*policy-lock*)
      (maphash (lambda (k v) (declare (ignore v))
                 (incf policy-count) (push k policy-names))
               *tactical-repository*))
    (list :policies-loaded policy-count
          :policy-names (sort policy-names #'string< :key #'symbol-name)
          :max-risk *max-risk-without-confirmation*
          :janitor-running (and *janitor-thread*
                                (bt:thread-alive-p *janitor-thread*))
          :network-monitor (and *network-monitor-thread*
                                (bt:thread-alive-p *network-monitor-thread*))
          :active-agents (hash-table-count *active-kali-agents*)
          :parallel-counts (let ((ht (make-hash-table :test 'eq)))
                              (maphash (lambda (k v) (setf (gethash k ht) v))
                                       *parallel-instance-counts*)
                              ht)
          :network-checkpoint (not (null *network-state-checkpoint*))
          :audit-log-entries (fill-pointer *policy-audit-log*)
          :last-denial (car (get-policy-audit-by-action :gatekeeper-deny 1)))))

(defun print-gatekeeper-report ()
  "Print human-readable Gatekeeper status report to *STANDARD-OUTPUT*."
  (let ((status (gatekeeper-status)))
    (format t "~&*** LISPMIND POLICY GATEKEEPER STATUS REPORT ***~%")
    (format t "  Policies Loaded:   ~A~%" (getf status :policies-loaded))
    (format t "  Registered Tools:  ~A~%" (getf status :policy-names))
    (format t "  Max Risk Level:    ~A~%" (getf status :max-risk))
    (format t "  Janitor Running:   ~A~%" (getf status :janitor-running))
    (format t "  Network Monitor:   ~A~%" (getf status :network-monitor))
    (format t "  Active Agents:     ~A~%" (getf status :active-agents))
    (format t "  Network Checkpoint: ~A~%" (getf status :network-checkpoint))
    (format t "  Audit Entries:     ~A~%" (getf status :audit-log-entries))
    (when (getf status :last-denial)
      (format t "  Last Denial:       ~A~%"
              (getf (getf status :last-denial) :reason)))
    (format t "*** END GATEKEEPER REPORT ***~%")))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 8: Initialization and Shutdown
;; ═══════════════════════════════════════════════════════════════════════════

(defun initialize-gatekeeper ()
  "Initialize the entire Gatekeeper subsystem at system startup:
  1. Load default security policies
  2. Save initial network checkpoint
  3. Start Janitor thread (5s interval)
  4. Start network monitor (10s interval)
Returns plist: :policies-loaded, :janitor-started,
:network-monitor-started, :checkpoint-saved, :status"
  (let ((policies (load-default-policies))
        (janitor (start-janitor-thread 5))
        (network-checkpoint (save-network-state))
        (network-monitor (start-network-monitor 10)))
    (policy-audit-log :gatekeeper-initialized t
                      (format nil "Initialized: ~D policies, janitor=~A, monitor=~A"
                              (length policies)
                              (if janitor "running" "failed")
                              (if network-monitor "running" "failed")))
    (list :policies-loaded (length policies)
          :janitor-started (not (null janitor))
          :network-monitor-started (not (null network-monitor))
          :checkpoint-saved (not (null network-checkpoint))
          :status :ready)))

(defun shutdown-gatekeeper ()
  "Gracefully shut down the Gatekeeper subsystem:
  1. Stop Janitor
  2. Stop network monitor
  3. Kill all remaining subprocesses
  4. Clear registries
Returns T."
  (stop-janitor-thread)
  (stop-network-monitor)
  (bt:with-lock-held (*kali-agents-lock*)
    (maphash
     (lambda (agent-id agent)
       (declare (ignore agent-id))
       (ignore-errors
         (let ((subprocess (kali-agent-subprocess agent)))
           (when (and subprocess (uiop:process-alive-p subprocess))
             (uiop:terminate-process subprocess :urgent t)))))
     *active-kali-agents*)
    (clrhash *active-kali-agents*)
    (clrhash *parallel-instance-counts*))
  (policy-audit-log :gatekeeper-shutdown t "Gatekeeper subsystem shut down")
  t)


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 9: Gray Streams Integration -- Filtered Output
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; "Output filtering prevents sensitive data (passwords, PII, internal IPs)
;;  from being stored in log files where it becomes a liability."

(defclass filtered-output-stream (trivial-gray-streams:fundamental-character-output-stream)
  ((agent
    :initarg :agent
    :accessor filtered-stream-agent
    :documentation "The KALI-AGENT whose output is being filtered.")
   (underlying-stream
    :initarg :underlying-stream
    :accessor filtered-stream-underlying
    :documentation "The actual output stream.")
   (buffer
    :initform (make-array 256 :element-type 'character :fill-pointer 0 :adjustable t)
    :accessor filtered-stream-buffer
    :documentation "Buffer accumulating characters until newline."))
  (:documentation
   "Gray stream that filters tool output line-by-line.
Each line is checked against the agent's OUTPUT-FILTERS policy.
Matching lines are discarded instead of written to the underlying stream."))

(defmethod trivial-gray-streams:stream-write-char
    ((stream filtered-output-stream) char)
  "Buffer characters until newline, then flush filtered line."
  (if (char= char #\\newline)
      (flush-filtered-line stream)
      (vector-push-extend char (filtered-stream-buffer stream))))

(defmethod trivial-gray-streams:stream-write-string
    ((stream filtered-output-stream) string &optional (start 0) (end nil))
  "Write string to filtered stream, filtering line-by-line."
  (let ((end (or end (length string))))
    (loop for i from start below end
          do (trivial-gray-streams:stream-write-char stream (char string i)))))

(defmethod trivial-gray-streams:stream-finish-output
    ((stream filtered-output-stream))
  "Flush any pending buffered output."
  (when (> (length (filtered-stream-buffer stream)) 0)
    (flush-filtered-line stream))
  (finish-output (filtered-stream-underlying stream)))

(defun flush-filtered-line (stream)
  "Flush buffered line, applying output filters from agent policy.
If a filter matches, write [FILTERED] marker. Otherwise write line."
  (let* ((agent (filtered-stream-agent stream))
         (line (coerce (filtered-stream-buffer stream) 'string))
         (policy (when agent (get-policy (kali-agent-tool-name agent))))
         (filters (when policy (tool-policy-output-filters policy)))
         (filtered-p nil))
    (dolist (pattern filters)
      (when (and (> (length pattern) 0) (search pattern line))
        (setf filtered-p t)
        (return)))
    (if filtered-p
        (write-line "[FILTERED -- output matched policy filter]"
                    (filtered-stream-underlying stream))
        (write-line line (filtered-stream-underlying stream)))
    (setf (fill-pointer (filtered-stream-buffer stream)) 0)))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 10: Integration with Orchestrator Emergency System
;; ═══════════════════════════════════════════════════════════════════════════

(defmethod handle-condition :after ((agent orchestrator) (condition emergency-halt))
  "Emergency halt handler: kill all Kali tool subprocesses.
When orchestrator handles EMERGENCY-HALT, this :AFTER method invokes
EMERGENCY-KILL-ALL-TOOLS. Ensures the nuclear option terminates all
dangerous subprocesses -- not just agent threads."
  (format *error-output* "~&[GATEKEEPER] Emergency halt -- killing all tool subprocesses...~%")
  (let ((result (emergency-kill-all-tools agent)))
    (format *error-output* "~&[GATEKEEPER] Killed ~D subprocesses (~D errors)~%"
            (getf result :killed-count)
            (length (getf result :errors)))
    result))


;; ═══════════════════════════════════════════════════════════════════════════
;; Section 11: Convenience API -- Shortcuts for Common Operations
;; ═══════════════════════════════════════════════════════════════════════════

(defun kill-agent-tool (agent)
  "Kill the tool subprocess for a specific KALI-AGENT.
Calls FINALIZE-AGENT. Returns T if subprocess was killed."
  (when (and (typep agent 'kali-agent)
             (kali-agent-subprocess agent)
             (uiop:process-alive-p (kali-agent-subprocess agent)))
    (finalize-agent agent)
    t))

(defun list-active-kali-tools ()
  "Return list of plists for all active Kali tool instances:
  :agent-id, :tool-name, :target, :pid, :launch-time, :elapsed"
  (bt:with-lock-held (*kali-agents-lock*)
    (let ((result '()))
      (maphash
       (lambda (agent-id agent)
         (push (list :agent-id agent-id
                     :tool-name (kali-agent-tool-name agent)
                     :target (kali-agent-target agent)
                     :pid (ignore-errors
                           (uiop:process-info-pid
                            (kali-agent-subprocess agent)))
                     :launch-time (kali-agent-launch-time agent)
                     :elapsed (if (kali-agent-launch-time agent)
                                  (local-time:timestamp-difference
                                   (local-time:now)
                                   (kali-agent-launch-time agent))
                                  nil))
               result))
       *active-kali-agents*)
      (nreverse result))))

(defun get-agent-output (agent)
  "Drain and return accumulated output from a KALI-AGENT's tool.
Returns NIL if no subprocess or stream is closed."
  (when (typep agent 'kali-agent)
    (drain-subprocess-output agent)
    (coerce (kali-agent-output-buffer agent) 'string)))

(defun wait-for-agent (agent &optional (timeout-seconds 300))
  "Block until KALI-AGENT's subprocess exits or timeout.
Polls every 0.1s. Returns exit code or :TIMEOUT.
Blocking -- do not call from monitor thread."
  (let ((start (get-universal-time)))
    (loop
      (let ((subprocess (kali-agent-subprocess agent)))
        (unless (and subprocess (uiop:process-alive-p subprocess))
          (return-from wait-for-agent
            (ignore-errors (uiop:wait-process subprocess))))
        (when (> (- (get-universal-time) start) timeout-seconds)
          (return-from wait-for-agent :timeout))
        (sleep 0.1)))))


;; ═══════════════════════════════════════════════════════════════════════════
;; CLOSING: Export Summary
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; Symbols defined in this file:
;;
;; CLASSES:
;;   kali-agent              -- Agent with subprocess management
;;   filtered-output-stream  -- Gray stream with output filtering
;;
;; STRUCTS:
;;   tool-policy             -- Policy rules for a Kali tool
;;
;; SPECIAL VARIABLES:
;;   *tactical-repository*           -- Tool policy registry
;;   *max-risk-without-confirmation*  -- Risk threshold
;;   *network-state-checkpoint*      -- Saved network state
;;   *active-kali-agents*            -- Active agent registry
;;   *policy-lock*                   -- Repository lock
;;   *kali-agents-lock*              -- Agent registry lock
;;   *parallel-instance-counts*      -- Per-tool concurrency counts
;;   *janitor-thread*                -- Janitor sweep thread
;;   *janitor-running-p*             -- Janitor control flag
;;   *janitor-lock*                  -- Janitor state lock
;;   *janitor-cvar*                  -- Janitor condition variable
;;   *network-monitor-thread*        -- Network monitor thread
;;   *network-monitor-running-p*     -- Monitor control flag
;;   *network-monitor-lock*          -- Monitor state lock
;;   *network-monitor-cvar*          -- Monitor condition variable
;;   *policy-audit-log*              -- Audit log circular buffer
;;   *audit-log-lock*                -- Audit log lock
;;   *audit-log-max-entries*         -- Max audit entries (1000)
;;
;; POLICY MANAGEMENT:
;;   load-default-policies    -- Register 7 built-in policies
;;   register-policy          -- Add/update a tool policy
;;   get-policy               -- Retrieve a tool policy
;;   policy-exists-p          -- Check if policy exists
;;   unregister-policy        -- Remove a tool policy
;;   list-registered-policies -- All registered tool names
;;   describe-policy          -- Human-readable policy description
;;   make-tool-policy         -- Construct a tool-policy
;;
;; POLICY VALIDATION:
;;   safe-strategy-p                -- The Gatekeeper
;;   validate-args-against-policy   -- Check forbidden args
;;   validate-required-args-present -- Check required args
;;   validate-target-against-policy -- Check forbidden targets
;;   validate-risk-level            -- Check risk acceptability
;;   check-max-parallel             -- Check concurrency limit
;;   confirm-high-risk-operation    -- Operator confirmation prompt
;;   target-matches-p               -- Target pattern matching
;;   wildcard-match-p               -- Wildcard matching
;;   risk-level-<=                  -- Risk level comparison
;;
;; THE JANITOR:
;;   finalize-agent         -- Generic finalization hook
;;   finalize-agent :after  -- Kill subprocess on agent death (CLOS)
;;   drain-subprocess-output -- Drain stdout/stderr
;;   janitor-sweep          -- Clean ghosts, zombies, runaways
;;   start-janitor-thread   -- Launch background sweep
;;   stop-janitor-thread    -- Stop Janitor
;;   janitor-loop           -- The sweep loop
;;   janitor-status         -- Janitor diagnostics
;;
;; NETWORK STATE:
;;   save-network-state           -- Capture interface config
;;   restore-network-state        -- Restore interfaces
;;   check-network-link           -- Check primary link status
;;   handle-unexpected-link-loss  -- Recovery action
;;   start-network-monitor        -- Launch link monitor
;;   stop-network-monitor         -- Stop monitor
;;   network-monitor-loop         -- Monitor loop
;;
;; EMERGENCY and AUDIT:
;;   emergency-kill-all-tools -- Kill all tool subprocesses
;;   policy-audit-log         -- Log a policy decision
;;   get-policy-audit         -- Retrieve audit log
;;   get-policy-audit-by-action -- Filtered audit retrieval
;;   clear-policy-audit       -- Clear audit log
;;
;; TOOL LAUNCHER:
;;   launch-kali-tool      -- Safe tool launch (main entry point)
;;   register-kali-agent   -- Register with orchestrator
;;   deregister-kali-agent -- Remove and kill subprocess
;;
;; CONVENIENCE:
;;   kill-agent-tool        -- Kill a single agent's tool
;;   list-active-kali-tools -- All running tool instances
;;   get-agent-output       -- Accumulated tool output
;;   wait-for-agent         -- Block until subprocess exits
;;
;; SYSTEM:
;;   initialize-gatekeeper   -- Full subsystem initialization
;;   shutdown-gatekeeper     -- Graceful shutdown
;;   gatekeeper-status       -- Comprehensive diagnostics
;;   print-gatekeeper-report -- Human-readable status report
;;
;; "The Gatekeeper stands at the threshold. It does not sleep, it does not
;;  forgive, and it never forgets. Every tool launch is a promise. The
;;  Gatekeeper ensures that promise is kept. The Janitor ensures no trace
;;  remains. And when everything goes wrong, the emergency kill-switch
;;  ensures that the damage stops here."

;;  remains. And when everything goes wrong, the emergency kill-switch
;;  ensures that the damage stops here.


;; ═══════════════════════════════════════════════════════════════════════════
;; WIFI SAFETY MODULE -- v2.2.1 Wi-Fi Policy & Network Stability
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; "Wi-Fi tools occupy a uniquely dangerous position in the offensive toolbox.
;;  They operate at the boundary of the airwaves -- invisible, unforgiving,
;;  and capable of causing real disruption to production networks. The Wi-Fi
;;  Safety Module extends the Gatekeeper's protection into the 2.4GHz and 5GHz
;;  domains, ensuring that every frame injection, every deauth, every handshake
;;  capture happens under controlled, monitored, and revocable conditions."
;;
;; COMPONENTS:
;;   Wi-Fi Tool Policies          -- load-wifi-default-policies
;;   Network Stability Monitor    -- RTT-based gateway health tracking
;;   Wi-Fi Signal Monitor         -- dBm-based signal strength guard
;;   Emergency Integration        -- Wi-Fi aware kill-switch + safe-state
;;   Wi-Fi Agent Classes          -- bettercap-agent, airgeddon-agent
;;
;; THREAT MODEL:
;;   - Broad deauth floods from bettercap wifi.deauth
;;   - Fuzzing attacks (wifi.fuzz) destabilizing target APs
;;   - Operations against primary interface (wlan0)
;;   - Airgeddon --dos mode causing full denial of service
;;   - PMKID captures without WPA3 safeguards
;;   - Signal degradation causing failed attacks with hanging state
;;   - Network instability during active Wi-Fi operations


;; ─────────────────────────────────────────────────────────────────────────
;; Section A: Wi-Fi Agent Classes
;; ─────────────────────────────────────────────────────────────────────────

(defclass bettercap-agent (kali-agent)
  ((interface
    :initarg :interface
    :initform "wlan1"
    :accessor wifi-agent-interface
    :documentation "Wi-Fi interface used by this agent. Default wlan1.
NEVER wlan0 (primary interface). Enforced by policy."))
  (:documentation "Specialized KALI-AGENT for bettercap Wi-Fi operations.
Runs recon, deauth, and packet capture under policy enforcement.
Monitored by the network stability system."))

(defclass airgeddon-agent (kali-agent)
  ((interface
    :initarg :interface
    :initform "wlan1"
    :accessor wifi-agent-interface
    :documentation "Wi-Fi interface used by this agent. Default wlan1.
Managed interface for Evil Twin and handshake capture."))
  (:documentation "Specialized KALI-AGENT for airgeddon Wi-Fi auditing.
Runs WPA3 audits, Evil Twin attacks, and handshake capture.
Destructive operations require explicit confirmation."))


;; ─────────────────────────────────────────────────────────────────────────
;; Section B: Wi-Fi Tool Policies -- The Air-Gatekeeper
;; ─────────────────────────────────────────────────────────────────────────

(defun load-wifi-default-policies () 
  "Register default policies for bettercap and airgeddon Wi-Fi tools.

BETTERCAP POLICY:
  - Forbidden: wifi.deauth module (broad deauth floods)
  - Forbidden: wifi.fuzz module (fuzzing attacks)
  - Forbidden: arguments matching *10.0.0.0/8* or *192.168.0.0/16*
  - Required: -iface must specify wlan1 (never wlan0 = primary)
  - Max parallel: 2 instances (conservative for Wi-Fi channel congestion)
  - Timeout: 300 seconds (5 minutes per operation)
  - Risk level: :high (always requires confirmation)

AIRGEDDON POLICY:
  - Forbidden: --dos flag (full denial of service mode)
  - Forbidden: --pmkid without accompanying --wpa3 flag
  - Required: either --script or --wpa3 flag must be present
  - Max parallel: 1 instance (destructive operations)
  - Timeout: 600 seconds (10 minutes per audit)
  - Risk level: :critical (always requires confirmation)
  - Confirmation required: yes (mandatory, cannot be bypassed)

Returns list of registered tool-name symbols. Idempotent.
These policies are IN ADDITION TO the base 7 default policies.
Call after LOAD-DEFAULT-POLICIES for complete protection."
  (let ((registered '()))
    ;; BETTERCAP: Wi-Fi recon and injection
    (push (tool-policy-tool-name
           (register-policy
            'bettercap
            (make-tool-policy
             'bettercap
             :forbidden-args '("wifi.deauth" "wifi.fuzz"
                               "--deauth" "--fuzz"
                               "*10.0.0.0/8*" "*192.168.0.0/16*"
                               "-iface wlan0" "--iface wlan0")
             :forbidden-targets '("10.0.0.0/8" "192.168.0.0/16")
             :max-parallel 2
             :timeout-seconds 300
             :required-args '("-iface wlan1")
             :risk-level :high)))
          registered)
    ;; AIRGEDDON: Wi-Fi auditing framework
    (push (tool-policy-tool-name
           (register-policy
            'airgeddon
            (make-tool-policy
             'airgeddon
             :forbidden-args '("--dos" "--dos-attack"
                               "--evil-twin-full"
                               "--wds-confusion")
             :forbidden-targets nil
             :max-parallel 1
             :timeout-seconds 600
             :required-args '("--script" "--wpa3")
             :risk-level :critical)))
          registered)
    (policy-audit-log :load-wifi-defaults t
                      (format nil "Loaded ~D Wi-Fi default policies: ~S"
                              (length registered) registered))
    registered))


;; ─────────────────────────────────────────────────────────────────────────
;; Section C: Network Stability Monitor -- RTT-Based Circuit Breaker
;; ─────────────────────────────────────────────────────────────────────────

(defvar *network-stability-monitor-running-p* nil
  "Is the network stability monitor currently active?
The monitor pings the default gateway every INTERVAL seconds and maintains
a sliding window of RTT measurements. It is the canary in the coal mine
for Wi-Fi induced network degradation.")

(defvar *network-stability-thread* nil
  "The background stability monitor thread handle (a BT:THREAD) or NIL.
Independent from the link monitor in Section 4. Focused on RTT, not link state.")

(defvar *network-stability-lock* (bt:make-lock "network-stability-lock")
  "Lock protecting stability monitor state variables.")

(defvar *network-stability-cvar* (bt:make-condition-variable :name "network-stability-cvar")
  "Condition variable for graceful stability monitor shutdown.")

(defvar *gateway-rtt-threshold-ms* 200
  "RTT above this value (in milliseconds) triggers a :degraded alert.
The alert signals that Wi-Fi operations may be impacting network quality.
Default 200ms is suitable for LAN environments. Adjust for WAN.")

(defvar *gateway-rtt-critical-ms* 500
  "RTT above this value (in milliseconds) triggers emergency safe-state.
When critical RTT is detected, all Wi-Fi tool processes are halted
and the system enters Wi-Fi safe mode. Default 500ms.")

(defvar *rtt-history* (make-array 20 :fill-pointer 0 :adjustable t)
  "Sliding window of recent RTT measurements in milliseconds.
Oldest entries are dropped when the window exceeds 20 samples.
All accesses must hold *NETWORK-STABILITY-LOCK*.")

(defvar *rtt-high-consecutive-count* 0
  "Counter for consecutive high-RTT readings.
When this reaches 3, the system enters safe-state automatically.
Reset to 0 on any normal RTT reading.")

(defvar *wifi-safe-mode-active-p* nil
  "Is Wi-Fi safe mode currently active?
When T, all Wi-Fi tool launches are blocked until stability returns.")

(defun measure-gateway-rtt () 
  "Ping the default gateway and return RTT in milliseconds as a float.
Uses /bin/ping -c 1 -W 2 for a single fast probe. Returns NIL if:
  - No default gateway can be determined
  - The gateway does not respond
  - The ping command fails
  - The RTT cannot be parsed from output
Thread-safe: makes no mutations to shared state.
Example: (measure-gateway-rtt) => 12.4"
  (handler-case
      (let* ((gateway (or (ignore-errors
                            (let ((route (uiop:run-program
                                          "ip route show default 2>/dev/null"
                                          :output '(:string :stripped t)
                                          :ignore-error-status t)))
                              (when (and route (> (length route) 0))
                                (let ((via-pos (search "via " route)))
                                  (when via-pos
                                    (let ((start (+ via-pos 4)))
                                      (subseq route start
                                              (position #\space route :start start))))))))
                        "192.168.1.1"))
             (output (uiop:run-program
                      (format nil "/bin/ping -c 1 -W 2 ~A 2>/dev/null" gateway)
                      :output '(:string :stripped t)
                      :ignore-error-status t)))
        (when (and output (search "time=" output))
          (let* ((time-pos (search "time=" output))
                 (start (+ time-pos 5))
                 (end (position #\space output :start start))
                 (ms-str (subseq output start end)))
            (let ((ms (parse-float:parse-float ms-str :junk-allowed t)))
              (when ms (float ms 0.0))))))
    (error (e)
      (policy-audit-log :rtt-measure-failed nil (format nil "~A" e))
      nil)
    (condition (c)
      (policy-audit-log :rtt-measure-condition nil (format nil "~A" c))
      nil)))

(defun get-average-rtt () 
  "Calculate average RTT from the sliding window.
Returns the arithmetic mean of all entries in *RTT-HISTORY*, or NIL
if no measurements have been taken yet. All accesses hold the lock.
Example: (get-average-rtt) => 45.2"
  (bt:with-lock-held (*network-stability-lock*)
    (let ((count (fill-pointer *rtt-history*)))
      (when (> count 0)
        (/ (loop for i from 0 below count
                 sum (aref *rtt-history* i))
           count)))))

(defun rtt-history-push (value) 
  "Push a new RTT value into the sliding window, discarding oldest if full.
VALUE: RTT in milliseconds (float). Must hold *NETWORK-STABILITY-LOCK*."
  (when (>= (fill-pointer *rtt-history*) (array-dimension *rtt-history* 0))
    ;; Shift everything down by one, drop oldest
    (replace *rtt-history* *rtt-history*
             :start1 0 :start2 1
             :end2 (fill-pointer *rtt-history*))
    (decf (fill-pointer *rtt-history*)))
  (vector-push value *rtt-history*))

(defun check-network-stability () 
  "Check network stability via gateway RTT measurement.
Performs a single ping and classifies the network state:
  - :stable   -- RTT <= warning threshold, all clear
  - :degraded -- RTT > warning threshold, Wi-Fi ops may be impacting
  - :critical -- RTT > critical threshold OR 3 consecutive high readings
On critical: triggers WIFI-EMERGENCY-HALT automatically.
On degraded: increments consecutive counter; logs alert.
On stable: resets consecutive counter.

Returns one of: :stable, :degraded, :critical.
Every code path is wrapped in error handling -- never crashes."
  (handler-case
      (let ((rtt (measure-gateway-rtt)))
        (bt:with-lock-held (*network-stability-lock*)
          (cond
            ;; No response -- treat as critical
            ((null rtt)
             (incf *rtt-high-consecutive-count*)
             (when (>= *rtt-high-consecutive-count* 2)
               (policy-audit-log :network-stability :critical
                                 "Gateway unreachable for 2 consecutive pings")
               (return-from check-network-stability :critical))
             :degraded)
            ;; Critical threshold
            ((> rtt *gateway-rtt-critical-ms*)
             (incf *rtt-high-consecutive-count*)
             (rtt-history-push rtt)
             (policy-audit-log :network-stability :critical
                               (format nil "RTT critical: ~,1fms (> ~Dms)"
                                       rtt *gateway-rtt-critical-ms*))
             (wifi-emergency-halt)
             :critical)
            ;; Warning threshold
            ((> rtt *gateway-rtt-threshold-ms*)
             (incf *rtt-high-consecutive-count*)
             (rtt-history-push rtt)
             (when (>= *rtt-high-consecutive-count* 3)
               (policy-audit-log :network-stability :critical
                                 (format nil "3 consecutive high RTTs (last: ~,1fms)"
                                         rtt))
               (enter-wifi-safe-state)
               :critical)
             (policy-audit-log :network-stability :degraded
                               (format nil "RTT elevated: ~,1fms (> ~Dms)"
                                       rtt *gateway-rtt-threshold-ms*))
             :degraded)
            ;; Normal
            (t
             (setf *rtt-high-consecutive-count* 0)
             (rtt-history-push rtt)
             :stable))))
    (error (e)
      (policy-audit-log :stability-check-error nil (format nil "~A" e))
      :degraded)
    (condition (c)
      (policy-audit-log :stability-check-condition nil (format nil "~A" c))
      :degraded)))

(defun start-network-stability-monitor (&optional (interval 3)) 
  "Start a background thread that pings the gateway every INTERVAL seconds.
Default INTERVAL is 3 seconds for rapid detection of Wi-Fi induced degradation.
The monitor is the circuit breaker: on critical RTT, it halts all Wi-Fi tools.
Returns the monitor thread. If already running, returns existing thread.
Thread-safe: acquires *NETWORK-STABILITY-LOCK*."
  (bt:with-lock-held (*network-stability-lock*)
    (if (and *network-stability-thread*
             (bt:thread-alive-p *network-stability-thread*))
        *network-stability-thread*
        (progn
          (setf *network-stability-monitor-running-p* t)
          (setf *wifi-safe-mode-active-p* nil)
          (setf *rtt-high-consecutive-count* 0)
          (setf (fill-pointer *rtt-history*) 0)
          (setf *network-stability-thread*
                (bt:make-thread
                 (lambda () (stability-monitor-loop interval))
                 :name "lispmind-stability-monitor"
                 :initial-bindings `((*standard-output* . ,*standard-output*)
                                     (*error-output*    . ,*error-output*))))
          (policy-audit-log :stability-monitor-started t
                            (format nil "Stability monitor started (interval: ~Ds)"
                                    interval))
          *network-stability-thread*))))

(defun stop-network-stability-monitor () 
  "Stop the network stability monitor gracefully.
Signals shutdown via *NETWORK-STABILITY-MONITOR-RUNNING-P* and waits
up to 10 seconds for thread termination. Force-destroys if needed.
Returns T if stopped, NIL if not running."
  (bt:with-lock-held (*network-stability-lock*)
    (when *network-stability-monitor-running-p*
      (setf *network-stability-monitor-running-p* nil)
      (bt:condition-notify *network-stability-cvar*)
      (when (and *network-stability-thread*
                 (bt:thread-alive-p *network-stability-thread*))
        (dotimes (i 100)
          (unless (bt:thread-alive-p *network-stability-thread*)
            (return))
          (sleep 0.1))
        (when (bt:thread-alive-p *network-stability-thread*)
          (ignore-errors (bt:destroy-thread *network-stability-thread*))))
      (setf *network-stability-thread* nil)
      (policy-audit-log :stability-monitor-stopped t
                        "Network stability monitor stopped")
      t)))

(defun stability-monitor-loop (interval) 
  "The stability monitor background loop. Immortal -- catches ALL errors.
Pings gateway every INTERVAL seconds, checks stability, acts on result.
A crashed monitor means undetected Wi-Fi induced DoS -- never let it die.
The loop exits cleanly when *NETWORK-STABILITY-MONITOR-RUNNING-P* is NIL."
  (loop while *network-stability-monitor-running-p* do
    (handler-case
        (progn
          (bt:with-lock-held (*network-stability-lock*)
            (unless *network-stability-monitor-running-p* (return))
            (bt:condition-wait *network-stability-cvar* *network-stability-lock*
                               :timeout interval))
          (when *network-stability-monitor-running-p*
            (check-network-stability)))
      (error (e)
        (format *error-output* "~&[STABILITY-MONITOR ERROR] ~A~%" e)
        (policy-audit-log :stability-monitor-error nil (format nil "~A" e)))
      (condition (c)
        (format *error-output* "~&[STABILITY-MONITOR CONDITION] ~A~%" c)
        (policy-audit-log :stability-monitor-condition nil (format nil "~A" c))))))


;; ─────────────────────────────────────────────────────────────────────────
;; Section D: Wi-Fi Signal Strength Monitoring
;; ─────────────────────────────────────────────────────────────────────────

(defvar *wifi-signal-threshold-dbm* -70
  "Signal strength threshold in dBm for auto-pause.
Signals weaker than -70 dBm (more negative) trigger auto-pause.
-30 dBm = excellent, -50 dBm = good, -70 dBm = fair, -90 dBm = poor.")

(defun measure-target-signal (bssid interface) 
  "Measure signal strength (dBm) of target BSSID.
Uses iw dev INTERFACE station dump when available, falling back to
airodump-ng --bssid for a single 3-second sample.

Arguments:
  BSSID     -- Target MAC address string (e.g., 'AA:BB:CC:DD:EE:FF')
  INTERFACE -- Wi-Fi interface name (e.g., 'wlan1')

Returns signal strength in dBm as integer, or NIL if:
  - The BSSID is not visible
  - The interface does not exist
  - The measurement tool is not available
  - The output cannot be parsed

Example: (measure-target-signal 'AA:BB:CC:DD:EE:FF' 'wlan1') => -42"
  (handler-case
      (let ((output (uiop:run-program
                     (format nil "iw dev ~A station dump 2>/dev/null" interface)
                     :output '(:string :stripped t)
                     :ignore-error-status t)))
        (if (and output (> (length output) 0) (search "signal:" output))
            ;; Parse iw output: look for Station <bssid> block and extract signal
            (let* ((bssid-lower (string-downcase bssid))
                   (station-pos (search bssid-lower output)))
              (when station-pos
                (let* ((block-start station-pos)
                       (block-end (or (search "\nStation" output :start2 (+ block-start 20))
                                      (length output)))
                       (block (subseq output block-start block-end))
                       (sig-pos (search "signal:" block)))
                  (when sig-pos
                    (let* ((val-start (position-if #'digit-or-minus-p
                                                    block :start (+ sig-pos 7)))
                           (val-end (position #\space block :start val-start))
                           (val-str (subseq block val-start val-end)))
                      (parse-integer val-str :junk-allowed t))))))
            ;; Fallback: try airodump-ng
            (let ((dump (uiop:run-program
                         (format nil "timeout 3 airodump-ng ~A --bssid ~A --write-interval 1 -w /tmp/signal_check 2>&1 || true"
                                 interface bssid)
                         :output '(:string :stripped t)
                         :ignore-error-status t)))
              (when (and dump (search "PWR" dump))
                ;; Parse PWR column from airodump-ng output
                (let ((pwr-line (find-pwr-line dump bssid)))
                  (when pwr-line
                    (parse-integer pwr-line :junk-allowed t)))))))
    (error (e)
      (policy-audit-log :signal-measure-failed nil
                        (format nil "BSSID ~A on ~A: ~A" bssid interface e))
      nil)
    (condition (c)
      (policy-audit-log :signal-measure-condition nil
                        (format nil "BSSID ~A on ~A: ~A" bssid interface c))
      nil)))

(defun digit-or-minus-p (char) 
  "Return T if CHAR is a digit or minus sign. Used by signal parser."
  (or (digit-char-p char) (char= char #\-)))

(defun find-pwr-line (output bssid) 
  "Extract the PWR column value for BSSID from airodump-ng output.
Returns the power value string, or NIL if not found."
  (let ((lines (uiop:split-string output :separator '(#\newline))))
    (dolist (line lines)
      (when (search (string-downcase bssid) (string-downcase line))
        ;; PWR is typically the 4th column
        (let ((tokens (uiop:split-string line :separator '(#\space #\tab))))
          (dolist (tok tokens)
            (when (and (> (length tok) 0)
                       (digit-or-minus-p (char tok 0)))
              (return-from find-pwr-line tok))))))
    nil))

(defun signal-above-threshold-p (dbm threshold) 
  "Check if signal DBM is above THRESHOLD (less negative = stronger).
Returns T if the signal is strong enough to continue operations.

Arguments:
  DBM       -- Signal strength in dBm (negative integer, e.g., -42)
  THRESHOLD -- Minimum acceptable signal in dBm (e.g., -70)

Returns T if DBM >= THRESHOLD (e.g., -42 >= -70 is T).
A NIL DBM is treated as below threshold (returns NIL).

Example: (signal-above-threshold-p -42 -70) => T"
  (and dbm (>= dbm threshold)))

(defun auto-pause-on-signal-weak (agent signal-db threshold) 
  "Auto-pause a Wi-Fi stress test if signal drops below THRESHOLD.
Called by the stability monitor or agent supervision loop when
signal degradation is detected.

Arguments:
  AGENT     -- The KALI-AGENT running the Wi-Fi operation
  SIGNAL-DB -- Current signal strength in dBm, or NIL if unknown
  THRESHOLD -- Minimum acceptable signal (default *WIFI-SIGNAL-THRESHOLD-DBM*)

Actions taken:
  1. If signal is NIL or below threshold: kill subprocess
  2. Set agent status to :paused
  3. Log the event to audit and telemetry
  4. Return :paused

Returns :ok if signal is good, :paused if paused, :unknown if no signal data."
  (cond
    ((null signal-db)
     (policy-audit-log :signal-pause-unknown (agent-id agent)
                       (format nil "No signal data for ~A, cannot assess"
                               (agent-id agent)))
     :unknown)
    ((not (signal-above-threshold-p signal-db threshold))
     (kill-agent-tool agent)
     (setf (agent-status agent) :paused)
     (policy-audit-log :signal-paused (agent-id agent)
                       (format nil "Signal ~D dBm below threshold ~D dBm -- paused ~A"
                               signal-db threshold (agent-id agent)))
     :paused)
    (t :ok)))


;; ─────────────────────────────────────────────────────────────────────────
;; Section E: Emergency Integration -- Wi-Fi Kill-Switch
;; ─────────────────────────────────────────────────────────────────────────

(defun wifi-emergency-halt () 
  "Kill all bettercap, airgeddon, and aircrack-ng processes.
This is the Wi-Fi specific emergency kill-switch. It targets the exact
process names used by Wi-Fi tools and sends SIGKILL to each.

Steps:
  1. Find PIDs of bettercap, airgeddon, aircrack-ng, airodump-ng, aireplay-ng
  2. Send SIGKILL to each PID
  3. Log the event to audit

Returns plist: :killed-count, :pids, :errors.
Every error is caught -- this function must never crash during an emergency."
  (let ((killed-count 0) (pids-killed '()) (errors '())
        (targets '("bettercap" "airgeddon" "aircrack-ng" "airodump-ng"
                   "aireplay-ng" "aireplay" "airmon-ng" "packetforge-ng")))
    (dolist (proc-name targets)
      (handler-case
          (let ((pid-output (uiop:run-program
                             (format nil "pgrep -f ~A 2>/dev/null || true" proc-name)
                             :output '(:string :stripped t)
                             :ignore-error-status t)))
            (when (and pid-output (> (length pid-output) 0))
              (dolist (pid-str (uiop:split-string pid-output :separator '(#\newline)))
                (when (> (length pid-str) 0)
                  (handler-case
                      (let ((pid (parse-integer pid-str :junk-allowed t)))
                        (when pid
                          (uiop:run-program
                           (format nil "kill -9 ~D 2>/dev/null || true" pid)
                           :ignore-error-status t)
                          (incf killed-count)
                          (push pid pids-killed)))
                    (error (e)
                      (push (cons proc-name (format nil "~A" e)) errors))))))
        (error (e)
          (push (cons proc-name (format nil "~A" e)) errors))
        (condition (c)
          (push (cons proc-name (format nil "~A" c)) errors)))
    (policy-audit-log :wifi-emergency-halt (> killed-count 0)
                      (format nil "Wi-Fi emergency halt: killed ~D processes (~D errors)"
                              killed-count (length errors)))
    (list :killed-count killed-count
          :pids (nreverse pids-killed)
          :errors errors)))

(defun enter-wifi-safe-state () 
  "Transition to Wi-Fi safe state. The nuclear option for Wi-Fi operations.
This function is called when network stability is critical or when
3 consecutive high RTT readings are detected.

Actions taken:
  1. Kill all Wi-Fi tool processes (bettercap, airgeddon, aircrack-ng family)
  2. Restore network interfaces from the saved checkpoint
  3. Set *WIFI-SAFE-MODE-ACTIVE-P* to T (blocks new Wi-Fi launches)
  4. Set all Wi-Fi agent statuses to :safe-mode
  5. Log the event to telemetry and audit
  6. Reset the RTT consecutive counter

Returns plist: :safe-mode-active-p, :processes-killed, :agents-affected.
To exit safe mode: call EXIT-WIFI-SAFE-STATE after stability returns."
  (let ((killed (wifi-emergency-halt))
        (agents-affected '()))
    ;; Restore network interfaces
    (ignore-errors (restore-network-state))
    ;; Set safe mode flag
    (setf *wifi-safe-mode-active-p* t)
    ;; Mark all Wi-Fi agents as safe-mode
    (bt:with-lock-held (*kali-agents-lock*)
      (maphash
       (lambda (agent-id agent)
         (when (or (typep agent 'bettercap-agent)
                   (typep agent 'airgeddon-agent))
           (setf (agent-status agent) :safe-mode)
           (push agent-id agents-affected)))
       *active-kali-agents*))
    ;; Reset consecutive counter
    (bt:with-lock-held (*network-stability-lock*)
      (setf *rtt-high-consecutive-count* 0))
    ;; Log
    (policy-audit-log :wifi-safe-state-entered t
                      (format nil "Wi-Fi safe state entered. Killed ~D processes. ~D agents in safe-mode."
                              (getf killed :killed-count)
                              (length agents-affected)))
    (list :safe-mode-active-p t
          :processes-killed (getf killed :killed-count)
          :agents-affected (nreverse agents-affected))))

(defun exit-wifi-safe-state () 
  "Exit Wi-Fi safe state after stability returns.
Verifies network stability before allowing operations to resume.
Sets *WIFI-SAFE-MODE-ACTIVE-P* to NIL if stability check passes.
Returns :resumed if exited, :still-unstable if stability check fails."
  (let ((stability (check-network-stability)))
    (if (eq stability :stable)
        (progn
          (setf *wifi-safe-mode-active-p* nil)
          (policy-audit-log :wifi-safe-state-exited t
                            "Wi-Fi safe state exited -- network stable")
          :resumed)
        (progn
          (policy-audit-log :wifi-safe-state-exit-denied nil
                            (format nil "Cannot exit safe state: network still ~A" stability))
          :still-unstable))))

(defun wifi-safe-mode-p () 
  "Return T if Wi-Fi safe mode is currently active.
When safe mode is active, all Wi-Fi tool launches are blocked.
New operations may only begin after EXIT-WIFI-SAFE-STATE succeeds."
  *wifi-safe-mode-active-p*)


;; ─────────────────────────────────────────────────────────────────────────
;; Section F: Emergency Halt Handlers for Wi-Fi Agents
;; ─────────────────────────────────────────────────────────────────────────

(defmethod handle-condition :after ((agent bettercap-agent) (condition emergency-halt))
  "Kill bettercap process on emergency halt.
This :AFTER method ensures that when an EMERGENCY-HALT condition is
signaled and the orchestrator begins handling it, any running bettercap
subprocess associated with this agent is terminated immediately.
The parent KALI-AGENT :AFTER method handles the generic cleanup.
This method adds Wi-Fi specific logging."
  (bt:with-lock-held ((agent-lock agent))
    (let ((subprocess (kali-agent-subprocess agent)))
      (when (and subprocess (uiop:process-alive-p subprocess))
        (ignore-errors (uiop:terminate-process subprocess :urgent t))
        (policy-audit-log :bettercap-emergency-killed (agent-id agent)
                          (format nil "Emergency halt killed bettercap for ~A"
                                  (agent-id agent)))))))

(defmethod handle-condition :after ((agent airgeddon-agent) (condition emergency-halt))
  "Kill airgeddon process on emergency halt.
This :AFTER method ensures that when an EMERGENCY-HALT condition is
signaled, any running airgeddon subprocess is terminated immediately.
Airgeddon operations are :critical risk -- they are the first to die
in an emergency. Also kills any child processes (airodump-ng, etc.)."
  (bt:with-lock-held ((agent-lock agent))
    (let ((subprocess (kali-agent-subprocess agent)))
      (when (and subprocess (uiop:process-alive-p subprocess))
        (ignore-errors (uiop:terminate-process subprocess :urgent t))
        (policy-audit-log :airgeddon-emergency-killed (agent-id agent)
                          (format nil "Emergency halt killed airgeddon for ~A"
                                  (agent-id agent)))))
  ;; Also sweep for orphaned airgeddon children
  (ignore-errors (wifi-emergency-halt)))


;; ─────────────────────────────────────────────────────────────────────────
;; Section G: Wi-Fi Gatekeeper Status
;; ─────────────────────────────────────────────────────────────────────────

(defun wifi-gatekeeper-status () 
  "Return comprehensive Wi-Fi safety subsystem status as a plist:
  :wifi-policies-loaded    -- Count of Wi-Fi policies registered
  :wifi-policy-names        -- List of Wi-Fi tool names
  :stability-monitor        -- Is the RTT monitor running?
  :wifi-safe-mode           -- Is safe mode active?
  :rtt-threshold-ms         -- Current warning threshold
  :rtt-critical-ms          -- Current critical threshold
  :rtt-average              -- Average RTT from sliding window
  :rtt-high-consecutive     -- Consecutive high RTT count
  :rtt-history-count        -- Number of samples in window
  :wifi-agents-active       -- Count of bettercap + airgeddon agents
  :signal-threshold-dbm     -- Signal auto-pause threshold"
  (let ((wifi-agents 0) (wifi-policy-names '()) (wifi-policy-count 0))
    (bt:with-lock-held (*kali-agents-lock*)
      (maphash (lambda (id agent)
                 (declare (ignore id))
                 (when (or (typep agent 'bettercap-agent)
                           (typep agent 'airgeddon-agent))
                   (incf wifi-agents)))
               *active-kali-agents*))
    (bt:with-lock-held (*policy-lock*)
      (dolist (name '(bettercap airgeddon))
        (when (gethash name *tactical-repository*)
          (incf wifi-policy-count)
          (push name wifi-policy-names))))
    (list :wifi-policies-loaded wifi-policy-count
          :wifi-policy-names wifi-policy-names
          :stability-monitor (and *network-stability-thread*
                                  (bt:thread-alive-p *network-stability-thread*))
          :wifi-safe-mode *wifi-safe-mode-active-p*
          :rtt-threshold-ms *gateway-rtt-threshold-ms*
          :rtt-critical-ms *gateway-rtt-critical-ms*
          :rtt-average (get-average-rtt)
          :rtt-high-consecutive *rtt-high-consecutive-count*
          :rtt-history-count (fill-pointer *rtt-history*)
          :wifi-agents-active wifi-agents
          :signal-threshold-dbm *wifi-signal-threshold-dbm*)))

(defun print-wifi-gatekeeper-report () 
  "Print human-readable Wi-Fi safety status report to *STANDARD-OUTPUT*."
  (let ((status (wifi-gatekeeper-status)))
    (format t "~&*** LISPMIND WI-FI SAFETY MODULE STATUS REPORT ***~%")
    (format t "  Wi-Fi Policies:    ~A (~{~A~^, ~})~%"
            (getf status :wifi-policies-loaded)
            (getf status :wifi-policy-names))
    (format t "  Stability Monitor: ~A~%"
            (if (getf status :stability-monitor) "RUNNING" "STOPPED"))
    (format t "  Wi-Fi Safe Mode:   ~A~%"
            (if (getf status :wifi-safe-mode) "ACTIVE" "inactive"))
    (format t "  RTT Thresholds:    warning=~Dms critical=~Dms~%"
            (getf status :rtt-threshold-ms)
            (getf status :rtt-critical-ms))
    (format t "  RTT Average:       ~,1fms (~D samples, ~D consecutive high)~%"
            (or (getf status :rtt-average) 0.0)
            (getf status :rtt-history-count)
            (getf status :rtt-high-consecutive))
    (format t "  Wi-Fi Agents:      ~D active~%"
            (getf status :wifi-agents-active))
    (format t "  Signal Threshold:  ~D dBm~%"
            (getf status :signal-threshold-dbm))
    (format t "*** END WI-FI SAFETY REPORT ***~%")))


;; ═══════════════════════════════════════════════════════════════════════════
;; END OF WI-FI SAFETY MODULE v2.2.1
;; ═══════════════════════════════════════════════════════════════════════════


;;;; ═════════════════════════════════════════════════════════════════════════
;;;; END OF POLICY-GATEKEEPER.LISP
;;;; ═════════════════════════════════════════════════════════════════════════
