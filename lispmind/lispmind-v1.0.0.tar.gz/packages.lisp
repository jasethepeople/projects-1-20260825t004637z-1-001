;;;; -*- Mode: Lisp; Syntax: ANSI-Common-Lisp; Base: 10 -*-
;;;;
;;;; PACKAGES.LISP — Central Package Definition for LISPMIND
;;;;
;;;; This is the first file loaded by ASDF (see lispmind.asd).  It defines the
;;;; LISPMIND package (nickname MIND) and exports every public symbol that the
;;;; nine implementation files create or reference.  Keep this file in strict
;;;; sync with the rest of the codebase — every exported generic function,
;;;; class, condition, and accessor must have a corresponding definition.

(in-package :cl-user)

;; ---------------------------------------------------------------------------
;; Package LISPMIND  (Nickname: MIND)
;; ---------------------------------------------------------------------------
;; The canonical namespace for the entire orchestrator.  All implementation
;; files begin with (in-package :lispmind).  External users should use the
;; MIND nickname for brevity: (mind:run-demo).
;;
;; Shadowing imports prevent name collisions between our exported symbols and
;; identically-named symbols from the used packages.  In particular:
;;   - `agent-health' shadows any potential generic from Alexandria
;;   - `agent-state' avoids ambiguity with closer-mop:class-state
;; ---------------------------------------------------------------------------
(defpackage :lispmind
  (:nicknames :mind)
  (:use
   ;; The Common Lisp standard — our foundation.
   :cl

   ;; Portable threading: locks, condition variables, threads.  Used heavily
   ;; in orchestrator.lisp and agent-class.lisp for concurrent agent access.
   :bordeaux-threads

   ;; CLOS MOP portability layer.  Enables :around methods on slot accessors
   ;; so that health/status changes automatically trigger notifications.
   :closer-mop

   ;; Alexandria utilities: with-gensyms, once-only, define-constant, etc.
   :alexandria)

  (:shadowing-import-from :closer-mop
                          #:standard-class)

  ;; ========================================================================
  ;; CONDITION EXPORTS — The Custom Condition Hierarchy
  ;; ========================================================================
  ;; These are the four condition classes that the orchestrator recognizes
  ;; and handles.  Each carries rich diagnostic data so the healing subsystem
  ;; can make informed restart decisions.
  ;;
  ;; Inheritance: all conditions ultimately inherit from ERROR.
  ;;
  ;; Usage in orchestrator.lisp: handler-bind binds these to restart
  ;; functions selected by default-restart-policy.
  ;; ========================================================================

  ;; Base condition for any agent-level failure.
  (:export #:agent-failure)

  ;; Raised when an agent's strategy function runs longer than its threshold
  ;; without producing progress.
  (:export #:strategy-stalled)

  ;; Raised when an agent exceeds its resource quota (memory, CPU, handles).
  (:export #:resource-exhausted)

  ;; Raised when an external system (network, database, API) fails to respond
  ;; within the allotted time.
  (:export #:external-timeout)

  ;; ---- Condition Readers --------------------------------------------------
  ;; Each slot below has an auto-generated reader (and writer when mutable).
  ;; These readers are exported so external debugging tools and the dashboard
  ;; can inspect condition details without breaking encapsulation.

  ;; AGENT-FAILURE readers
  (:export #:agent-failure-agent-id      ; symbol — which agent failed
           #:agent-failure-reason)        ; string — human-readable cause

  ;; STRATEGY-STALLED readers
  (:export #:strategy-stalled-agent-id       ; symbol — stalled agent
           #:strategy-stalled-elapsed-time   ; float — seconds since start
           #:strategy-stalled-threshold)     ; float — configured limit

  ;; RESOURCE-EXHAUSTED readers
  (:export #:resource-exhausted-agent-id       ; symbol — over-limit agent
           #:resource-exhausted-resource-type  ; keyword — :memory | :cpu | :handles
           #:resource-exhausted-current-usage  ; number — actual consumption
           #:resource-exhausted-limit)         ; number — configured ceiling

  ;; EXTERNAL-TIMEOUT readers
  (:export #:external-timeout-agent-id          ; symbol — waiting agent
           #:external-timeout-operation         ; string — what was attempted
           #:external-timeout-timeout-seconds)  ; float — how long it waited

  ;; ========================================================================
  ;; CLASS EXPORTS — CLOS Class Names
  ;; ========================================================================
  ;; These are the two primary classes.  AGENT is the base unit of
  ;; computation; ORCHESTRATOR is a meta-agent that supervises a colony
  ;; of agents.
  ;; ========================================================================

  (:export #:agent)          ; Base agent class with MOP hooks
  (:export #:orchestrator)   ; Meta-agent: registry, monitor, messenger

  ;; ========================================================================
  ;; GENERIC FUNCTION EXPORTS — Polymorphic Operations
  ;; ========================================================================
  ;; These generic functions form the core protocol.  Each has methods
  ;; specialized on AGENT, ORCHESTRATOR, or subclasses created by
  ;; DEFINE-AGENT-TYPE.  New agent types automatically participate in
  ;; the protocol by inheriting from AGENT.
  ;; ========================================================================

  ;; Execute the agent's current strategy function.  Primary method on
  ;; base AGENT is a no-op; DEFINE-AGENT-TYPE generates a real method.
  (:export #:run-agent)

  ;; Dispatch a condition to the agent's restart policy.  Returns a restart
  ;; keyword (e.g. :retry, :use-fallback, :escalate).
  (:export #:handle-condition)

  ;; Predicate: is the agent still alive?  Checks health > 0 and heartbeat
  ;; freshness (within 30 seconds).
  (:export #:agent-alive-p)

  ;; Callback invoked by MOP :around methods when agent-health changes.
  ;; Implemented in orchestrator.lisp to trigger healing when health drops
  ;; below critical thresholds.
  (:export #:notify-health-change)

  ;; Callback invoked by MOP :around methods when agent-status changes.
  ;; Used by the dashboard to refresh its display without polling.
  (:export #:notify-status-change)

  ;; ========================================================================
  ;; FUNCTION EXPORTS — API Entry Points
  ;; ========================================================================
  ;; These are the functions that users (and demo.lisp) call directly.
  ;; Every function has a docstring in its defining file.
  ;; ========================================================================

  ;; ---- Agent Lifecycle ----------------------------------------------------
  (:export #:make-agent)           ; Create a generic agent instance.
  (:export #:define-agent-type)    ; Macro: DSL for declaring agent subclasses.
  (:export #:register-agent)       ; Add an agent to an orchestrator's registry.
  (:export #:deregister-agent)     ; Remove an agent by id from the registry.

  ;; ---- Orchestrator Control -----------------------------------------------
  (:export #:start-orchestrator)   ; Launch monitor + dashboard threads.
  (:export #:stop-orchestrator)    ; Graceful shutdown of all threads.

  ;; ---- Introspection ------------------------------------------------------
  (:export #:list-agents)          ; Return all registered agents.
  (:export #:inspect-agent)        ; Detailed human-readable agent report.

  ;; ---- Healing & Patching -------------------------------------------------
  (:export #:heal-agent)           ; Apply a named restart to an agent.
  (:export #:hotpatch-agent)       ; Replace strategy at runtime, zero-downtime.
  (:export #:rollback-strategy)    ; Revert to a previous strategy version.

  ;; ---- Persistence --------------------------------------------------------
  (:export #:checkpoint-system)           ; Serialize entire orchestrator state.
  (:export #:restore-system)             ; Restore from checkpoint directory.
  (:export #:checkpoint-agent)           ; Serialize single agent state.
  (:export #:restore-agent-from-checkpoint)  ; Recreate agent from disk.

  ;; ---- Dashboard & Demo ---------------------------------------------------
  (:export #:start-dashboard)      ; Launch ASCII dashboard in its own thread.
  (:export #:stop-dashboard)       ; Terminate dashboard thread.
  (:export #:run-demo)             ; Self-contained demonstration narrative.
  (:export #:simulate-failure)    ; Inject a synthetic condition for testing.

  ;; ---- Messaging ----------------------------------------------------------
  (:export #:send-message)         ; Inter-agent asynchronous message passing.

  ;; ========================================================================
  ;; ACCESSOR EXPORTS — Slot Readers/Writers
  ;; ========================================================================
  ;; These are generated automatically by CLOS defclass :accessor specs.
  ;; They are exported so the dashboard, checkpoint system, and external
  ;; tooling can read (and sometimes write) agent state.
  ;;
  ;; NOTE: Writers are intentionally NOT exported for most slots to preserve
  ;; encapsulation.  Use the provided generic functions (heal-agent,
  ;; hotpatch-agent) for mutations.  The orchestrator's monitor loop
  ;; accesses slots directly — it is the only privileged mutator.
  ;; ========================================================================

  ;; ---- Agent slots --------------------------------------------------------
  (:export #:agent-id)             ; symbol   — unique identifier (read-only after creation)
  (:export #:agent-health)         ; integer  — 0..100 health score
  (:export #:agent-strategy)       ; function — current behavior function
  (:export #:agent-capabilities)   ; list     — keyword capability tags
  (:export #:agent-restart-policy) ; function — restart selection logic
  (:export #:agent-state)          ; hash-table — agent-local key/value store
  (:export #:agent-heartbeat)      ; timestamp — last alive signal
  (:export #:agent-error-count)    ; integer  — cumulative errors since birth
  (:export #:agent-status)         ; keyword  — :running :paused :failed :healing
  (:export #:agent-version)        ; integer  — strategy version counter
  (:export #:agent-lock)           ; bt:lock  — thread-safe mutation gate

  ;; ---- Orchestrator slots -------------------------------------------------
  (:export #:orchestrator-agents)           ; hash-table  — id → agent mapping
  (:export #:orchestrator-mailboxes)        ; hash-table  — id → message queue
  (:export #:orchestrator-running-p)        ; boolean     — is the loop active?
  (:export #:orchestrator-monitor-thread)   ; bt:thread or nil — health monitor
  (:export #:orchestrator-dashboard-thread) ; bt:thread or nil — REPL display

  ;; Package documentation string (visible via (documentation 'lispmind 'package))
  (:documentation
   "LISPMIND — Self-Healing Agentic AI Orchestrator.

The LISPMIND package (nickname MIND) exports the complete public API for
building, monitoring, and healing autonomous agent colonies in Common Lisp.

Key entry points:
  (mind:run-demo)               — Watch the system heal itself
  (mind:start-orchestrator)     — Launch a live orchestrator
  (mind:define-agent-type ...)  — Create a new agent species
  (mind:list-agents)            — See what's running

All symbols are documented.  Use (describe 'symbol) or (documentation 'symbol 'function)
for details."))
