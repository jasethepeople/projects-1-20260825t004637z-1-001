;;;; -*- Mode: Lisp; Syntax: ANSI-Common-Lisp; Base: 10 -*-
;;;
;;; ORCHESTRATOR.LISP — The Heart of LISPMIND
;;;
;;; ═══════════════════════════════════════════════════════════════════════════
;;;                     SUPREME AGENT: REGISTRY, MONITOR, HEALER
;;; ═══════════════════════════════════════════════════════════════════════════
;;;
;;; This file defines the ORCHESTRATOR class and its entire operational
;;; substrate: agent registry, inter-agent messaging, the monitor loop,
;;; the healing system, and meta-cognition triggers.
;;;
;;; DESIGN PHILOSOPHY
;;; ─────────────────
;;; The orchestrator is not a "manager" in the sense of an external
;;; supervisor. It is a META-AGENT — an agent that happens to supervise
;;; other agents. It inherits from AGENT because it has its own health,
;;; strategy, heartbeat, and can itself fail, stall, or be healed. This
;;; symmetry is deliberate: if the orchestrator can heal agents, what
;;; heals the orchestrator? The answer: the same restart system, applied
;;; recursively.
;;;
;;; The monitor loop is the beating heart. It runs in a dedicated thread,
;;; wakes every 2 seconds (or on demand via condition variable), checks
;;; every registered agent's vital signs, and signals conditions when
;;; trouble is detected. Critically, it uses HANDLER-BIND (not HANDLER-CASE)
;;; to preserve the full stack context and restart visibility. This is the
;;; LISPMIND way: never unwind the stack until a restart has been chosen.
;;;
;;; THREAD SAFETY
;;; ─────────────
;;; All registry mutations (register-agent, deregister-agent) hold the
;;; orchestrator's monitor-lock via BT:WITH-LOCK-HELD. The mailboxes
;;; hash-table is similarly protected. The monitor loop acquires the lock
;;; before iterating over agents, ensuring that concurrent registrations
;;; do not corrupt the iteration.
;;;
;;; MESSAGING
;;; ─────────
;;; Agents communicate via asynchronous message queues (simple lists stored
;;; in a hash-table). send-message prepends to the recipient's mailbox;
;;; receive-messages returns a copy of all pending messages. There is no
;;; blocking receive — this is a fire-and-forget system. Future versions
;;; may add blocking dequeues with condition variables.
;;;
;;; HEALING LADDER
;;; ──────────────
;;; When a condition is detected, the monitor loop establishes six restarts
;;; forming a ladder of escalating intervention:
;;;   1. :RETRY                — cheapest, for transient failures
;;;   2. :USE-FALLBACK         — degrade to safe strategy
;;;   3. :ESCALATE             — hand to orchestrator's own policy
;;;   4. :REPLACE-AGENT        — nuclear option: fresh instance
;;;   5. :HOTFIX-AND-CONTINUE  — live patch (the LISPMIND signature move)
;;;   6. :PAUSE-AND-SELF-MODIFY — introspect, adjust, resume
;;;
;;; The restart to invoke is selected by SELECT-RESTART, which delegates to
;;; the agent's restart-policy function (or the orchestrator's own policy
;;; when escalation occurs).
;;;
;;; META-COGNITION
;;; ──────────────
;;; If an agent repeatedly fails (> 3 errors) and has been repeatedly
;;; fallback-restarted, the system triggers meta-cognition: a diagnostic
;;; message is printed and the agent is flagged for hot-patching. This is
;;; the seed of self-improvement — the system notices that its own recovery
;;; actions are insufficient and asks for smarter code.
;;;
;;; "The orchestrator does not merely manage agents. It tends them, as a
;;;  gardener tends a garden — pruning the dead, nourishing the weak, and
;;;  planting anew when the soil must be refreshed."

(in-package :lispmind)

;; ───────────────────────────────────────────────────────────────────────────
;; Section 1: Special Variable — The Active Orchestrator Singleton
;; ───────────────────────────────────────────────────────────────────────────
;;
;; There is typically one orchestrator per LISPMIND instance. This special
;; variable holds the currently active orchestrator, set by START-ORCHESTRATOR
;; and cleared by STOP-ORCHESTRATOR. Dashboard and demo code reference it
;; so users don't need to pass orchestrator references everywhere.

(defparameter *default-orchestrator* nil
  "The currently active orchestrator instance.

Set by START-ORCHESTRATOR when an orchestrator is launched.
Cleared (set to NIL) by STOP-ORCHESTRATOR on graceful shutdown.

Intended usage:
  (start-orchestrator)                    ; sets *default-orchestrator*
  (register-agent *default-orchestrator* my-agent)
  (start-dashboard)                       ; uses *default-orchestrator* implicitly

Thread-safety: this is a special variable, not a lock-protected cell.
In production, pass the orchestrator explicitly rather than relying on
this global, except in interactive REPL sessions.")


;; ───────────────────────────────────────────────────────────────────────────
;; Section 2: Orchestrator Class — The Meta-Agent
;; ───────────────────────────────────────────────────────────────────────────
;;
;; The orchestrator inherits from AGENT because it IS an agent — a self-aware,
;; self-monitoring entity that can fail and be healed like any other. The
;; additional slots provide the supervisory substrate: a registry of agents,
;; mailboxes for inter-agent messaging, and thread handles for the monitor
;; and dashboard loops.

(defclass orchestrator (agent)
  ((agents
    :initform (make-hash-table :test 'eq)
    :accessor orchestrator-agents
    :documentation
    "Registry: agent-id → agent instance.

An EQ hash-table mapping each registered agent's ID (a symbol) to its
AGENT instance. All accesses are protected by MONITOR-LOCK. Agents are
added by REGISTER-AGENT and removed by DEREGISTER-AGENT.")

   (mailboxes
    :initform (make-hash-table :test 'eq)
    :accessor orchestrator-mailboxes
    :documentation
    "Message queues: agent-id → mailbox list.

An EQ hash-table mapping each registered agent's ID to a list of
messages. Messages are cons cells of the form (FROM-ID . MESSAGE).
The list is accessed LIFO (newest first) for simplicity. All accesses
are protected by MONITOR-LOCK.")

   (running-p
    :initform nil
    :accessor orchestrator-running-p
    :documentation
    "Is the orchestrator monitor loop currently running?

Set to T by START-ORCHESTRATOR before the monitor thread is spawned.
Set to NIL by STOP-ORCHESTRATOR to signal graceful shutdown. The
monitor loop checks this flag on each iteration.")

   (monitor-thread
    :initform nil
    :accessor orchestrator-monitor-thread
    :documentation
    "The monitor loop thread (a BT:THREAD instance) or NIL.

Set by START-ORCHESTRATOR when it spawns the monitor thread.
Cleared by STOP-ORCHESTRATOR after joining the thread. Used to prevent
double-start and to join during shutdown.")

   (dashboard-thread
    :initform nil
    :accessor orchestrator-dashboard-thread
    :documentation
    "The dashboard display thread (a BT:THREAD instance) or NIL.

Set when the dashboard is started (see dashboard.lisp). Cleared on
stop. The orchestrator tracks this so STOP-ORCHESTRATOR can shut down
the dashboard along with everything else.")

   (monitor-lock
    :initform (bt:make-lock "monitor-lock")
    :reader orchestrator-monitor-lock
    :documentation
    "Lock protecting all orchestrator mutable state.

This lock guards: agents registry, mailboxes, running-p flag, and
monitor-thread slot. The monitor loop acquires this lock before
iterating over agents. Registry operations (register, deregister)
hold this lock. The condition variable MONITOR-CVAR is associated
with this lock.")

   (monitor-cvar
    :initform (bt:make-condition-variable :name "monitor-cvar")
    :reader orchestrator-monitor-cvar
    :documentation
    "Condition variable to wake the monitor loop.

The monitor loop sleeps on this cvar with a 2-second timeout. When
STOP-ORCHESTRATOR needs to shut down quickly, it signals this cvar
to wake the monitor immediately rather than waiting for the full
timeout. This makes shutdown responsive — no unnecessary delays."))

  (:documentation
   "The orchestrator is the supreme agent — it manages a swarm of agents,
monitors their health, handles their failures via restarts, and can even heal itself.

The orchestrator inherits from AGENT, which means it has its own health,
heartbeat, strategy, and can participate in the same restart protocol as
the agents it supervises. This recursive design means the system can
recover from orchestrator failures as well as agent failures.

Key capabilities:
  • Agent registry — add, remove, and iterate over supervised agents
  • Health monitoring — check heartbeats every 2 seconds, detect failures
  • Condition handling — signal conditions and invoke restarts via handler-bind
  • Inter-agent messaging — asynchronous fire-and-forget message queues
  • Healing — apply named restarts to sick agents
  • Meta-cognition — detect patterns of repeated failure and trigger hot-patching

Create with MAKE-ORCHESTRATOR, launch with START-ORCHESTRATOR, stop with
STOP-ORCHESTRATOR."))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 3: Constructor
;; ───────────────────────────────────────────────────────────────────────────

(defun make-orchestrator (&rest initargs)
  "Create a new ORCHESTRATOR instance with the given initargs.

Usage: (make-orchestrator :health 100 :capabilities '(:supervise :heal :patch))

All standard AGENT initargs are accepted: :ID :HEALTH :STRATEGY
:CAPABILITIES :RESTART-POLICY :STATE :HEARTBEAT :ERROR-COUNT :STATUS :VERSION.

The orchestrator is created with:
  • An empty agent registry (EQ hash-table)
  • An empty mailbox table (EQ hash-table)
  • running-p = NIL (not yet started)
  • A fresh monitor-lock and condition variable
  • A gensym'd ID (or the provided :ID initarg)

Returns the new orchestrator instance. The caller must call
START-ORCHESTRATOR to launch the monitor thread."
  (apply #'make-instance 'orchestrator initargs))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 4: Lifecycle — Start and Stop
;; ───────────────────────────────────────────────────────────────────────────
;;
;; Starting an orchestrator means spawning the monitor thread and setting
;; the *default-orchestrator* singleton. Stopping means signaling the monitor
;; to exit, waking it via the condition variable, and joining the thread.

(defun start-orchestrator (&optional (orchestrator (make-orchestrator)))
  "Start the orchestrator's monitor thread and set *DEFAULT-ORCHESTRATOR*.

If no orchestrator is provided, a fresh one is created via MAKE-ORCHESTRATOR.

Steps:
  1. Acquire the orchestrator's monitor-lock.
  2. If already running (running-p is T), release lock and return immediately.
  3. Set running-p to T.
  4. Spawn the monitor thread (bt:make-thread #'monitor-loop).
  5. Set *DEFAULT-ORCHESTRATOR* to this orchestrator.
  6. Print startup message.

The monitor thread runs MONITOR-LOOP, which checks agent health every
2 seconds and handles conditions via handler-bind.

Returns the started orchestrator.

Example:
  (defparameter *my-orch* (start-orchestrator))
  ;; Now register agents...
  (register-agent *my-orch* (make-agent :id 'worker-1))"
  (bt:with-lock-held ((orchestrator-monitor-lock orchestrator))
    (when (orchestrator-running-p orchestrator)
      (format *trace-output* "~&[ORCH] Orchestrator ~A already running.~%"
              (agent-id orchestrator))
      (return-from start-orchestrator orchestrator))
    ;; Mark as running before spawning thread to avoid race
    (setf (orchestrator-running-p orchestrator) t)
    ;; Spawn the monitor thread
    (setf (orchestrator-monitor-thread orchestrator)
          (bt:make-thread
           (lambda () (monitor-loop orchestrator))
           :name (format nil "monitor-~A" (agent-id orchestrator))
           :initial-bindings '())))
  ;; Set the global singleton (outside the lock — special variable, not shared state)
  (setf *default-orchestrator* orchestrator)
  (format *trace-output* "~&[ORCH] Orchestrator ~A started. Monitor thread: ~A~%"
          (agent-id orchestrator)
          (bt:thread-name (orchestrator-monitor-thread orchestrator)))
  orchestrator)

(defun stop-orchestrator (orchestrator)
  "Stop the orchestrator gracefully.

Steps:
  1. Acquire the orchestrator's monitor-lock.
  2. If not running (running-p is NIL), release lock and return.
  3. Set running-p to NIL — this signals the monitor loop to exit.
  4. Signal the condition variable to wake the monitor immediately.
  5. Release the lock.
  6. Join the monitor thread (wait for it to finish).
  7. If a dashboard thread exists, note it (dashboard.lisp handles its own stop).
  8. Clear *DEFAULT-ORCHESTRATOR* if it points to this orchestrator.

This function blocks until the monitor thread has exited. The condition
variable signal ensures the monitor wakes promptly rather than waiting
for its full 2-second sleep timeout.

Returns the stopped orchestrator.

Example:
  (stop-orchestrator *my-orch*)
  ;; All agents are still in the registry but are no longer monitored."
  (bt:with-lock-held ((orchestrator-monitor-lock orchestrator))
    (unless (orchestrator-running-p orchestrator)
      (format *trace-output* "~&[ORCH] Orchestrator ~A is not running.~%"
              (agent-id orchestrator))
      (return-from stop-orchestrator orchestrator))
    ;; Signal shutdown
    (setf (orchestrator-running-p orchestrator) nil)
    ;; Wake the monitor so it notices the shutdown flag immediately
    (bt:condition-notify (orchestrator-monitor-cvar orchestrator)))
  ;; Join the monitor thread (outside the lock to avoid deadlock)
  (when (orchestrator-monitor-thread orchestrator)
    (bt:join-thread (orchestrator-monitor-thread orchestrator))
    (setf (orchestrator-monitor-thread orchestrator) nil))
  ;; Clear the global singleton if we own it
  (when (eq *default-orchestrator* orchestrator)
    (setf *default-orchestrator* nil))
  (format *trace-output* "~&[ORCH] Orchestrator ~A stopped gracefully.~%"
          (agent-id orchestrator))
  orchestrator)


;; ───────────────────────────────────────────────────────────────────────────
;; Section 5: Agent Registry — Register and Deregister
;; ───────────────────────────────────────────────────────────────────────────
;;
;; These functions manage the agents hash-table. All mutations hold the
;; monitor-lock. When an agent is registered, a mailbox is created for it.
;; When deregistered, the mailbox is cleaned up.

(defun register-agent (orchestrator agent)
  "Add an agent to the orchestrator's registry and create a mailbox for it.

Acquires the orchestrator's monitor-lock, inserts the agent into the
AGENTS hash-table keyed by its ID, and creates an empty mailbox list
in the MAILBOXES hash-table under the same key.

If an agent with the same ID already exists, it is silently replaced.
This is intentional: REGISTER-AGENT is idempotent.

Also prints a notification to *TRACE-OUTPUT*.

Returns the registered agent.

Example:
  (register-agent *orch* (make-agent :id 'scraper-1 :capabilities '(:fetch)))"
  (let ((agent-id (agent-id agent)))
    (bt:with-lock-held ((orchestrator-monitor-lock orchestrator))
      (setf (gethash agent-id (orchestrator-agents orchestrator)) agent)
      (setf (gethash agent-id (orchestrator-mailboxes orchestrator)) '()))
    (format *trace-output* "~&[ORCH] Registered agent ~A (capabilities: ~S)~%"
            agent-id (agent-capabilities agent))
    agent))

(defun deregister-agent (orchestrator agent-id)
  "Remove an agent from the registry and clean up its mailbox.

Acquires the orchestrator's monitor-lock, removes the agent from the
AGENTS hash-table (if present), and removes its mailbox from the
MAILBOXES hash-table. Returns T if the agent was found and removed,
NIL if no such agent existed.

This is a safe operation: the agent object itself is not destroyed,
merely removed from the orchestrator's supervision. The agent can be
re-registered later if desired.

Example:
  (deregister-agent *orch* 'scraper-1)  ; → T or NIL"
  (bt:with-lock-held ((orchestrator-monitor-lock orchestrator))
    (remhash agent-id (orchestrator-agents orchestrator))
    (remhash agent-id (orchestrator-mailboxes orchestrator)))
  (format *trace-output* "~&[ORCH] Deregistered agent ~A~%" agent-id))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 6: Inter-Agent Messaging
;; ───────────────────────────────────────────────────────────────────────────
;;
;; A simple fire-and-forget messaging system. Each registered agent has a
;; mailbox (a list). send-message prepends a message; receive-messages
;; returns a fresh list of all pending messages (non-destructive read).

(defun send-message (orchestrator from-id to-id message)
  "Send a message from one agent to another via their mailboxes.

The message is stored as a cons cell (FROM-ID . MESSAGE) in the
recipient's mailbox list. The recipient can retrieve messages via
RECEIVE-MESSAGES.

If TO-ID is not a registered agent, a warning is printed and the message
is discarded. This is the fire-and-forget model: delivery is best-effort.

Acquires the orchestrator's monitor-lock briefly to mutate the mailbox.

Returns the message (for convenience).

Example:
  (send-message *orch* 'scraper-1 'analyst-2 '(data . \"page-42-results\"))
  (receive-messages *orch* 'analyst-2)
    ;; → ((SCRAPER-1 DATA . \"page-42-results\"))"
  (bt:with-lock-held ((orchestrator-monitor-lock orchestrator))
    (let ((mailbox (gethash to-id (orchestrator-mailboxes orchestrator))))
      (if mailbox
          (setf (gethash to-id (orchestrator-mailboxes orchestrator))
                (cons (cons from-id message) mailbox))
          (format *trace-output*
                  "~&[ORCH] WARNING: Cannot send message to unregistered agent ~A~%"
                  to-id))))
  message)

(defun receive-messages (orchestrator agent-id)
  "Retrieve all pending messages for an agent (non-destructive read).

Returns a COPY of the agent's mailbox list. Each element is a cons cell
of the form (SENDER-ID . MESSAGE). The original mailbox is NOT modified —
this is a read-only operation. To clear messages, use CLEAR-MESSAGES.

If AGENT-ID is not registered, returns NIL.

Acquires the orchestrator's monitor-lock for the duration of the copy.

Example:
  (receive-messages *orch* 'analyst-2)
    ;; → ((SCRAPER-1 . \"results for page 42\") (SCRAPER-3 . \"results for page 7\"))"
  (bt:with-lock-held ((orchestrator-monitor-lock orchestrator))
    (let ((mailbox (gethash agent-id (orchestrator-mailboxes orchestrator))))
      (when mailbox
        (copy-list mailbox)))))

(defun clear-messages (orchestrator agent-id)
  "Clear all pending messages for an agent.

Sets the agent's mailbox to the empty list. Returns the previous mailbox
contents (the messages that were cleared), or NIL if the agent is not
registered.

Acquires the orchestrator's monitor-lock."
  (bt:with-lock-held ((orchestrator-monitor-lock orchestrator))
    (let ((old-mailbox (gethash agent-id (orchestrator-mailboxes orchestrator))))
      (when old-mailbox
        (setf (gethash agent-id (orchestrator-mailboxes orchestrator)) '())
        old-mailbox))))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 7: Fallback Strategy
;; ───────────────────────────────────────────────────────────────────────────
;;
;; When the :USE-FALLBACK restart is invoked, the agent's strategy is
;; replaced with this function. It does the minimal possible work — just
;; enough to signal that the agent is alive and running in degraded mode.

(defun fallback-strategy (agent)
  "A safe fallback strategy that does minimal work.

This function is installed as the agent's strategy when the :USE-FALLBACK
restart is invoked. It prints a brief message indicating degraded mode
and returns NIL immediately. This ensures the agent consumes no resources
and cannot fail, while still being alive for the orchestrator to monitor.

The fallback strategy is the system's degradation mode: the agent survives
but does not progress. This gives the orchestrator (or a human operator)
time to diagnose and apply a proper fix (e.g., hot-patching).

Example:
  ;; :USE-FALLBACK restart installs this:
  (setf (agent-strategy agent) #'fallback-strategy)"
  (format *trace-output* "~&[FALLBACK] Agent ~A running in degraded mode~%"
          (agent-id agent))
  nil)


;; ───────────────────────────────────────────────────────────────────────────
;; Section 8: The Monitor Loop — The Beating Heart of LISPMIND
;; ───────────────────────────────────────────────────────────────────────────
;;
;; This is the most important function in the entire system. It runs in a
;; dedicated thread, wakes every 2 seconds, and performs these duties:
;;
;;   1. Acquire the monitor-lock.
;;   2. Check running-p — if NIL, exit the loop (graceful shutdown).
;;   3. Iterate over all registered agents.
;;   4. For each agent, check if it is alive (AGENT-ALIVE-P).
;;   5. If dead, signal AGENT-FAILURE.
;;   6. If error-count > 5, trigger healing.
;;   7. If error-count > 3 with multiple fallbacks, trigger meta-cognition.
;;   8. Handle all conditions via HANDLER-BIND with all 6 restarts.
;;   9. Release the lock.
;;  10. Wait on the condition variable with 2-second timeout.
;;
;; WHY HANDLER-BIND (NOT HANDLER-CASE)
;; ───────────────────────────────────
;; HANDLER-BIND binds handlers WITHOUT unwinding the stack. When a condition
;; is signaled inside the monitor loop, the handler sees the FULL CALL STACK
;; as it was when trouble struck. This means restarts established by
;; RESTART-CASE inside the handler-bind are visible and invocable.
;;
;; HANDLER-CASE would UNWIND the stack before running the handler, destroying
;; the very context we need to recover. Restarts would be invisible because
;; the stack frame that established them would already be gone.
;;
;; This is not a stylistic choice — it is a semantic necessity. LISPMIND's
;; entire healing philosophy depends on handler-bind supremacy.

(defun monitor-loop (orchestrator)
  "The orchestrator's heart. Runs in a separate thread.

This function implements the main monitoring loop that checks agent health,
detects failures, and triggers healing via Common Lisp's condition/restart
system. It runs until STOP-ORCHESTRATOR sets RUNNING-P to NIL.

Loop cycle:
  1. Acquire monitor-lock.
  2. If running-p is NIL, release lock and return (shutdown).
  3. For each registered agent:
     a. Check ALIVE-P — if dead, signal AGENT-FAILURE.
     b. If error-count > 5, initiate healing.
     c. If error-count > 3 with repeated fallbacks, trigger meta-cognition.
  4. Release monitor-lock.
  5. Wait on monitor-cvar with 2-second timeout.

All condition handling uses HANDLER-BIND (not HANDLER-CASE) to preserve
restart visibility. Six restarts are available: :RETRY, :USE-FALLBACK,
:ESCALATE, :REPLACE-AGENT, :HOTFIX-AND-CONTINUE, :PAUSE-AND-SELF-MODIFY.

This function never returns normally except during graceful shutdown. Any
unexpected error is caught at the outermost level, logged, and the loop
continues — the monitor must never die."
  (format *trace-output* "~&[MONITOR] Monitor loop for ~A starting...~%"
          (agent-id orchestrator))
  (loop
    ;; ── Check shutdown flag (with lock held for consistency) ──────────────
    (bt:with-lock-held ((orchestrator-monitor-lock orchestrator))
      (unless (orchestrator-running-p orchestrator)
        (format *trace-output* "~&[MONITOR] Shutdown signal received. Exiting.~%")
        (return-from monitor-loop nil))

      ;; ── Iterate over all registered agents ──────────────────────────────
      ;; We use maphash to visit each agent. For each one, we check vitals
      ;; and potentially signal conditions. The handler-bind wraps each
      ;; agent check so that conditions are caught and restarts applied
      ;; individually per-agent.
      (maphash
       (lambda (aid agent)
         (declare (ignore aid))  ; agent-id is also accessible via agent
         (handler-bind
             ;; ── Condition handlers: one per condition type ──────────────
             ;; Each handler logs the condition, then decides which restart
             ;; to invoke based on the agent's restart-policy function.
             ;; The restart is invoked via INVOKE-RESTART after finding it
             ;; with FIND-RESTART. If no restart is found, the handler
             ;; returns normally and the condition propagulates.
             ((agent-failure
               (lambda (condition)
                 (format *trace-output*
                         "~&[MONITOR] AGENT-FAILURE detected: ~A~%"
                         condition)
                 ;; Let the restart policy decide what to do
                 (let ((restart-name (select-restart orchestrator agent condition)))
                   (case restart-name
                     (:replace-agent
                      (when (find-restart 'replace-agent)
                        (invoke-restart 'replace-agent)))
                     (:escalate
                      (when (find-restart 'escalate)
                        (invoke-restart 'escalate)))
                     (otherwise
                      (when (find-restart 'use-fallback)
                        (invoke-restart 'use-fallback)))))))

              (strategy-stalled
               (lambda (condition)
                 (format *trace-output*
                         "~&[MONITOR] STRATEGY-STALLED detected: ~A~%"
                         condition)
                 (let ((restart-name (select-restart orchestrator agent condition)))
                   (case restart-name
                     (:hotfix-and-continue
                      (when (find-restart 'hotfix-and-continue)
                        (invoke-restart 'hotfix-and-continue)))
                     (:escalate
                      (when (find-restart 'escalate)
                        (invoke-restart 'escalate)))
                     (otherwise
                      (when (find-restart 'pause-and-self-modify)
                        (invoke-restart 'pause-and-self-modify)))))))

              (resource-exhausted
               (lambda (condition)
                 (format *trace-output*
                         "~&[MONITOR] RESOURCE-EXHAUSTED detected: ~A~%"
                         condition)
                 (let ((restart-name (select-restart orchestrator agent condition)))
                   (case restart-name
                     (:pause-and-self-modify
                      (when (find-restart 'pause-and-self-modify)
                        (invoke-restart 'pause-and-self-modify)))
                     (:escalate
                      (when (find-restart 'escalate)
                        (invoke-restart 'escalate)))
                     (otherwise
                      (when (find-restart 'use-fallback)
                        (invoke-restart 'use-fallback)))))))

              (external-timeout
               (lambda (condition)
                 (format *trace-output*
                         "~&[MONITOR] EXTERNAL-TIMEOUT detected: ~A~%"
                         condition)
                 (let ((restart-name (select-restart orchestrator agent condition)))
                   (case restart-name
                     (:retry
                      (when (find-restart 'retry)
                        (invoke-restart 'retry)))
                     (:use-fallback
                      (when (find-restart 'use-fallback)
                        (invoke-restart 'use-fallback)))
                     (:escalate
                      (when (find-restart 'escalate)
                        (invoke-restart 'escalate)))
                     (otherwise
                      (when (find-restart 'retry)
                        (invoke-restart 'retry))))))))

           ;; ── Restart-case: all 6 restarts established ─────────────────
           ;; Inside the handler-bind, we establish the restart ladder.
           ;; When a handler above invokes a restart, control transfers
           ;; to one of these cases. The stack is NOT unwound — we resume
           ;; execution in the same dynamic context.
           (restart-case
               (progn
                 ;; ── Core health check ─────────────────────────────────
                 (unless (agent-alive-p agent)
                   ;; Agent is dead — signal the condition
                   (signal-condition 'agent-failure
                                     :agent-id (agent-id agent)
                                     :reason (format nil "Agent ~A not alive (health=~A, heartbeat stale)"
                                                     (agent-id agent)
                                                     (agent-health agent))))

                 ;; ── Error-count threshold check ───────────────────────
                 (when (> (agent-error-count agent) 5)
                   (format *trace-output*
                           "~&[MONITOR] Agent ~A has ~A errors — triggering healing~%"
                           (agent-id agent) (agent-error-count agent))
                   (signal-condition 'agent-failure
                                     :agent-id (agent-id agent)
                                     :reason (format nil "Error count ~A exceeds threshold"
                                                     (agent-error-count agent))))

                 ;; ── Meta-cognition check ──────────────────────────────
                 (check-meta-cognition orchestrator agent))

             ;; ── The six canonical restarts ────────────────────────────
             (retry (&optional value)
               :report (lambda (stream)
                         (format stream "Retry the failed operation."))
               :test (lambda (c) (declare (ignore c)) t)
               (format *trace-output*
                       "~&[MONITOR] :RETRY restart invoked for agent ~A (value: ~S)~%"
                       (agent-id agent) value)
               ;; Decrement error count as a gesture of optimism
               (bt:with-lock-held ((agent-lock agent))
                 (decf (agent-error-count agent))))

             (use-fallback ()
               :report (lambda (stream)
                         (format stream "Switch to fallback strategy."))
               :test (lambda (c) (declare (ignore c)) t)
               (format *trace-output*
                       "~&[MONITOR] :USE-FALLBACK restart invoked for agent ~A~%"
                       (agent-id agent))
               (bt:with-lock-held ((agent-lock agent))
                 (setf (agent-strategy agent) #'fallback-strategy)
                 (setf (agent-status agent) :running)))

             (escalate ()
               :report (lambda (stream)
                         (format stream "Escalate to orchestrator."))
               :test (lambda (c) (declare (ignore c)) t)
               (format *trace-output*
                       "~&[MONITOR] :ESCALATE restart invoked for agent ~A — delegating to orchestrator policy~%"
                       (agent-id agent))
               ;; Apply the orchestrator's own restart policy
               (let ((orch-restart (funcall (agent-restart-policy orchestrator)
                                            (make-condition 'agent-failure
                                                           :agent-id (agent-id agent)
                                                           :reason "Escalated from agent")
                                            orchestrator)))
                 (format *trace-output*
                         "~&[MONITOR] Orchestrator policy selected: ~A~%"
                         orch-restart)))

             (replace-agent ()
               :report (lambda (stream)
                         (format stream "Terminate and replace the agent."))
               :test (lambda (c) (declare (ignore c)) t)
               (format *trace-output*
                       "~&[MONITOR] :REPLACE-AGENT restart invoked for agent ~A~%"
                       (agent-id agent))
               (let ((old-capabilities (agent-capabilities agent))
                     (old-id (agent-id agent)))
                 ;; Create replacement agent with same capabilities
                 (let ((new-agent (make-agent :id old-id
                                               :capabilities old-capabilities)))
                   (setf (gethash old-id (orchestrator-agents orchestrator))
                         new-agent)
                   (setf (gethash old-id (orchestrator-mailboxes orchestrator))
                         '()))))

             (hotfix-and-continue ()
               :report (lambda (stream)
                         (format stream "Hot-patch strategy and continue."))
               :test (lambda (c) (declare (ignore c)) t)
               (format *trace-output*
                       "~&[MONITOR] :HOTFIX-AND-CONTINUE restart invoked for agent ~A~%"
                       (agent-id agent))
               ;; Placeholder: the actual hotfix is applied by hotpatch.lisp's
               ;; HOTPATCH-AGENT function. Here we mark the agent as healing
               ;; and set a flag in its state for the hotpatch system to pick up.
               ;; This is the integration point with hotpatch.lisp.
               (bt:with-lock-held ((agent-lock agent))
                 (setf (agent-status agent) :healing)
                 ;; Set a flag in agent state that hotpatch.lisp will check
                 (setf (gethash :hotfix-requested (agent-state agent)) t)
                 (format *trace-output*
                         "~&[MONITOR] Hotfix flag set for agent ~A — hotpatch.lisp will apply patch~%"
                         (agent-id agent))))

             (pause-and-self-modify ()
               :report (lambda (stream)
                         (format stream "Pause agent for introspection."))
               :test (lambda (c) (declare (ignore c)) t)
               (format *trace-output*
                       "~&[MONITOR] :PAUSE-AND-SELF-MODIFY restart invoked for agent ~A~%"
                       (agent-id agent))
               (bt:with-lock-held ((agent-lock agent))
                 (setf (agent-status agent) :paused))
               ;; Print an introspection prompt — this is the self-modification hook
               (format *trace-output*
                       "~&[MONITOR] ╔══════════════════════════════════════════════════════════════╗~%")
               (format *trace-output*
                       "~&[MONITOR] ║  Agent ~A is PAUSED for introspection.~%"
                       (agent-id agent))
               (format *trace-output*
                       "~&[MONITOR] ║  Review its state with: (inspect-agent '~A)~%"
                       (agent-id agent))
               (format *trace-output*
                       "~&[MONITOR] ║  Resume with: (setf (agent-status <agent>) :running)~%")
               (format *trace-output*
                       "~&[MONITOR] ╚══════════════════════════════════════════════════════════════╝~%")))))
       (orchestrator-agents orchestrator)))

    ;; ── Wait for next cycle ──────────────────────────────────────────────
    ;; We use a condition variable with a timeout rather than sleep.
    ;; This makes shutdown responsive: STOP-ORCHESTRATOR signals the cvar,
    ;; waking us immediately instead of waiting the full 2 seconds.
    (bt:with-lock-held ((orchestrator-monitor-lock orchestrator))
      (when (orchestrator-running-p orchestrator)
        (bt:condition-wait (orchestrator-monitor-cvar orchestrator)
                           (orchestrator-monitor-lock orchestrator)
                           :timeout 2))))

  ;; ── Graceful exit ─────────────────────────────────────────────────────
  (format *trace-output* "~&[MONITOR] Monitor loop for ~A exited cleanly.~%"
          (agent-id orchestrator)))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 9: Healing System
;; ───────────────────────────────────────────────────────────────────────────
;;
;; The healing system provides programmatic control over restart invocation.
;; SELECT-RESTART chooses which restart to use based on the condition and
;; agent state. HEAL-AGENT applies a specific restart by name.

(defun select-restart (orchestrator agent condition)
  "Select the best restart for a condition. Currently rule-based.

Delegates to the agent's restart-policy function, which returns a restart
keyword based on condition type and agent history. If the restart-policy
returns an unrecognized keyword, falls back to :ESCALATE.

This function is called by the monitor loop's condition handlers to decide
which restart to invoke via INVOKE-RESTART.

Arguments:
  ORCHESTRATOR — the orchestrator managing the agent
  AGENT        — the agent that signalled the condition
  CONDITION    — the condition instance that was signalled

Returns a keyword: one of :RETRY :USE-FALLBACK :ESCALATE :REPLACE-AGENT
:HOTFIX-AND-CONTINUE :PAUSE-AND-SELF-MODIFY.

Example:
  (select-restart *orch* my-agent some-condition)  ; → :retry"
  (declare (ignore orchestrator))
  (let ((restart-keyword (funcall (agent-restart-policy agent) condition agent)))
    (if (member restart-keyword
                '(:retry :use-fallback :escalate :replace-agent
                  :hotfix-and-continue :pause-and-self-modify))
        restart-keyword
        :escalate)))

(defun heal-agent (orchestrator agent-id restart-name)
  "Apply a named restart to an agent.

Looks up the agent in the orchestrator's registry by AGENT-ID. If found,
creates a synthetic condition and establishes all six restarts, then
invokes the named one. If the agent is not found, prints a warning.

This is the public API for manual healing — it allows a human operator
(or the dashboard) to force a specific recovery action on an agent.

Arguments:
  ORCHESTRATOR — the orchestrator managing the agent
  AGENT-ID     — the ID (symbol) of the agent to heal
  RESTART-NAME — keyword naming the restart to invoke
                 (:retry :use-fallback :escalate :replace-agent
                  :hotfix-and-continue :pause-and-self-modify)

Returns T if the restart was invoked, NIL if the agent was not found or
the restart is not available.

Example:
  (heal-agent *orch* 'scraper-1 :hotfix-and-continue)
  (heal-agent *orch* 'analyst-2 :replace-agent)"
  (let ((agent (bt:with-lock-held ((orchestrator-monitor-lock orchestrator))
                 (gethash agent-id (orchestrator-agents orchestrator)))))
    (unless agent
      (format *trace-output* "~&[HEAL] No agent with ID ~A found in registry.~%"
              agent-id)
      (return-from heal-agent nil))
    (format *trace-output* "~&[HEAL] Applying restart ~A to agent ~A...~%"
            restart-name agent-id)
    ;; Establish all restarts, then invoke the requested one
    (restart-case
        (progn
          ;; Signal a synthetic condition to trigger the handler-bind path
          (signal-condition 'agent-failure
                            :agent-id agent-id
                            :reason (format nil "Manual healing: ~A" restart-name))
          ;; If no handler transferred control, invoke the restart directly
          (case restart-name
            (:retry (when (find-restart 'retry) (invoke-restart 'retry)))
            (:use-fallback (when (find-restart 'use-fallback)
                             (invoke-restart 'use-fallback)))
            (:escalate (when (find-restart 'escalate)
                         (invoke-restart 'escalate)))
            (:replace-agent (when (find-restart 'replace-agent)
                              (invoke-restart 'replace-agent)))
            (:hotfix-and-continue (when (find-restart 'hotfix-and-continue)
                                    (invoke-restart 'hotfix-and-continue)))
            (:pause-and-self-modify (when (find-restart 'pause-and-self-modify)
                                      (invoke-restart 'pause-and-self-modify)))))
      (retry ()
        :report (lambda (stream) (format stream "Retry the failed operation."))
        (format *trace-output* "~&[HEAL] :RETRY applied to ~A~%" agent-id)
        (bt:with-lock-held ((agent-lock agent))
          (decf (agent-error-count agent)))
        t)
      (use-fallback ()
        :report (lambda (stream) (format stream "Switch to fallback strategy."))
        (format *trace-output* "~&[HEAL] :USE-FALLBACK applied to ~A~%" agent-id)
        (bt:with-lock-held ((agent-lock agent))
          (setf (agent-strategy agent) #'fallback-strategy)
          (setf (agent-status agent) :running))
        t)
      (escalate ()
        :report (lambda (stream) (format stream "Escalate to orchestrator."))
        (format *trace-output* "~&[HEAL] :ESCALATE applied to ~A~%" agent-id)
        t)
      (replace-agent ()
        :report (lambda (stream) (format stream "Terminate and replace the agent."))
        (format *trace-output* "~&[HEAL] :REPLACE-AGENT applied to ~A~%" agent-id)
        (let ((old-capabilities (agent-capabilities agent))
              (old-id (agent-id agent)))
          (let ((new-agent (make-agent :id old-id
                                        :capabilities old-capabilities)))
            (bt:with-lock-held ((orchestrator-monitor-lock orchestrator))
              (setf (gethash old-id (orchestrator-agents orchestrator)) new-agent)
              (setf (gethash old-id (orchestrator-mailboxes orchestrator)) '()))))
        t)
      (hotfix-and-continue ()
        :report (lambda (stream) (format stream "Hot-patch strategy and continue."))
        (format *trace-output* "~&[HEAL] :HOTFIX-AND-CONTINUE applied to ~A~%" agent-id)
        (bt:with-lock-held ((agent-lock agent))
          (setf (agent-status agent) :healing)
          (setf (gethash :hotfix-requested (agent-state agent)) t))
        t)
      (pause-and-self-modify ()
        :report (lambda (stream) (format stream "Pause agent for introspection."))
        (format *trace-output* "~&[HEAL] :PAUSE-AND-SELF-MODIFY applied to ~A~%" agent-id)
        (bt:with-lock-held ((agent-lock agent))
          (setf (agent-status agent) :paused))
        t))))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 10: Meta-Cognition — Auto-Hotfix Trigger
;; ───────────────────────────────────────────────────────────────────────────
;;
;; Meta-cognition is the system's ability to observe its own recovery
;; patterns and decide that they are insufficient. When an agent has been
;; repeatedly fallback-restarted but continues to fail, the system recognizes
;; that the fallback is not a solution — it is merely a band-aid. It then
;; triggers a meta-cognitive event, printing a diagnostic and preparing the
;; agent for hot-patching.
;;
;; This is the seed of self-improvement: the system notices that its own
;; healing actions are not working, and asks for better code.

(defun check-meta-cognition (orchestrator agent)
  "Check if an agent has had too many failures and trigger auto-hotfix.

If the agent's error-count > 3 AND the agent has the :fallback-count key
in its state hash-table with a value > 1, print a meta-cognition message
and prepare the agent for hot-patching.

The :fallback-count is incremented by the :USE-FALLBACK restart handler.
This tracks how many times the agent has been degraded to fallback mode.
If it keeps failing even in fallback (or keeps getting fallback-restarted),
something deeper is wrong — the agent needs new code, not just a restart.

This function is called by the monitor loop during each agent check.
It does not itself signal conditions; it merely prints diagnostic output
and sets a flag that the hotpatch system (hotpatch.lisp) can observe.

Arguments:
  ORCHESTRATOR — the orchestrator managing the agent
  AGENT        — the agent to check

Returns T if meta-cognition was triggered, NIL otherwise."
  (declare (ignore orchestrator))
  (let ((error-count (agent-error-count agent))
        (fallback-count (or (gethash :fallback-count (agent-state agent)) 0)))
    (when (and (> error-count 3)
               (> fallback-count 1))
      ;; Meta-cognition triggered
      (format *trace-output*
              "~&[META] ╔══════════════════════════════════════════════════════════════╗~%")
      (format *trace-output*
              "~&[META] ║  META-COGNITION TRIGGERED for agent ~A~%"
              (agent-id agent))
      (format *trace-output*
              "~&[META] ║  Error count: ~A | Fallback count: ~A~%"
              error-count fallback-count)
      (format *trace-output*
              "~&[META] ║  Pattern: repeated failures despite fallback restarts.~%")
      (format *trace-output*
              "~&[META] ║  Action: Preparing agent for hot-patch.~%")
      (format *trace-output*
              "~&[META] ║  Use (hotpatch-agent '~A :new-strategy #'your-fix)~%"
              (agent-id agent))
      (format *trace-output*
              "~&[META] ╚══════════════════════════════════════════════════════════════╝~%")
      ;; Set the hotfix-requested flag so hotpatch.lisp will take action
      (setf (gethash :hotfix-requested (agent-state agent)) t)
      ;; Also set a meta-cognition flag for logging/analysis
      (setf (gethash :meta-cognition-triggered (agent-state agent)) (local-time:now))
      t)))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 11: Orchestrator Notification Specializations
;; ───────────────────────────────────────────────────────────────────────────
;;
;; These :AFTER methods specialize the NOTIFY-HEALTH-CHANGE and
;; NOTIFY-STATUS-CHANGE generic functions for the ORCHESTRATOR class.
;; They complement the default methods (defined in agent-class.lisp) with
;; orchestrator-specific behavior: critical health warnings and status
;; change logging.

(defmethod notify-health-change :after ((agent orchestrator) old-value new-value)
  "Orchestrator health change — if health drops below 50, print warning.

This :AFTER method runs after the default NOTIFY-HEALTH-CHANGE method
(defined in agent-class.lisp) which prints the basic transition message.
We add an additional warning when the orchestrator's own health drops
below the critical threshold of 50, because a sick orchestrator cannot
heal its agents.

If health drops to 0, an additional critical alert is printed — the
orchestrator itself needs healing."
  (when (< new-value 50)
    (format *trace-output*
            "~&[ORCH-WARN] ╔═══════════════════════════════════════════════════════╗~%")
    (format *trace-output*
            "~&[ORCH-WARN] ║  ORCHESTRATOR ~A HEALTH CRITICAL: ~A~%"
            (agent-id agent) new-value)
    (format *trace-output*
            "~&[ORCH-WARN] ║  A sick orchestrator cannot heal its agents.~%")
    (format *trace-output*
            "~&[ORCH-WARN] ╚═══════════════════════════════════════════════════════╝~%"))
  (when (<= new-value 0)
    (format *trace-output*
            "~&[ORCH-CRIT] ╔═══════════════════════════════════════════════════════╗~%")
    (format *trace-output*
            "~&[ORCH-CRIT] ║  ORCHESTRATOR ~A HEALTH ZERO — SYSTEM COMPROMISED~%"
            (agent-id agent))
    (format *trace-output*
            "~&[ORCH-CRIT] ║  Consider restarting the orchestrator.~%")
    (format *trace-output*
            "~&[ORCH-CRIT] ╚═══════════════════════════════════════════════════════╝~%")))

(defmethod notify-status-change :after ((agent orchestrator) old-status new-status)
  "Orchestrator status change — log to console with emphasis.

This :AFTER method runs after the default NOTIFY-STATUS-CHANGE method.
It adds orchestrator-specific emphasis because an orchestrator status
change affects ALL supervised agents. When the orchestrator goes to
:PAUSED or :FAILED, every agent is effectively orphaned."
  (format *trace-output*
          "~&[ORCH-STATUS] Orchestrator ~A: ~A → ~A [affects ~A supervised agent(s)]~%"
          (agent-id agent)
          old-status
          new-status
          (hash-table-count (orchestrator-agents agent))))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 12: Utility Functions
;; ───────────────────────────────────────────────────────────────────────────
;;
;; Convenience functions for inspecting the orchestrator's state.

(defun list-agents (&optional (orchestrator *default-orchestrator*))
  "Return a list of all registered agents in the orchestrator.

Returns an alist of (AGENT-ID . AGENT-INSTANCE) for each registered agent.
If no orchestrator is provided, uses *DEFAULT-ORCHESTRATOR*.

Acquires the monitor-lock briefly to copy the registry.

Example:
  (list-agents *my-orch*)
    ;; → ((SCRAPER-1 . #<AGENT ...>) (ANALYST-2 . #<AGENT ...>))"
  (unless orchestrator
    (error "No orchestrator provided and *DEFAULT-ORCHESTRATOR* is NIL."))
  (bt:with-lock-held ((orchestrator-monitor-lock orchestrator))
    (let ((result '()))
      (maphash (lambda (id agent)
                 (push (cons id agent) result))
               (orchestrator-agents orchestrator))
      (nreverse result))))

(defun inspect-agent (agent-id &optional (orchestrator *default-orchestrator*))
  "Print a detailed inspection report for an agent.

Looks up the agent by ID in the orchestrator's registry and prints a
comprehensive report including: id, health, status, error-count, version,
capabilities, heartbeat age, strategy name, and state contents.

If the agent is not found, prints a warning.

Example:
  (inspect-agent 'scraper-1 *my-orch*)"
  (unless orchestrator
    (error "No orchestrator provided and *DEFAULT-ORCHESTRATOR* is NIL."))
  (let ((agent (bt:with-lock-held ((orchestrator-monitor-lock orchestrator))
                 (gethash agent-id (orchestrator-agents orchestrator)))))
    (unless agent
      (format *trace-output* "~&[INSPECT] No agent with ID ~A found.~%" agent-id)
      (return-from inspect-agent nil))
    (let ((heartbeat-age (local-time:timestamp-difference
                          (local-time:now)
                          (agent-heartbeat agent))))
      (format *trace-output*
              "~&╔══════════════════════════════════════════════════════════════════╗~%")
      (format *trace-output*
              "~&║  AGENT: ~A~%" agent-id)
      (format *trace-output*
              "~&╠══════════════════════════════════════════════════════════════════╣~%")
      (format *trace-output*
              "~&║  Health:      ~3D / 100~%" (agent-health agent))
      (format *trace-output*
              "~&║  Status:      ~A~%" (agent-status agent))
      (format *trace-output*
              "~&║  Error Count: ~D~%" (agent-error-count agent))
      (format *trace-output*
              "~&║  Version:     ~D~%" (agent-version agent))
      (format *trace-output*
              "~&║  Capabilities: ~S~%" (agent-capabilities agent))
      (format *trace-output*
              "~&║  Heartbeat:   ~,1Fs ago~%" heartbeat-age)
      (format *trace-output*
              "~&║  Alive:       ~A~%" (agent-alive-p agent))
      (format *trace-output*
              "~&║  Strategy:    ~A~%" (agent-strategy agent))
      (format *trace-output*
              "~&║  State:       ~S~%"
              (let ((state-entries '()))
                (maphash (lambda (k v) (push (cons k v) state-entries))
                         (agent-state agent))
                state-entries))
      (format *trace-output*
              "~&╚══════════════════════════════════════════════════════════════════╝~%"))
    agent))


;;;; ═════════════════════════════════════════════════════════════════════════
;;;; END OF ORCHESTRATOR.LISP
;;;; ═════════════════════════════════════════════════════════════════════════
