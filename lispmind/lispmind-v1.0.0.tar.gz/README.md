# LISPMIND: The Living Orchestrator

> *"Code that heals itself. Agents that outlive their bugs. A system that
> learns while it runs — and never stops running."*

**LISPMIND** is a production-grade, self-healing agent orchestrator written in
Common Lisp (SBCL). It runs as a single, live, malleable image on an air-gapped
Kali Linux system.  Using the full power of CLOS MOP, the condition/restart
system, hot-patching, and macro-driven agent factories, LISPMIND creates a
*colony* of autonomous agents that monitor each other, recover from failure,
and rewrite their own strategies at runtime — **without ever restarting the
process**.

Think of it as a Kubernetes for Lisp — if Kubernetes could rewrite its own
scheduler while it was scheduling.

---

## Features

| Feature | Description |
|---------|-------------|
| **Self-Healing Agents** | Every agent carries a health score, heartbeat, and error budget. The orchestrator detects failure, stalls, and resource exhaustion — then applies the right restart automatically. |
| **Hot-Patching (Zero Downtime)** | Replace an agent's strategy function while it runs.  Old versions are preserved in a version history — rollback any time with `(mind:rollback-strategy agent)`. |
| **CLOS MOP Hooks** | `:around` methods on slot accessors trigger notifications when health or status changes.  The orchestrator reacts instantly — no polling needed. |
| **Macro-Driven Agent Factory** | `define-agent-type` is a full DSL: declare a new agent species with capabilities, strategy, and health thresholds in one expression.  It generates the class, methods, error handling, and restart bindings automatically. |
| **Checkpoint / Restore** | Serialize any agent (or the entire orchestrator) to disk with `cl-store`.  Restore after power loss with zero state loss. |
| **ASCII Dashboard** | Live REPL dashboard showing every agent's health, status, error count, and heartbeat age.  Run it in a dedicated thread and watch your colony breathe. |
| **Condition/Restart Protocol** | Six restart strategies (`:retry`, `:use-fallback`, `:escalate`, `:replace-agent`, `:hotfix-and-continue`, `:pause-and-self-modify`) are selected by a rule-based policy engine. |

---

## Prerequisites

- **SBCL** (Steel Bank Common Lisp) — tested on SBCL 2.3.x and later
- **Quicklisp** — the Common Lisp library manager
- A terminal with a monospace font (for the ASCII dashboard)

---

## Air-Gapped Kali Linux Installation

On a Kali Linux machine without internet access, follow these steps:

### 1. Install SBCL

```bash
sudo apt-get update
sudo apt-get install -y sbcl
```

Verify:
```bash
sbcl --version
# SBCL 2.3.x (or later)
```

### 2. Install Quicklisp (Offline Bootstrap)

On an internet-connected machine, download the Quicklisp bootstrap:
```bash
curl -O https://beta.quicklisp.org/quicklisp.lisp
```

Transfer `quicklisp.lisp` to the air-gapped Kali machine (USB, SCP, etc.),
then:

```bash
sbcl --load quicklisp.lisp
```

Inside the SBCL REPL:
```lisp
(quicklisp-quickstart:install)
(ql:add-to-init-file)
(quit)
```

### 3. Obtain & Place LISPMIND

Transfer the LISPMIND project directory to the air-gapped machine:

```bash
mkdir -p ~/quicklisp/local-projects/
cp -r /path/to/lispmind ~/quicklisp/local-projects/lispmind/
```

The directory layout should look like:
```
~/quicklisp/local-projects/lispmind/
  ├── lispmind.asd
  ├── packages.lisp
  ├── conditions.lisp
  ├── agent-class.lisp
  ├── macros.lisp
  ├── hotpatch.lisp
  ├── checkpoint.lisp
  ├── orchestrator.lisp
  ├── dashboard.lisp
  ├── demo.lisp
  └── README.md
```

### 4. Resolve Dependencies

You need the following libraries available to Quicklisp.  On an air-gapped
system, download them (and their transitive dependencies) on a connected
machine:

```bash
# On an internet-connected machine with SBCL + Quicklisp:
sbcl --eval '(ql:quickload "bordeaux-threads")' \
     --eval '(ql:quickload "closer-mop")' \
     --eval '(ql:quickload "alexandria")' \
     --eval '(ql:quickload "cl-ppcre")' \
     --eval '(ql:quickload "local-time")' \
     --eval '(ql:quickload "cl-store")' \
     --eval '(ql:quickload "lparallel")' \
     --eval '(quit)'
```

Then copy `~/quicklisp/dists/` and `~/quicklisp/quicklisp/` to the same
paths on the air-gapped machine.

### 5. Load LISPMIND

```bash
sbcl
```

```lisp
(ql:quickload :lispmind)
```

If all dependencies are satisfied, you will see compilation output for all
ten Lisp files followed by `:LISPMIND` — the system is alive.

---

## Quickstart

```lisp
;; Load the system
(ql:quickload :lispmind)

;; Run the self-contained demonstration
(mind:run-demo)
```

You will see:
1. An orchestrator booting up
2. Five agents spawning (3 web-scrapers, 2 analysts)
3. A simulated network failure being injected
4. The orchestrator healing the agent automatically
5. A hot-patch upgrading a broken strategy
6. Live dashboard updates for 6 seconds
7. Clean shutdown with a final summary

---

## REPL God-Mode Commands

| Command | What It Does |
|---------|-------------|
| `(mind:run-demo)` | Run the full self-healing demonstration |
| `(mind:start-orchestrator)` | Create and launch a new orchestrator |
| `(mind:stop-orchestrator orch)` | Gracefully shut down an orchestrator |
| `(mind:list-agents)` | List every registered agent with status |
| `(mind:inspect-agent 'agent-id)` | Deep inspection of a single agent |
| `(mind:heal-agent orch 'id :retry)` | Apply `:retry` restart to an agent |
| `(mind:hotpatch-agent agent :new-strategy #'my-fn)` | Replace strategy at runtime |
| `(mind:rollback-strategy agent 1)` | Roll back 1 strategy version |
| `(mind:checkpoint-system orch "./checkpoints/")` | Save all state to disk |
| `(mind:restore-system orch "./checkpoints/")` | Restore all agents from disk |
| `(mind:start-dashboard orch)` | Launch the live ASCII dashboard |
| `(mind:stop-dashboard)` | Kill the dashboard thread |
| `(mind:simulate-failure 'id 'agent-failure)` | Inject a synthetic failure |
| `(mind:send-message orch 'from 'to "hello")` | Send an inter-agent message |
| `(mind:define-agent-type my-agent ...)` | Declare a new agent species |

### Pro Tips

```lisp
;; Create a web-scraper agent inline
(defvar *scraper* (mind:make-agent :capabilities '(fetch parse store)))

;; Start a dashboard that refreshes every 2 seconds
(mind:start-dashboard)

;; Inject chaos and watch the system heal
(mind:simulate-failure 'scraper-1 'external-timeout)

;; Save everything before you go
(mind:checkpoint-system *orchestrator* "/tmp/lispmind-backup/")
```

---

## Architecture Overview

```
  ┌──────────────────────────────────────────────────────────────────┐
  │                    LISPMIND ORCHESTRATOR                          │
  │  ┌──────────────────────────────────────────────────────────┐   │
  │  │              MONITOR LOOP (bordeaux-threads)              │   │
  │  │  Every 2s:  check heartbeats ──> heal if dead/stalled   │   │
  │  │             handler-bind ──> 6 restart strategies         │   │
  │  └──────────────────────────────────────────────────────────┘   │
  │                         │                                        │
  │         ┌───────────────┼───────────────┐                       │
  │         ▼               ▼               ▼                       │
  │  ┌──────────┐   ┌──────────┐   ┌──────────┐                    │
  │  │  Agent 1 │   │  Agent 2 │   │  Agent N │  ...                │
  │  │ :running │   │ :healing │   │ :paused  │                    │
  │  │ health=92│   │ health=60│   │ health=100                    │
  │  │ errors=1 │   │ errors=4 │   │ errors=0 │                    │
  │  └────┬─────┘   └────┬─────┘   └────┬─────┘                    │
  │       │              │              │                            │
  │       └──────────────┼──────────────┘                            │
  │                      ▼                                           │
  │         ┌──────────────────────┐                                 │
  │         │   MOP :around hooks  │  health change ──> notify      │
  │         │   on slot accessors  │  status change ──> notify      │
  │         └──────────────────────┘                                 │
  │                      │                                           │
  │         ┌────────────┴────────────┐                              │
  │         ▼                         ▼                              │
  │  ┌──────────────┐      ┌──────────────────┐                     │
  │  │  HOTPATCH    │      │   CHECKPOINT     │                     │
  │  │  Versioned   │      │   cl-store       │                     │
  │  │  strategies  │      │   serialize all  │                     │
  │  └──────────────┘      └──────────────────┘                     │
  │                                                                 │
  │  ┌──────────────────────────────────────────────────────────┐   │
  │  │              DASHBOARD (ASCII REPL Thread)                │   │
  │  │  Live table: Agent | Health | Status | Errors | Heartbeat │   │
  │  └──────────────────────────────────────────────────────────┘   │
  └──────────────────────────────────────────────────────────────────┘

  DEFINE-AGENT-TYPE Macro
  ├─> defclass (inherits from AGENT)
  ├─> defmethod run-agent  (strategy + restart-case + heartbeat)
  └─> defmethod handle-condition  (rule-based restart selection)
```

### File Dependency Graph

```
packages ──> conditions ──> agent-class ──> macros
                                                │
                        ┌───────────────────────┘
                        ▼
  hotpatch ──> checkpoint ──> orchestrator ──> dashboard ──> demo
```

---

## The Philosophy

LISPMIND is built on a radical premise: **a running Lisp image is not a static
artifact — it is a living system**.  Functions are not binaries to deploy;
they are organisms to evolve.  Agents are not processes to restart; they are
cells that regenerate.  The orchestrator is not a supervisor; it is an
immune system.

When a web scraper hits a network timeout, LISPMIND doesn't crash.  It retries.
If that fails, it falls back.  If errors accumulate, it hot-patches new logic
into the running agent.  If all else fails, it replaces the agent with a fresh
clone — carrying over its state, but not its bugs.

All of this happens while the rest of the colony keeps running.  **Zero
downtime. Zero restarts. Pure living code.**

---

## Extend It

LISPMIND is a skeleton with room to grow:

- **Add a new agent type**: `(mind:define-agent-type crypto-trader ...)`
- **Add a new restart**: Extend `default-restart-policy` in orchestrator.lisp
- **Add a new condition**: Inherit from `agent-failure` in conditions.lisp
- **Cluster multiple orchestrators**: Use `send-message` over sockets
- **Swarm intelligence**: Agents could negotiate task allocation
- **Genetic strategies**: Evolve strategy functions with mutation/crossover

The MOP hooks are there.  The restart protocol is there.  The macro factory
is there.  **What will you build?**

---

*Hack the planet.  Heal the code.  Long live Lisp.*
