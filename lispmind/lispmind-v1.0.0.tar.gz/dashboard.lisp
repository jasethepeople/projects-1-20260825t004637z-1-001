;;;; -*- Mode: Lisp; Syntax: ANSI-Common-Lisp; Base: 10 -*-
;;;
;;; DASHBOARD.LISP — REPL Dashboard & Interactive Commands for LISPMIND
;;;
;;; ═══════════════════════════════════════════════════════════════════════════
;;;                    THE GOD-MODE INTERFACE
;;; ═══════════════════════════════════════════════════════════════════════════
;;;
;;; This file provides the entire REPL-based dashboard experience — the
;;; "God Mode" interface for controlling and observing the LISPMIND
;;; orchestrator. Every function is designed for the human operator sitting
;;; at the SBCL REPL, watching their agent colony live, breathe, and heal.
;;;
;;; DESIGN PHILOSOPHY
;;; ─────────────────
;;; The dashboard is not a separate GUI or web app. It is pure Common Lisp
;;; at the REPL — because on an air-gapped Kali system, the REPL *is* the
;;; interface. We use Unicode box-drawing characters for visual structure,
;;; ANSI color codes for health status, and real-time thread-based updates
;;; to create a living display that feels like a cockpit.
;;;
;;; The dashboard has two modes:
;;;   1. STATIC  — Call (mind:print-dashboard) for a one-shot snapshot.
;;;   2. LIVE    — Call (mind:start-dashboard) for a 2-second refresh loop.
;;;
;;; All dashboard operations are thread-safe. The dashboard thread only
;;; reads agent state (never writes), and it acquires no locks — reads of
;;; the slots it accesses (id, health, status, error-count, heartbeat) are
;;; atomic on SBCL for standard objects.
;;;
;;; UNICODE BOX-DRAWING LEGEND
;;; ───────────────────────────
;;;   ╔ ═ ╗  ╠ ═ ╣  ╠ ╬ ╣  ╚ ╩ ╝  ║
;;;   TL──TR  L══R   L═╬R  BL──BR  V
;;;   (top    (left   (cross  (bottom (vertical)
;;;    line    T       cross)  line)
;;;    with
;;;    corners)
;;;
;;; ANSI COLOR CODES (degrade gracefully on non-ANSI terminals)
;;; ────────────────────────────────────────────────────────────
;;;   ESC[32m  Green   — health 100 (perfect)
;;;   ESC[33m  Yellow  — health 75-99 (caution)
;;;   ESC[38;5;208m Orange — health 50-74 (warning)
;;;   ESC[31m  Red     — health < 50 (critical)
;;;   ESC[0m   Reset   — normal text
;;;
;;; "The REPL is not a debugger. It is the control panel of a living system."

(in-package :lispmind)

;; ───────────────────────────────────────────────────────────────────────────
;; Section 1: Dashboard Control Flags
;; ───────────────────────────────────────────────────────────────────────────
;;
;; These special variables control the dashboard thread lifecycle and
;; display options. They are dynamically bound where appropriate and
;; are thread-safe for the single-dashboard-thread design.

(defparameter *dashboard-running-p* nil
  "Thread-local flag controlling the dashboard refresh loop.

When START-DASHBOARD sets this to T, the DASHBOARD-LOOP runs. When
STOP-DASHBOARD sets it to NIL, the loop exits gracefully after the
current sleep cycle completes.

This is a simple flag rather than a condition variable because the
dashboard thread sleeps on a fixed 2-second interval. The stop
latency is at most 2 seconds, which is acceptable for a display.")

(defparameter *dashboard-use-unicode-p* t
  "When T, use Unicode box-drawing characters for the dashboard.
When NIL, fall back to plain ASCII (+, -, |) for maximum terminal
compatibility. Set to NIL if your terminal cannot display Unicode.")

(defparameter *dashboard-use-color-p* t
  "When T, use ANSI color codes for health status highlighting.
When NIL, display health as plain numbers. Automatically disabled
if *STANDARD-OUTPUT* is not a terminal with color support.")


;; ───────────────────────────────────────────────────────────────────────────
;; Section 2: Unicode/ASCII Character Set
;; ───────────────────────────────────────────────────────────────────────────
;;
;; A dispatch table that selects the right characters based on the
;; Unicode preference flag. This keeps the rendering code clean —
;; it just calls these accessors and gets the right glyphs.

(defun dash-char ()
  "Return the horizontal line character (═ or =)."
  (if *dashboard-use-unicode-p* "═" "="))

(defun vert-char ()
  "Return the vertical line character (║ or |)."
  (if *dashboard-use-unicode-p* "║" "|"))

(defun tl-corner ()
  "Return the top-left corner character."
  (if *dashboard-use-unicode-p* "╔" "+"))

(defun tr-corner ()
  "Return the top-right corner character."
  (if *dashboard-use-unicode-p* "╗" "+"))

(defun bl-corner ()
  "Return the bottom-left corner character."
  (if *dashboard-use-unicode-p* "╚" "+"))

(defun br-corner ()
  "Return the bottom-right corner character."
  (if *dashboard-use-unicode-p* "╝" "+"))

(defun t-junction ()
  "Return a T-junction connecting from below (╦ or +)."
  (if *dashboard-use-unicode-p* "╦" "+"))

(defun b-junction ()
  "Return an inverted T-junction (╩ or +)."
  (if *dashboard-use-unicode-p* "╩" "+"))

(defun l-junction ()
  "Return a left T-junction (╠ or +)."
  (if *dashboard-use-unicode-p* "╠" "+"))

(defun r-junction ()
  "Return a right T-junction (╣ or +)."
  (if *dashboard-use-unicode-p* "╣" "+"))

(defun cross-junction ()
  "Return a cross junction (╬ or +)."
  (if *dashboard-use-unicode-p* "╬" "+"))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 3: ANSI Color Utilities
;; ───────────────────────────────────────────────────────────────────────────
;;
;; Lightweight color formatting that degrades gracefully on terminals
;; without color support. The ESC character prefix follows the ANSI
;; escape sequence standard (ISO/IEC 6429).

(defun ansi-color (code)
  "Return an ANSI escape sequence string for the given color CODE.

CODE is an integer or a cons of (attribute ; color-code) for 256-color
mode. Returns the empty string if *DASHBOARD-USE-COLOR-P* is NIL.

Examples:
  (ansi-color 32)           → \"\e[32m\"   (green)
  (ansi-color '(38 5 208))  → \"\e[38;5;208m\" (orange)"
  (if *dashboard-use-color-p*
      (if (consp code)
          (format nil "~C[~{~A~^;~}m" #\Escape code)
          (format nil "~C[~Am" #\Escape code))
      ""))

(defun ansi-reset ()
  "Return the ANSI reset escape sequence, or empty string if color disabled."
  (if *dashboard-use-color-p*
      (format nil "~C[0m" #\Escape)
      ""))

(defun health-color (health)
  "Return an ANSI color escape string appropriate for a HEALTH value.

Color mapping:
  HEALTH = 100        → green  (ESC[32m)
  75 <= HEALTH < 100  → yellow (ESC[33m)
  50 <= HEALTH < 75   → orange (ESC[38;5;208m)
  HEALTH < 50         → red    (ESC[31m)

Returns the empty string if *DASHBOARD-USE-COLOR-P* is NIL."
  (cond ((= health 100) (ansi-color 32))     ; green: perfect
        ((>= health 75) (ansi-color 33))     ; yellow: caution
        ((>= health 50) (ansi-color '(38 5 208)))  ; orange: warning
        (t (ansi-color 31))))                ; red: critical


;; ───────────────────────────────────────────────────────────────────────────
;; Section 4: Terminal Control
;; ───────────────────────────────────────────────────────────────────────────

(defun clear-screen ()
  "Clear the terminal screen using ANSI escape codes.

Sends the \"clear screen and move cursor to home position\" sequence
(ESC[2J ESC[H). This is faster and more reliable than spawning an
external 'clear' process. Has no effect if *STANDARD-OUTPUT* is not
a terminal."
  (format t "~C[2J~C[H" #\Escape #\Escape)
  (force-output))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 5: Time Formatting Utilities
;; ───────────────────────────────────────────────────────────────────────────

(defun format-time-ago (timestamp)
  "Format a LOCAL-TIME:TIMESTAMP as a human-readable relative time string.

Calculates the difference between now and TIMESTAMP, returning strings
like 'just now', '2s ago', '1m ago', '5m ago', '1h ago', etc.

Arguments:
  TIMESTAMP — a LOCAL-TIME:TIMESTAMP instance (e.g., from AGENT-HEARTBEAT).

Returns a string suitable for display in the dashboard heartbeat column.

Examples:
  (format-time-ago (local-time:now))                    → \"just now\"
  (format-time-ago (local-time:timestamp- (now) 5 :sec)) → \"5s ago\""
  (let* ((now (local-time:now))
         (diff-sec (max 0 (floor (local-time:timestamp-difference now timestamp)))))
    (cond ((< diff-sec 2)   "just now")
          ((< diff-sec 60)  (format nil "~As ago" diff-sec))
          ((< diff-sec 120) "1m ago")
          ((< diff-sec 3600)
           (format nil "~Am ago" (floor diff-sec 60)))
          ((< diff-sec 7200) "1h ago")
          (t (format nil "~Ah ago" (floor diff-sec 3600))))))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 6: Visual Health Bar
;; ───────────────────────────────────────────────────────────────────────────

(defun health-bar (health &optional (width 20))
  "Create a visual health bar string showing proportional fill.

Returns a string like '[████████░░░░░░░░░░░░] 100%' where the number
of filled blocks represents the health percentage. Uses Unicode full
block (█) and light shade (░) characters for visual clarity.

Arguments:
  HEALTH — integer from 0 to 100 representing health percentage.
  WIDTH  — number of bar segments (default 20). Each segment is ~5%.

Returns a string of the form '[<filled><empty>] <percent>%'.

Example:
  (health-bar 100)   → \"[████████████████████] 100%\"
  (health-bar 50)    → \"[██████████░░░░░░░░░░]  50%\"
  (health-bar 0)     → \"[░░░░░░░░░░░░░░░░░░░░]   0%\""
  (let ((filled (floor (* health width) 100))
        (empty (- width (floor (* health width) 100))))
    (format nil "[~A~A] ~3D%"
            (make-string filled :initial-element #\Full_Block)
            (make-string empty  :initial-element #\Light_Shade)
            health)))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 7: Dashboard Header & Footer
;; ───────────────────────────────────────────────────────────────────────────

(defun print-dashboard-header ()
  "Print the dashboard title banner with version information.

Displays a centered title in a Unicode box:
  ╔══════════════════════════════════════════════════════════════════════╗
  ║                 LISPMIND — AGENT ORCHESTRATOR v1.0.0               ║
  ╚══════════════════════════════════════════════════════════════════════╝

The title width is 70 characters. Color is applied to the version
number in green when color is enabled."
  (let* ((title "LISPMIND — AGENT ORCHESTRATOR v1.0.0")
         (inner-width 70)
         (padding (max 0 (floor (- inner-width (length title)) 2)))
         (left-pad (make-string padding :initial-element #\Space))
         (right-pad (make-string (max 0 (- inner-width (length title) padding))
                                 :initial-element #\Space)))
    (format t "~&~A~A~A~A~A~%"
            (tl-corner) (make-string inner-width :initial-element (aref (dash-char) 0))
            (tr-corner))
    (format t "~A~A~A~A~A~A~A~%"
            (vert-char) left-pad
            (ansi-color 36) title (ansi-reset)
            right-pad (vert-char))
    (format t "~A~A~A~A~A~%"
            (l-junction) (make-string inner-width :initial-element (aref (dash-char) 0))
            (r-junction))))

(defun print-dashboard-footer ()
  "Print help text showing available REPL commands at the bottom of the dashboard.

Displays a compact command reference so the operator never needs to
remember the full API. The footer is separated from the agent table
by a horizontal rule.

Example output:
  ╔══════════════════════════════════════════════════════════════════════╗
  ║  Commands: (mind:list-agents)  (mind:inspect-agent 'id)            ║
  ║  (mind:start-dashboard)  (mind:stop-dashboard)  (mind:run-demo)    ║
  ╚══════════════════════════════════════════════════════════════════════╝"
  (let* ((inner-width 70)
         (commands "Commands: (list-agents) (inspect-agent 'id) (start-dashboard) (run-demo)"))
    (format t "~&~A~A~A~%"
            (l-junction) (make-string inner-width :initial-element (aref (dash-char) 0))
            (r-junction))
    (format t "~A ~A~A~A ~A~%"
            (vert-char)
            (ansi-color 36) commands (ansi-reset)
            (make-string (max 0 (- inner-width (length commands) 1))
                         :initial-element #\Space)
            (vert-char))
    (format t "~A~A~A~%"
            (bl-corner) (make-string inner-width :initial-element (aref (dash-char) 0))
            (br-corner))))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 8: Core Dashboard — The Agent Table
;; ───────────────────────────────────────────────────────────────────────────
;;
;; This is the visual centerpiece of LISPMIND: a beautiful ASCII table
;; showing every registered agent, its vital signs, and its last heartbeat.
;;
;; Example output:
;; ╔══════════════════════════════════════════════════════════════════════╗
;; ║                 LISPMIND — AGENT ORCHESTRATOR v1.0.0               ║
;; ╠═════════════════╦════════╦════════════╦═════════════╦══════════════╣
;; ║   Agent ID      ║ Health ║   Status   ║ Error Count ║  Heartbeat   ║
;; ╠═════════════════╬════════╬════════════╬═════════════╬══════════════╣
;; ║ SCRAPER-1234    ║  100   ║ :running   ║      0      ║   2s ago     ║
;; ║ ANALYST-5678    ║   85   ║ :running   ║      2      ║   5s ago     ║
;; ╚═════════════════╩════════╩════════════╩═════════════╩══════════════╝

(defun print-dashboard (orchestrator)
  "Print a beautiful ASCII table showing all registered agents.

This is the static snapshot function — call it anytime for a current
view of the orchestrator's agent registry. For a live updating display,
use START-DASHBOARD instead.

The table shows: Agent ID, Health (with color coding), Status, Error
Count, and Heartbeat age. Agents are sorted by ID for stable display.

Health color coding (ANSI):
  100   → green   (perfect health)
  75-99 → yellow  (minor issues)
  50-74 → orange  (significant degradation)
  <50   → red     (critical — healing needed)

Arguments:
  ORCHESTRATOR — the orchestrator instance to display (defaults to
                 *DEFAULT-ORCHESTRATOR* via START-DASHBOARD).

Returns:
  The number of agents displayed (as a secondary value, prints to *STANDARD-OUTPUT*)."
  (let ((agents '()))
    ;; Collect all agents from the registry
    (bt:with-lock-held ((orchestrator-monitor-lock orchestrator))
      (maphash (lambda (id agent)
                 (declare (ignore id))
                 (push agent agents))
               (orchestrator-agents orchestrator)))
    ;; Sort by agent-id for stable display
    (setf agents (sort agents #'string< :key (lambda (a) (symbol-name (agent-id a)))))
    ;; Print the dashboard
    (print-dashboard-header)
    (print-dashboard-column-headers)
    (print-dashboard-separator-line)
    (if (null agents)
        (print-dashboard-empty-row)
        (dolist (agent agents)
          (print-dashboard-agent-row agent)))
    (print-dashboard-bottom-line)
    (print-dashboard-footer)
    (values (length agents))))

(defun print-dashboard-column-headers ()
  "Print the column header row for the agent table.

Columns: Agent ID (16), Health (8), Status (12), Error Count (13), Heartbeat (14)."
  (format t "~A ~16A ~A ~8A ~A ~12A ~A ~13A ~A ~14A ~A~%"
          (vert-char) "Agent ID"
          (vert-char) "Health"
          (vert-char) "Status"
          (vert-char) "Error Count"
          (vert-char) "Heartbeat"
          (vert-char)))

(defun print-dashboard-separator-line ()
  "Print a horizontal separator line between header and data rows."
  (format t "~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~A~%"
          (l-junction)
          (make-string 16 :initial-element (aref (dash-char) 0))
          (cross-junction)
          (make-string 8 :initial-element (aref (dash-char) 0))
          (cross-junction)
          (make-string 12 :initial-element (aref (dash-char) 0))
          (cross-junction)
          (make-string 13 :initial-element (aref (dash-char) 0))
          (cross-junction)
          (make-string 14 :initial-element (aref (dash-char) 0))
          (r-junction)))

(defun print-dashboard-bottom-line ()
  "Print the bottom border line of the agent table."
  (format t "~A~A~A~A~A~A~A~A~A~A~A~%"
          (bl-corner)
          (make-string 16 :initial-element (aref (dash-char) 0))
          (b-junction)
          (make-string 8 :initial-element (aref (dash-char) 0))
          (b-junction)
          (make-string 12 :initial-element (aref (dash-char) 0))
          (b-junction)
          (make-string 13 :initial-element (aref (dash-char) 0))
          (b-junction)
          (make-string 14 :initial-element (aref (dash-char) 0))
          (br-corner)))

(defun print-dashboard-empty-row ()
  "Print a row indicating no agents are registered."
  (format t "~A ~68A ~A~%"
          (vert-char)
          "  [No agents registered — use (register-agent orch (make-agent))]"
          (vert-char)))

(defun print-dashboard-agent-row (agent)
  "Print a single agent's data row in the dashboard table.

Applies ANSI color to the health value based on thresholds. Formats
the heartbeat as a relative time string ('2s ago', 'just now')."
  (let ((id-str (symbol-name (agent-id agent)))
        (health (agent-health agent))
        (status (agent-status agent))
        (errors (agent-error-count agent))
        (heartbeat-str (format-time-ago (agent-heartbeat agent))))
    (format t "~A ~16A ~A ~A~4D~A ~A ~12A ~A ~13D ~A ~14A ~A~%"
            (vert-char) id-str
            (vert-char) (health-color health) health (ansi-reset)
            (vert-char) status
            (vert-char) errors
            (vert-char) heartbeat-str
            (vert-char))))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 9: Agent Introspection
;; ───────────────────────────────────────────────────────────────────────────

;; NOTE: INSPECT-AGENT and LIST-AGENTS are defined in orchestrator.lisp
;; and provide the canonical implementations. The dashboard enhances them
;; through method specializations on notify-health-change and
;; notify-status-change, plus the print-dashboard function below.


;; ───────────────────────────────────────────────────────────────────────────
;; Section 11: Failure Simulation
;; ───────────────────────────────────────────────────────────────────────────
;;
;; This function injects synthetic conditions into the system for testing
;; and demonstration purposes. It is the primary tool for showing that
;; the self-healing machinery actually works.

(defun simulate-failure (agent-id condition-type)
  "Simulate a failure on an agent for testing and demonstration.

Looks up the agent in the *DEFAULT-ORCHESTRATOR* registry, constructs
a condition of the specified type with appropriate default parameters,
and signals it. The orchestrator's monitor loop (via handler-bind)
will detect the condition and invoke the appropriate restart.

CONDITION-TYPE must be one of:
  'AGENT-FAILURE      — Simulates a complete agent failure
  'STRATEGY-STALLED   — Simulates a hung strategy
  'RESOURCE-EXHAUSTED — Simulates memory/CPU exhaustion
  'EXTERNAL-TIMEOUT   — Simulates a network/API timeout

Arguments:
  AGENT-ID      — symbol naming the target agent
  CONDITION-TYPE — quoted condition class name (one of the four above)

Returns:
  T if the condition was signalled, NIL if the agent was not found.

Example:
  (simulate-failure 'SCRAPER-1 'EXTERNAL-TIMEOUT)
  ;; → The orchestrator will apply :RETRY or :USE-FALLBACK

  (simulate-failure 'ANALYST-2 'RESOURCE-EXHAUSTED)
  ;; → The orchestrator will apply :PAUSE-AND-SELF-MODIFY"
  (unless *default-orchestrator*
    (format t "~&[DASH] No default orchestrator — start one with (start-orchestrator)~%")
    (return-from simulate-failure nil))
  (let ((agent (bt:with-lock-held ((orchestrator-monitor-lock *default-orchestrator*))
                 (gethash agent-id (orchestrator-agents *default-orchestrator*)))))
    (unless agent
      (format t "~&[DASH] No agent with ID ~A found. Cannot simulate failure.~%" agent-id)
      (return-from simulate-failure nil))
    ;; Construct and signal the appropriate condition
    (format t "~&[DASH] Simulating ~A on agent ~A...~%" condition-type agent-id)
    (case condition-type
      (agent-failure
       (signal-condition 'agent-failure
                         :agent-id agent-id
                         :reason (format nil "Simulated failure on ~A" agent-id)))
      (strategy-stalled
       (signal-condition 'strategy-stalled
                         :agent-id agent-id
                         :elapsed-time 120.0
                         :threshold 30.0))
      (resource-exhausted
       (signal-condition 'resource-exhausted
                         :agent-id agent-id
                         :resource-type :memory
                         :current-usage 1073741824
                         :limit 536870912))
      (external-timeout
       (signal-condition 'external-timeout
                         :agent-id agent-id
                         :operation "Simulated network request"
                         :timeout-seconds 30.0))
      (otherwise
       (format t "~&[DASH] Unknown condition type: ~A. Use one of: ~
                  AGENT-FAILURE, STRATEGY-STALLED, RESOURCE-EXHAUSTED, EXTERNAL-TIMEOUT~%"
               condition-type)
       (return-from simulate-failure nil)))
    (format t "~&[DASH] Condition signalled. Monitor will handle recovery.~%")
    t))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 12: Live Dashboard Thread
;; ───────────────────────────────────────────────────────────────────────────
;;
;; The live dashboard runs in a background thread, refreshing every 2
;; seconds. It uses a simple flag (*DASHBOARD-RUNNING-P*) for graceful
;; shutdown. The loop clears the screen, prints the full dashboard, then
;; sleeps.

(defun dashboard-loop (orchestrator)
  "The dashboard refresh loop. Runs in a dedicated thread.

Loop behavior:
  1. Check *DASHBOARD-RUNNING-P*. If NIL, exit.
  2. Clear the terminal screen.
  3. Print the dashboard header with title and version.
  4. Print the agent table (all registered agents).
  5. Print the footer with command reference.
  6. Force output to ensure display is visible.
  7. Sleep for 2 seconds.
  8. Repeat from step 1.

This function is called by START-DASHBOARD in a new thread. It exits
gracefully when STOP-DASHBOARD sets *DASHBOARD-RUNNING-P* to NIL.

Arguments:
  ORCHESTRATOR — the orchestrator to display (passed from START-DASHBOARD)."
  (loop
    (unless *dashboard-running-p*
      (format *trace-output* "~&[DASH] Dashboard loop exiting.~%")
      (return-from dashboard-loop nil))
    ;; Clear and redraw
    (clear-screen)
    (print-dashboard orchestrator)
    (format t "~&~%[DASH] Refreshing every 2s. Call (mind:stop-dashboard) to exit.~%")
    (force-output)
    ;; Sleep with periodic wakeups to check the flag
    (dotimes (i 20)  ; 20 x 100ms = 2 seconds, with early-exit check
      (unless *dashboard-running-p*
        (return))
      (sleep 0.1))))

(defun start-dashboard (&optional (orchestrator *default-orchestrator*))
  "Start the live dashboard in a background thread.

Spawns a new thread that runs DASHBOARD-LOOP, refreshing the display
every 2 seconds. The dashboard shows the current state of all registered
agents in a beautiful Unicode table with health color coding.

If a dashboard thread is already running on the orchestrator, this
function first stops it before starting a new one.

Arguments:
  ORCHESTRATOR — the orchestrator to display. Defaults to
                 *DEFAULT-ORCHESTRATOR*. An error is signalled if no
                 orchestrator is provided and *DEFAULT-ORCHESTRATOR*
                 is NIL.

Returns:
  The dashboard thread (a BT:THREAD instance).

Example:
  (start-dashboard)                              ; uses default
  (start-dashboard my-orchestrator)              ; explicit orchestrator
  (stop-dashboard)                               ; stops the dashboard"
  (unless orchestrator
    (error "No orchestrator provided and *DEFAULT-ORCHESTRATOR* is NIL. ~
            Start an orchestrator first: (start-orchestrator)"))
  ;; Stop existing dashboard if one is running
  (when (and (orchestrator-dashboard-thread orchestrator)
             (bt:thread-alive-p (orchestrator-dashboard-thread orchestrator)))
    (format *trace-output* "~&[DASH] Stopping existing dashboard thread...~%")
    (stop-dashboard))
  ;; Start the new dashboard
  (setf *dashboard-running-p* t)
  (let ((thread (bt:make-thread
                 (lambda () (dashboard-loop orchestrator))
                 :name "lispmind-dashboard"
                 :initial-bindings '())))
    (setf (orchestrator-dashboard-thread orchestrator) thread)
    (format *trace-output* "~&[DASH] Dashboard started on thread ~A~%"
            (bt:thread-name thread))
    thread))

(defun stop-dashboard ()
  "Stop the dashboard display thread.

Sets *DASHBOARD-RUNNING-P* to NIL, which causes the dashboard loop
to exit gracefully on its next iteration. The function returns
immediately — the actual thread exit may take up to 2 seconds.

If no dashboard is running, prints a message and returns NIL.

Returns:
  T if a dashboard was stopped, NIL if none was running.

Example:
  (stop-dashboard)  ; → T"
  (if (and *default-orchestrator*
           (orchestrator-dashboard-thread *default-orchestrator*)
           *dashboard-running-p*)
      (progn
        (setf *dashboard-running-p* nil)
        ;; Also clear the dashboard-thread slot on the orchestrator
        (when *default-orchestrator*
          (setf (orchestrator-dashboard-thread *default-orchestrator*) nil))
        (format *trace-output* "~&[DASH] Dashboard stop signal sent.~%")
        t)
      (progn
        (format *trace-output* "~&[DASH] No dashboard is currently running.~%")
        nil)))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 13: Dashboard-Enhanced Notifications
;; ───────────────────────────────────────────────────────────────────────────
;;
;; These :AFTER methods on NOTIFY-HEALTH-CHANGE and NOTIFY-STATUS-CHANGE
;; provide inline dashboard updates when agent state changes. They
;; complement the default methods (defined in agent-class.lisp) and the
;; orchestrator methods (defined in orchestrator.lisp) with compact,
;; dashboard-style output.

(defmethod notify-health-change :after ((agent agent) old-value new-value)
  "Dashboard-enhanced health notification — prints a compact dashboard row.

When an agent's health changes, this :AFTER method prints a single-line
update with color-coded health value and a mini health bar. This gives
the operator immediate visual feedback without needing to re-read the
full dashboard.

The output format:
  [HEALTH] AGENT-ID | old → new [████░░░░░░] health-bar

This method runs after the default method (which prints the basic
transition) and after any orchestrator method (which may trigger healing)."
  (let ((color (health-color new-value)))
    (format *trace-output* "~&~A[DASH-HEALTH] ~16A | ~3D → ~A~3D~A | ~A~A~%"
            (ansi-color 35)                              ; magenta prefix
            (agent-id agent)
            old-value
            color new-value (ansi-reset)
            (ansi-color 35)
            (health-bar new-value 10)
            (ansi-reset))))

(defmethod notify-status-change :after ((agent agent) old-status new-status)
  "Dashboard-enhanced status notification — prints with timestamp.

When an agent's status changes, this :AFTER method prints a timestamped
single-line update. The timestamp is formatted as an ISO-8601 local time
string, giving operators precise timing for status transitions.

The output format:
  [STATUS HH:MM:SS] AGENT-ID | :OLD-STATUS → :NEW-STATUS

This method runs after the default method (which prints the basic
transition) and after any orchestrator method (which may update the
registry or trigger the dashboard refresh)."
  (let ((timestamp (local-time:format-timestring
                    nil (local-time:now)
                    :format '((:hour 2) #\: (:min 2) #\: (:sec 2)))))
    (format *trace-output* "~&~A[DASH-STATUS ~A] ~16A | ~A → ~A~A~%"
            (ansi-color 36)                              ; cyan prefix
            timestamp
            (agent-id agent)
            old-status new-status
            (ansi-reset))))


;; ───────────────────────────────────────────────────────────────────────────
;; Section 14: REPL Command Reference
;; ───────────────────────────────────────────────────────────────────────────
;;
;; This function prints a comprehensive help menu showing every available
;; REPL command. It is the operator's cheat sheet for the God Mode interface.

(defun print-help ()
  "Print a comprehensive help menu showing all available REPL commands.

Displays every public function in the LISPMIND API that is relevant
to the human operator at the REPL. Each command includes a brief
description of what it does.

The help is organized into functional groups:
  • Introspection — looking at agents
  • Healing — fixing broken agents
  • Control — starting and stopping systems
  • Persistence — saving and restoring state
  • Testing — simulation and demos

Example:
  (print-help)  ; → prints the full help menu to *STANDARD-OUTPUT*"
  (format t "~%~%")
  (format t "╔══════════════════════════════════════════════════════════════════════╗~%")
  (format t "║          LISPMIND — REPL COMMAND REFERENCE (God Mode)              ║~%")
  (format t "╠══════════════════════════════════════════════════════════════════════╣~%")
  ;; Introspection
  (format t "║  ~AINTROSPECTION~A                                                      ║~%"
          (ansi-color 1) (ansi-reset))  ; bold
  (format t "║    (mind:list-agents)                    List all agents             ║~%")
  (format t "║    (mind:inspect-agent 'agent-id)        Detailed agent report       ║~%")
  (format t "║    (mind:print-dashboard orch)           Static dashboard snapshot   ║~%")
  (format t "╠══════════════════════════════════════════════════════════════════════╣~%")
  ;; Healing
  (format t "║  ~AHEALING & PATCHING~A                                                ║~%"
          (ansi-color 1) (ansi-reset))
  (format t "║    (mind:heal-agent orch 'id :use-fallback)   Apply named restart    ║~%")
  (format t "║    (mind:hotpatch-agent agent :new-strategy #'fn)  Live code patch   ║~%")
  (format t "║    (mind:simulate-failure 'id 'condition)    Inject test failure     ║~%")
  (format t "╠══════════════════════════════════════════════════════════════════════╣~%")
  ;; Control
  (format t "║  ~AORCHESTRATOR CONTROL~A                                              ║~%"
          (ansi-color 1) (ansi-reset))
  (format t "║    (mind:start-orchestrator)             Launch monitor thread       ║~%")
  (format t "║    (mind:stop-orchestrator orch)         Graceful shutdown           ║~%")
  (format t "║    (mind:start-dashboard)                Live REPL dashboard         ║~%")
  (format t "║    (mind:stop-dashboard)                 Stop dashboard thread       ║~%")
  (format t "╠══════════════════════════════════════════════════════════════════════╣~%")
  ;; Persistence
  (format t "║  ~APERSISTENCE~A                                                       ║~%"
          (ansi-color 1) (ansi-reset))
  (format t "║    (mind:checkpoint-system orch)         Save all agent states       ║~%")
  (format t "║    (mind:restore-system orch path)       Restore from checkpoint     ║~%")
  (format t "╠══════════════════════════════════════════════════════════════════════╣~%")
  ;; Testing
  (format t "║  ~ADEMONSTRATION~A                                                     ║~%"
          (ansi-color 1) (ansi-reset))
  (format t "║    (mind:run-demo)                       Full self-healing demo      ║~%")
  (format t "╚══════════════════════════════════════════════════════════════════════╝~%")
  (format t "~%")
  ;; Quick condition-type reference for simulate-failure
  (format t "  Condition types for SIMULATE-FAILURE:~%")
  (format t "    'AGENT-FAILURE      — Total agent failure~%")
  (format t "    'STRATEGY-STALLED   — Hung strategy function~%")
  (format t "    'RESOURCE-EXHAUSTED — Memory/CPU/disk exhaustion~%")
  (format t "    'EXTERNAL-TIMEOUT   — Network/API timeout~%")
  (format t "~%"))


;; ═══════════════════════════════════════════════════════════════════════════
;; End of DASHBOARD.LISP
;; ═══════════════════════════════════════════════════════════════════════════
;;
;; This file implements the complete REPL dashboard experience for LISPMIND:
;;
;;   • Beautiful Unicode box-drawing tables with color-coded health
;;   • Real-time live dashboard via background thread
;;   • Agent introspection with full state display
;;   • Failure simulation for testing self-healing
;;   • Dashboard-enhanced notifications on state changes
;;   • Comprehensive REPL help system
;;
;; Load this file after orchestrator.lisp. All symbols are in the
;; LISPMIND package (nickname MIND) and are exported from packages.lisp.
;;
;; "The REPL is not a debugger. It is the control panel of a living system."
